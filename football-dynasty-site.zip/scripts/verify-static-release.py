#!/usr/bin/env python3
"""Verify Football Dynasty's full static game before deploying.
This script reads static files only and NEVER opens browser saves.
"""
from pathlib import Path
from hashlib import sha256
from urllib.parse import urlsplit, unquote
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'hosting-manifest-123d.json').read_text())
errors=[]
checked=0
for key,meta in manifest['assets'].items():
    p=ROOT/key
    if not p.is_file():
        errors.append(f'MISSING essential asset: {key}'); continue
    raw=p.read_bytes()
    if len(raw)!=meta['bytes']: errors.append(f'SIZE MISMATCH: {key}')
    if sha256(raw).hexdigest()!=meta['sha256']: errors.append(f'HASH MISMATCH: {key}')
    checked+=1
for page in ['index.html','play.html','hosting-check.html','game/index.html']:
    file=ROOT/page
    if not file.is_file(): errors.append(f'MISSING HTML: {page}'); continue
    html=file.read_text(encoding='utf-8')
    for url in re.findall(r"""(?:src|href)\s*=\s*["']([^"']+)["']""",html):
        if not url or url.startswith(('#','//','mailto:','data:','javascript:')) or url.startswith(('https:','http:')): continue
        parsed=urlsplit(url)
        if not parsed.path:continue
        path=unquote(parsed.path)
        if path.startswith('/'):
            errors.append(f'ABSOLUTE LINK incompatible with repo subpath in {page}: {url}');continue
        f=(file.parent/path).resolve()
        if not f.is_relative_to(ROOT.resolve()) or not f.exists():
            errors.append(f'BROKEN LINK in {page}: {url}')
            continue
        checked+=1
sw=(ROOT/'game/sw.js').read_text(encoding='utf-8')
match=re.search(r'const SHELL\s*=\s*\[([\s\S]*?)\];',sw)
if not match: errors.append('Unable to parse service worker shell list')
else:
    for url in re.findall(r"""["'](\./[^"']+)["']""",match.group(1)):
        f=(ROOT/'game'/url).resolve()
        if not f.is_relative_to(ROOT.resolve()) or not f.exists():errors.append(f'MISSING PWA SHELL: {url}')
        else:checked+=1
m=json.loads((ROOT/'game/manifest.webmanifest').read_text())
for item in m.get('icons',[]):
    f=ROOT/'game'/item['src']
    if not f.is_file(): errors.append(f'MISSING ICON: {item["src"]}')
    else: checked+=1
for path in ['.nojekyll','game/host-bridge-123c.js','hosting-check.html']:
    if not (ROOT/path).exists():errors.append(f'MISSING REQUIRED FILE: {path}')
if errors:
    print('FAILED: '+str(len(errors))+' error(s)\n'+'\n'.join(errors));sys.exit(1)
print(f'PASS: {checked} asset links and content-integrity checks; game engine and packaged resources ready for static deployment')
