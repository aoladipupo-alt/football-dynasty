# Football Dynasty 1.22z — Legacy Feature Regression Repair

## What changed
This build fixes a bundled/offline new-career initialization defect in 1.22y. When full compiled-world loading was unavailable, the original startup path could call `rebuildSeasonFixtures(2026)` before initializing `firstSeasonFixtures`, leaving only the 396 UEFA fixture rows produced separately by the continental engine. Consequently, new careers could have no domestic league fixtures and no user matchdays.

The 2026 season rebuild now initializes its canonical domestic/FA Cup fixture baseline **only when that fixture baseline is empty**. It then uses the existing builder and unchanged IDs/dates. Pre-initialized careers keep their current first-season baseline. The 2027+ rollover logic, transfers, development and match results are unchanged.

## Measured before/after in the same seed-database Chromium harness
- Before (1.22y): 396 UEFA fixtures; **0 Premier League fixtures**, 0 fixtures for Bournemouth, no match preview link on Calendar.
- After (1.22z): **3,448 total fixtures** — 396 UEFA, 3,042 league fixtures (including 380 Premier League), and 10 first-round FA Cup fixtures; Bournemouth's opener on **2026-08-15** against Tottenham Hotspur is present.
- A Calendar click opened the match preview; a separate month-advance test reached **2026-08-15** with the schedule intact. Kickoff was observed entering LIVE with four visible touchline tactical controls; that automated browser run stalled during shutdown, so this is NOT a completed full-match test.

## Other early features audited
- Saved tactic preset and set-piece routine: browser-created, selected, present after navigation.
- Training objectives: activated and still present after navigation.
- Transfer shortlist: toggled successfully; scouting page rendered.
- Dynamics squad role: changed and persisted after navigating away.
- Inbox, staff, board, finance controls: browser rendered, no page errors.
- Club legacy/history: two Node legacy records tests passed.
- Big-match pressure: capped and neutral-match behavior passed.
- Loan reports and movement, academy intake (10 per club), youth match-selection, foreign feeder generation, save compression: targeted tests passed.
- Cross-system loan/manager/press behavior: separate standalone Chromium module tests passed; concurrent stress reruns timed out (not counted as fresh passes).
- The existing 20-year controlled lower-league rebuild passed in the inherited 1.22y suite with 227 replacement signings, 0 negative club cash budgets. No new transfer/finance rules were introduced.

## Limits
The browser harness uses the bundled/seed world with scripts injected into about:blank; real `file://` and localhost navigation were blocked by this execution environment. This verified and fixed a genuine fallback-path bug, but **does not prove the compiled-world cold-load path, an old user's multi-year career migration, or a complete interactive 90-minute match**. The fixture baseline fix is conditioned on an empty baseline to avoid disturbing already-prepared careers.

## Installing
Extract the playable archive keeping `data/`, `assets/`, and other files in place. Back up saved careers before upgrading. The service-worker cache version is bumped to 1.22z; debug export reports this version.
