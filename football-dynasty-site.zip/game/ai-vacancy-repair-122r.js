/* Football Dynasty 1.22r — bounded, funded, post-window positional repair.
 * Finds EXISTING unemployed adults for genuinely thin AI squads, after ordinary
 * transfers, loans and youth placement. No invented players, money or minutes.
 */
(function(root){'use strict';
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const round=x=>Math.round(x*100)/100;
const group=p=>root.FDSquadIntelligence122g?.family?.(p)||((p?.positions||[])[0]==='GK'?'GK':'MID');
const floors={GK:2,DEF:5,MID:4,WIDE:2,ST:2};
const bounds={1:[57,87],2:[53,78],3:[47,71],4:[45,67]};
const maxWeekly={1:100,2:23,3:12,4:7};
function review({roster=[],tier=3,year=2027}={}){
 const squad=root.FDSquadIntelligence122g;
 if(!squad)return {eligible:false,reason:'squad analysis unavailable',holes:[]};
 const report=squad.inspect(roster,year);
 const holes=Object.keys(floors).map(role=>{
  const cell=report.groups[role],effective=cell.count+cell.academyReady;
  return {role,missing:Math.max(0,floors[role]-effective),effective,first:cell.players[0]?.overall||0};
 }).filter(h=>h.missing>0).sort((a,b)=>b.missing-a.missing||Object.keys(floors).indexOf(a.role)-Object.keys(floors).indexOf(b.role));
 return {eligible:holes.length>0&&report.seniorCount>=11&&report.seniorCount<32&&
   (report.seniorCount<15||holes.length>=2||holes.some(h=>h.missing>=2)),
   holes,seniorCount:report.seniorCount,reason:holes.length?'Essential positional shortage':'No essential shortage'};
}
function suitable({player,club,roster=[],finance,year=2027,tier=3,getWage=()=>0,prepared=null}={}){
 if(!player||!player.id||!club?.id||!finance||player.clubId!=='free-agent'||player.retired||player.profilePending||player.parentClubId||player.transferType==='Loan'||
    n(player.age||player.simulationAge071g)<18||n(player.age||player.simulationAge071g)>34||
    String(player.lastTransferWindow||'')===`${year}-07`||String(player.lastTransferWindow||'')===`${year}-01`)return null;
 const t=Math.max(1,Math.min(4,n(tier)||3)),f=group(player),needs=prepared||review({roster,tier:t,year}),hole=needs.holes.find(x=>x.role===f);
 if(!needs.eligible||!hole)return null;
 const ovr=n(player.overall),[lo,hi]=bounds[t];if(ovr<lo||ovr>hi)return null;
 const peers=roster.filter(p=>p&&!p.retired&&!p.profilePending&&group(p)===f&&p.squadStatus!=='Academy'&&p.registrationGroup!=='U21').sort((a,b)=>n(b.overall)-n(a.overall));
 const senior=roster.filter(p=>p&&!p.retired&&p.registrationGroup!=='U21'&&p.squadStatus!=='Academy');
 const baseline=senior.slice().sort((a,b)=>n(b.overall)-n(a.overall))[Math.min(9,senior.length-1)]?.overall||lo+7;
 const strongest=n(peers[0]?.overall);
 if(ovr<Math.max(lo,n(baseline)-(t>=3?17:14),strongest?(strongest-(f==='GK'?19:17)):lo))return null;
 if(strongest&&ovr>strongest+15)return null; // implausible level drop for a free agent
 const wage=Math.max(.4,n(player.wage),n(getWage(player,club)));
 if(wage>maxWeekly[t])return null;
 const signingCost=round(Math.max(.02,Math.min(t>=3?.12:t===2?.28:.65,ovr*.0009)));
 if(n(finance.budget)<signingCost)return null;
 if(!root.FDMarketBalance122f?.canAdd?.({finance,roster,weeklyWage:wage}))return null;
 const age=n(player.age||player.simulationAge071g),potential=n(player.development?.potentialMax||ovr);
 const score=hole.missing*30+Math.min(20,ovr-n(baseline)+12)*2+Math.max(0,25-needs.seniorCount)*2-
   Math.max(0,age-30)*4-wage*.8+(age<=23?Math.min(5,Math.max(0,potential-ovr)):0);
 return {score,role:f,wage,signingCost,missing:hole.missing,seniorCount:needs.seniorCount};
}
function run({players=[],clubs=[],finances={},year=2027,month='July',seed='',protectedClubId='',getTier=c=>c.tier||1,
 getWage=p=>p.wage||0,getContractLength=()=>2,maxMoves=6}={}){
 const events=[];events.touchedPlayerIds097d=[];
 if(!root.FDSquadIntelligence122g||!root.FDMarketBalance122f||!['July','07','08','January','01'].includes(String(month)))return events;
 const limit=Math.min(['January','01'].includes(String(month))?3:6,Math.max(0,n(maxMoves)));
 if(!limit)return events;
 const rosters=new Map(clubs.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired&&rosters.has(p.clubId))rosters.get(p.clubId).push(p);
 const pool=players.filter(p=>p?.clubId==='free-agent'&&!p.retired&&!p.profilePending&&n(p.overall)>0).sort((a,b)=>String(a.id).localeCompare(String(b.id)));
 const stamp=`${year}-${['January','01'].includes(String(month))?'01':'07'}`;
 const eligible=clubs.filter(c=>c?.id&&c.id!==protectedClubId&&finances[c.id]&&rosters.has(c.id))
  .map(c=>({c,tier:Math.max(1,Math.min(4,n(getTier(c))||1)),roster:rosters.get(c.id)}))
  .map(x=>({...x,plan:review({roster:x.roster,tier:x.tier,year})}))
  .filter(x=>x.tier>=2&&!x.roster.some(p=>p.vacancyRepairStamp122r===stamp)&&x.plan.eligible)
  .sort((a,b)=>{
   const ah=a.plan.holes.reduce((s,x)=>s+x.missing,0),bh=b.plan.holes.reduce((s,x)=>s+x.missing,0);
   return bh-ah||a.roster.length-b.roster.length||String(a.c.id).localeCompare(String(b.c.id));
  });
 // One signing per club and a tiny world-wide cap keep this a repair pass,
 // never a replacement for the ordinary AI transfer market.
 const used=new Set();
 for(const {c,tier,roster,plan} of eligible){
  if(events.length>=limit)break;
  let best=null;
  for(const p of pool){if(used.has(p.id)||p.clubId!=='free-agent')continue;
   const fit=suitable({player:p,club:c,roster,finance:finances[c.id],year,tier,getWage,prepared:plan});
   if(!fit)continue;
   if(!best||fit.score>best.fit.score||fit.score===best.fit.score&&String(p.id)<String(best.p.id))best={p,fit};
  }
  if(!best)continue;
  const {p,fit}=best,finance=finances[c.id];
  // Recheck all affordability and vacancy rules before writing the contract.
  if(!suitable({player:p,club:c,roster,finance,year,tier,getWage}))continue;
  const priorWage=n(p.wage);
  p.clubId=c.id;p.teamName=c.name;p.leagueName=c.league;
  p.registrationGroup='Senior';p.squadStatus='First Team';p.transferType='Permanent';
  p.parentClubId=null;p.parentClubName=null;p.loanEndYear=null;p.loanEnd=null;
  p.wage=round(fit.wage);p.contractUntil=n(year)+Math.max(1,Math.min(4,n(getContractLength(p,c))||2));
  p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);
  p.lastTransferWindow=`${year}-${['January','01'].includes(String(month))?'01':'07'}`;
  p.vacancyRepairStamp122r=stamp;
  p.clubTenure073=0;p.freeAgentYears080=0;p.transferListed=false;p.wantsMove=false;
  p.transferListedByFinance=false;p.financialPressureSale=false;
  finance.budget=round(n(finance.budget)-fit.signingCost);
  finance.spent=round(n(finance.spent)+fit.signingCost);
  roster.push(p);used.add(p.id);
  events.push({kind:'ai-vacancy-repair122r',season:String(year),window:String(month),playerId:p.id,playerName:p.name,
   fromClubId:'free-agent',fromClubName:'Free Agent',toClubId:c.id,toClubName:c.name,toLeague:c.league,
   fee:0,signingCost:fit.signingCost,position:p.positions?.[0]||p.position||'',wage:fit.wage,previousWage:priorWage,
   managerStyle:'Essential depth repair',philosophy:'Affordable positional vacancy',role122r:fit.role,missingBefore122r:fit.missing,seniorBefore122r:fit.seniorCount});
  events.touchedPlayerIds097d.push(p.id);
 }
 return events;
}
const api={review,suitable,run};root.FDVacancyRepair122r=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
