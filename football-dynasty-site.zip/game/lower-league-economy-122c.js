/* Football Dynasty 1.22c — annual lower-league wage headroom and division transitions.
   This is an ALLOCATION policy, not fabricated ticket/sponsor revenue. Only confirmed
   salaries, the existing league finance profile, and real promotion/relegation count.
   Compact O(1) checks per club. Existing contracts are never cut retroactively. */
(function(root){'use strict';
const n=v=>Number.isFinite(Number(v))?Number(v):0;
const r=v=>Math.round(Math.max(0,v)*100)/100;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const minRecruiting={1:4,2:2.2,3:1.35,4:.85};
function yearly({club,finance,profile,payroll,tier,year,placement,protectedClubId=''}={}){
  if(!club||!finance||!profile||!year||club.id===protectedClubId||tier<2||tier>4)return null;
  const used=Math.max(0,n(payroll));
  const profileWage=Math.max(.1,n(profile.wageBudget));
  const placementBump=placement===1?1.085:placement<=4?1.045:placement>=17?.94:1;
  // Target uses both league-level commercial capability and CURRENT payroll.
  // A sparse squad retains an entry-level recruitment allowance, while an
  // expensive squad cannot use past overspending to print extra wage room.
  const leagueLimit=profileWage*placementBump;
  const vacancyAllowance=(tier===2?2.0:tier===3?1.35:.9);
  const payrollCeiling=used*1.24+vacancyAllowance;
  const target=Math.max(minRecruiting[tier],used*1.055,Math.min(leagueLimit,payrollCeiling));
  const previous=Math.max(0,n(finance.wageBudget));
  // A previously inflated allocation unwinds at most 24% at a time; wage
  // commitments are contractual and always remain fully covered.
  const bounded=previous>target?Math.max(target,previous*.76):target;
  const granted=r(Math.max(minRecruiting[tier],used*1.055,bounded));
  finance.wageBudget=granted;
  const row={year:Number(year),tier,league:String(club.league||''),payrollM:r(used),profileWageM:r(profileWage),wageBudgetM:granted,headroomM:r(Math.max(0,granted-used)),
    status:used>granted*.975?'Committed':used>granted*.86?'Tight':'Sustainable',allocationBasis:'League profile and signed wages; no synthetic revenue'};
  finance.lowerLeagueEconomy122c=row;
  return row;
}
function transition({club,finance,profile,payroll,toTier,fromTier,season,kind}={}){
 if(!club||!finance||!profile||!season||!toTier)return null;
 const used=Math.max(0,n(payroll)),previous=Math.max(0,n(finance.wageBudget));
 const newProfile=Math.max(.1,n(profile.wageBudget));
 let next;
 if(toTier<fromTier){
   // Promotion can create NEW headroom, within the new division's profile.
   next=Math.max(used*1.075,previous*(toTier===1?1.12:1.075),newProfile*.85);
   next=Math.min(next,Math.max(used*1.17,newProfile*1.18));
 }else{
   // Relegation starts a staged reduction. Existing payroll is not magically cut.
   next=Math.max(used*1.035,Math.min(previous*.88,newProfile*1.16));
 }
 const after=r(next);
 finance.wageBudget=after;
 const row={season:Number(season),kind:String(kind||''),fromTier:Number(fromTier),toTier:Number(toTier),previousWageBudgetM:r(previous),wageBudgetM:after,payrollM:r(used),reason:toTier<fromTier?'New-division recruitment allowance':'Relegation wage-room reduction; existing contracts honored'};
 finance.divisionEconomy122c=row;
 return row;
}
const api={yearly,transition};root.FDLowerLeagueEconomy122c=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
