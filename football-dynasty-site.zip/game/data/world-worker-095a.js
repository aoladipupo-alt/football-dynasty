/* Football Dynasty 0.95a — background world index worker. */
'use strict';
self.onmessage = event => {
  const payload=event.data||{};
  if(payload.type!=='build-indexes'||!Array.isArray(payload.rows))return;
  const out={club:Object.create(null),league:Object.create(null),nation:Object.create(null),position:Object.create(null)};
  const add=(map,key,id)=>{key=String(key||'').trim();if(!key)return;(map[key]||(map[key]=[])).push(id);};
  for(const row of payload.rows){
    if(!Array.isArray(row))continue;
    const [id,club,league,nation,positions]=row;
    if(!id)continue;
    add(out.club,club,id);add(out.league,league,id);add(out.nation,nation,id);
    for(const pos of Array.isArray(positions)?positions:[])add(out.position,pos,id);
  }
  self.postMessage({type:'indexes-ready',version:payload.version||'',indexes:out});
};
