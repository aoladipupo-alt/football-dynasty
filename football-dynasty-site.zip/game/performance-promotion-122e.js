/* Football Dynasty 1.22e — evidence-backed upward mobility for established
   lower-division seniors (not only international academy graduates).
   Transfers are paid and create neither players nor match appearances. */
(function(root){
'use strict';
const n=x=>Number(x)||0, round=x=>Math.round(x*100)/100;
const getRole=p=>{const s=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();return s==='GK'?'GK':/^(CB|LB|RB|LWB|RWB|SW)/.test(s)?'DEF':/^(LW|RW|LM|RM)/.test(s)?'WIDE':/^(ST|CF|LF|RF)/.test(s)?'ST':'MID';};
const desired={GK:3,DEF:8,MID:7,WIDE:5,ST:4};
function tier(c,getTier){return Math.max(1,Math.min(4,n(getTier(c))||1));}
function evidence(p,club,year,getTier){
 if(!p||!club)return null;
 const t=tier(club,getTier),prior=p.lowerLeagueReview122a;
 // Only season-end snapshots captured BEFORE minutes are cleared; never use
 // cumulative career minutes, unplayed pregen attributes or guessed games.
 if(prior&&n(prior.season)===year-1&&(!n(prior.tier)||n(prior.tier)===t)&&prior.role===getRole(p)&&n(prior.minutes)>0){
   return {year:year-1,tier:t,minutes:Math.round(n(prior.minutes)),source:'Completed-season senior minutes'};
 }
 // Foreign graduates also carry their May career passport, which records
 // genuine club-specific season minutes. Do not reuse a previous club's record.
 const review=(p.feederCareer121u?.reviews||[]).find(x=>x.month==='05'&&x.clubId===p.clubId&&n(x.tier)===t&&n(x.date?.slice(0,4))===year);
 return review?{year:year-1,tier:t,minutes:Math.round(n(review.minutes)),source:'Verified feeder-graduate review'}:null;
}
function eligible(p,from,year,getTier=c=>n(c?.tier)||1){
 if(!p||!from||p.retired||p.profilePending||p.clubId!==from.id||!p.id||p.transferType==='Loan'||p.parentClubId)return false;
 const t=tier(from,getTier),age=n(p.age),o=n(p.overall);
 if(t<2||age<18||age>29||p.registrationGroup==='Academy'||p.squadStatus==='Academy')return false;
 if(o<({2:72,3:64,4:60}[t])||o>87)return false;
 const proof=evidence(p,from,year,getTier);
 if(!proof||proof.minutes<({2:1650,3:1200,4:1050}[t]))return false;
 if(String(p.lastTransferWindow||'')===`${year}-07`||n(p.promotionLastYear122e)>year-3||n(p.upwardLastYear121v)>year-3)return false;
 const match=String(p.lastPermanentTransferSeason108||p.lastTransferSeason||'').match(/20\d{2}/);
 if(match&&year-n(match[0])<2)return false;
 return true;
}
function fit(p,buyer,roster,getTier=c=>n(c?.tier)||1){
 const active=roster.filter(q=>q&&!q.retired&&q.registrationGroup!=='U21'&&q.registrationGroup!=='Academy'&&q.squadStatus!=='Academy'&&q.transferType!=='Loan');
 if(active.length>=32)return null;
 const r=getRole(p),peers=active.filter(q=>getRole(q)===r).sort((a,b)=>n(b.overall)-n(a.overall));
 const rank=peers.filter(q=>n(q.overall)>n(p.overall)+1).length;
 const needs=desired[r],typical=n(peers[Math.max(0,Math.min(peers.length-1,Math.floor((needs-1)*.55)))]?.overall)||n(active[10]?.overall)||65;
 // A senior signing must be a plausible rotation player, not a bench stash.
 if(rank>=Math.max(2,needs-1)||n(p.overall)<typical-6||n(p.overall)>typical+11)return null;
 const shortage=Math.max(0,needs-peers.length);
 const upgrade=peers.some(q=>n(q.overall)+2<=n(p.overall));
 if(!shortage&&!upgrade&&active.length>=22)return null;
 return {role:r,rank,shortage,typical,rosterSize:active.length};
}
function run({players=[],clubs=[],finances={},year=2027,month='07',protectedClubId='',getTier=c=>n(c?.tier)||1,getValue=()=>1,getWage=p=>n(p.wage),getContractLength=()=>3,maxMoves=8}={}){
 const events=[];events.touchedPlayerIds097d=[];
 year=n(year)||2027;
 if(String(month).padStart(2,'0')!=='07'||!Array.isArray(players)||!Array.isArray(clubs))return events;
 const clubMap=new Map(clubs.filter(c=>c?.id).map(c=>[c.id,c]));
 const rosters=new Map(clubs.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired)rosters.get(p.clubId)?.push(p);
 const selected=players.filter(p=>p&&p.clubId!==protectedClubId&&eligible(p,clubMap.get(p.clubId),year,getTier))
   .sort((a,b)=>n(evidence(b,clubMap.get(b.clubId),year,getTier)?.minutes)-n(evidence(a,clubMap.get(a.clubId),year,getTier)?.minutes)||n(b.overall)-n(a.overall)||String(a.id).localeCompare(String(b.id)));
 const sellers=new Map(),buyers=new Map(),used=new Set();
 for(const p of selected){
  if(events.length>=Math.max(0,Math.min(12,n(maxMoves))))break;
  const from=clubMap.get(p.clubId),ft=tier(from,getTier),source=rosters.get(from.id)||[];
  if(used.has(p.id)||n(sellers.get(from.id))>=2||source.filter(q=>q&&!q.retired&&q.registrationGroup!=='U21'&&q.transferType!=='Loan').length<19)continue;
  const remaining=source.filter(q=>q.id!==p.id&&!q.retired&&getRole(q)===getRole(p)&&q.registrationGroup!=='Academy');
  if(remaining.length<Math.max(2,Math.floor(desired[getRole(p)]/2)))continue;
  const proof=evidence(p,from,year,getTier),choices=[];
  for(const buyer of clubs){
   if(!buyer?.id||buyer.id===from.id||buyer.id===protectedClubId||tier(buyer,getTier)!==ft-1||n(buyers.get(buyer.id))>=1)continue;
   // Clubs favor their own pyramid; cross-border scouting is possible for
   // established adults but not a routine shortcut for teenage lower-leaguers.
   const abroad=Boolean(from.country&&buyer.country&&from.country!==buyer.country);
   if(abroad&&n(p.age)<21&&ft>=3)continue;
   const f=finances[buyer.id];if(!f||n(f.budget)<=0||n(f.wageBudget)<=0)continue;
   const squad=rosters.get(buyer.id)||[],vacancy=fit(p,buyer,squad,getTier);if(!vacancy||root.FDSquadIntelligence122g?.severeCongestion?.(squad,p,year))continue;
   const yearsLeft=n(p.contractUntil)>year?n(p.contractUntil)-year:0;
   const fee=round(Math.max(.1,n(getValue(p,year)))*(yearsLeft<=1?.78:yearsLeft===2?.95:1.08));
   if(!Number.isFinite(fee)||fee<=0||fee>n(f.budget)*.38)continue;
   const wage=Math.max(.5,n(p.wage),n(getWage(p,buyer)));
   const payroll=squad.filter(q=>!q.retired).reduce((s,q)=>s+Math.max(0,n(q.wage))*(q.transferType==='Loan'?.026:.052),0);
   if(wage*.052>Math.max(0,(root.FDMarketBalance122f?.limit?.(f)??n(f.wageBudget))*1.015-payroll))continue;
   const rankHelp=Math.max(0,desired[vacancy.role]-vacancy.rank)*3;
   const score=(ft-tier(buyer,getTier))*20+vacancy.shortage*5+rankHelp+Math.max(0,8-Math.abs(n(p.overall)-vacancy.typical)*2)+
     Math.min(12,n(f.budget)/8)-fee/Math.max(1,n(f.budget))*5+(abroad?-10:8);
   choices.push({buyer,fee,wage,vacancy,score});
  }
  choices.sort((a,b)=>b.score-a.score||String(a.buyer.id).localeCompare(String(b.buyer.id)));
  if(!choices.length)continue;
  const {buyer,fee,wage,vacancy}=choices[0];
  const priorId=from.id,oldFinance=finances[priorId],newFinance=finances[buyer.id];
  const royalty=p.shadowSellOn121z;
  const sellOn=royalty?.academyId&&royalty.academyId!==priorId?round(Math.max(0,fee-n(royalty.initialFee))*Math.min(.3,Math.max(0,n(royalty.rate)))):0;
  // Only distribute a payable royalty, never make the seller's balance negative.
  const paidRoyalty=Math.min(fee,sellOn);
  p.clubId=buyer.id;p.teamName=buyer.name;p.leagueName=buyer.league;
  p.transferType='Permanent';p.parentClubId=null;p.registrationGroup='Senior';p.squadStatus='First Team';
  p.wage=round(wage);p.contractUntil=year+Math.min(5,Math.max(2,n(getContractLength(p,buyer))||3));
  p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=`${year}-07`;
  p.promotionLastYear122e=year;p.clubTenure073=0;p.wantsMove=false;p.transferListed=false;p.loanDestinationPending=false;
  const step={year,fromClubId:priorId,toClubId:buyer.id,fromTier:ft,toTier:tier(buyer,getTier),fee,previousMinutes:proof.minutes,outcome:'Awaiting first season'};
  p.promotionMoves122e=[step,...(p.promotionMoves122e||[])].slice(0,6);
  // Preserve the unified graduate transfer history for existing career pages.
  if(p.shadowAcademy116){p.upwardLastYear121v=year;p.upwardLastHost121v=buyer.id;
   p.upwardMoves121v=[{...step,reviewMinutes:proof.minutes},...(p.upwardMoves121v||[])].slice(0,6);}
  newFinance.budget=round(Math.max(0,n(newFinance.budget)-fee));newFinance.spent=round(n(newFinance.spent)+fee);
  if(oldFinance){oldFinance.budget=round(n(oldFinance.budget)+fee-paidRoyalty);oldFinance.received=round(n(oldFinance.received)+fee-paidRoyalty);}
  if(paidRoyalty&&royalty){royalty.earnedTotal=round(n(royalty.earnedTotal)+paidRoyalty);royalty.lastRoyaltyYear=year;
   const sponsor=finances[royalty.academyId];if(sponsor){sponsor.budget=round(n(sponsor.budget)+paidRoyalty);sponsor.received=round(n(sponsor.received)+paidRoyalty);}}
  source.splice(source.indexOf(p),1);rosters.get(buyer.id).push(p);
  used.add(p.id);sellers.set(priorId,n(sellers.get(priorId))+1);buyers.set(buyer.id,1);
  events.push({kind:'ai-performance-promotion122e',season:String(year),window:'07',playerId:p.id,playerName:p.name,
   fromClubId:priorId,fromClubName:from.name,toClubId:buyer.id,toClubName:buyer.name,toLeague:buyer.league,
   fee,sellOnRoyalty121z:paidRoyalty,position:p.positions?.[0]||p.position||'',managerStyle:'Performance recruitment',
   philosophy:'Proven senior minutes and squad opportunity',opportunity:`${proof.minutes} recorded minutes at tier ${ft}; ${vacancy.role} opening at tier ${tier(buyer,getTier)}`});
  events.touchedPlayerIds097d.push(p.id);
 }
 return events;
}
function review(p,completedYear){
 const rec=p?.promotionMoves122e?.[0];if(!rec||rec.outcome!=='Awaiting first season'||n(completedYear)!==n(rec.year))return null;
 const minutes=p.clubId===rec.toClubId?Math.max(0,Math.round(n(p.seasonMinutes))):0;
 rec.outcome=p.clubId!==rec.toClubId?'Moved again':minutes>=1200?'Established':minutes>=400?'Progress':'Blocked';
 rec.postMoveMinutes=minutes;rec.assessedYear=completedYear;
 return rec;
}
const api={run,eligible,evidence,fit,review};root.FDPerformancePromotion122e=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
