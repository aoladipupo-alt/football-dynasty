/* Football Dynasty 1.22u — opt-in, read-only debugging and quality checks.
   No player records, career saves or private localStorage values are exported. */
(()=>{
  'use strict';
  const VERSION='1.23a';
  const errors=[];
  const record=(kind,message)=>{
    if(errors.length>=20)errors.shift();
    errors.push({kind,message:String(message||'Unknown').slice(0,240)});
  };
  window.addEventListener('error',e=>record('error',e.message||e.error?.message));
  window.addEventListener('unhandledrejection',e=>record('rejection',e.reason?.message||e.reason));
  function uniqueCounts(list){
    const ids=new Set();let duplicates=0,missing=0;
    for(const row of list){const id=row?.id;if(id===undefined||id===null||String(id)===''){missing++;continue;}if(ids.has(id))duplicates++;else ids.add(id);}
    return {count:list.length,duplicateIds:duplicates,missingIds:missing};
  }
  function inspect(){
    const start=performance.now();
    const players=Array.isArray(window.FD?.allPlayers)?window.FD.allPlayers:[];
    const clubs=Array.isArray(window.FD?.allClubs)?window.FD.allClubs:[];
    const domIds=new Set();let duplicateDomIds=0;
    document.querySelectorAll('[id]').forEach(el=>{if(domIds.has(el.id))duplicateDomIds++;else domIds.add(el.id);});
    const resources=performance.getEntriesByType('resource');
    const js=resources.filter(r=>/\.js(?:\?|$)/i.test(r.name));
    const cache='caches' in window;
    return {
      version:VERSION,
      timestamp:new Date().toISOString(),
      app:{ready:!!(window.__FD_INTERACTIVE_READY_095B||window.__FD_BOOT_READY_095B),
        screen:document.documentElement.dataset.deviceMode||'unknown',
        performanceMode:window.FDPerf60?.getEffectiveMode?.()||'unknown'},
      world:{clubs:uniqueCounts(clubs),players:uniqueCounts(players)},
      document:{duplicateElementIds:duplicateDomIds},
      loading:{scriptRequests:js.length,resourceEntries:resources.length,
        lastScriptFetches:js.slice(-6).map(r=>({name:r.name.split('/').pop().split('?')[0],ms:Math.round(r.duration)})),
        careerContinue:window.__FD_CAREER_LOAD_METRICS_122V||null},
      support:{serviceWorker:'serviceWorker' in navigator,caches:cache,indexedDB:!!window.indexedDB},
      issues:errors.slice(),
      diagnosticsMs:Math.round((performance.now()-start)*100)/100
    };
  }
  let panel=null;let button=null;
  function mount(){
    if(panel)return;
    const css=document.createElement('style');css.id='fd-debug-css-122u';
    css.textContent=`#fd-debug-button-122u{position:fixed;left:10px;bottom:10px;z-index:9999;padding:7px 10px;border:1px solid #76829a;border-radius:8px;background:#151a22;color:#eaf1ff;font:600 12px system-ui;cursor:pointer}#fd-debug-panel-122u{position:fixed;left:10px;bottom:48px;z-index:10000;width:min(510px,calc(100vw - 20px));max-height:75vh;overflow:auto;border:1px solid #76829a;border-radius:10px;padding:14px;background:#151a22;color:#f3f6ff;box-shadow:0 8px 28px #000a;font:13px/1.5 system-ui}#fd-debug-panel-122u h2{font-size:16px;margin:0 0 6px}#fd-debug-panel-122u p{margin:5px 0 10px;color:#b8c6da}#fd-debug-panel-122u pre{white-space:pre-wrap;overflow-wrap:anywhere;font:11px/1.4 monospace;background:#202a39;padding:10px;border-radius:6px}#fd-debug-panel-122u button{border:1px solid #63718c;background:#29374b;color:#fff;border-radius:6px;padding:8px;cursor:pointer;margin-right:6px}`;
    document.head.appendChild(css);
    button=document.createElement('button');button.type='button';button.id='fd-debug-button-122u';button.textContent='Debug';button.setAttribute('aria-controls','fd-debug-panel-122u');button.setAttribute('aria-expanded','false');document.body.appendChild(button);
    panel=document.createElement('section');panel.id='fd-debug-panel-122u';panel.hidden=true;
    panel.setAttribute('aria-label','Football Dynasty diagnostics');
    panel.innerHTML='<h2>Football Dynasty diagnostics</h2><p>Read-only checks. Does not include saves or player details.</p><button type="button" data-action="refresh">Run checks</button><button type="button" data-action="download">Export report</button><button type="button" data-action="close">Close</button><pre aria-live="polite"></pre>';
    document.body.appendChild(panel);
    button.addEventListener('click',()=>toggle());
    panel.addEventListener('click',e=>{const action=e.target.closest('[data-action]')?.dataset.action;
      if(action==='refresh')refresh();
      if(action==='close')toggle(false);
      if(action==='download'){
        const payload=JSON.stringify(inspect(),null,2);
        const url=URL.createObjectURL(new Blob([payload],{type:'application/json'}));
        const a=document.createElement('a');a.href=url;a.download='football-dynasty-debug-122y.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
      }
    });
  }
  function refresh(){if(!panel)return;panel.querySelector('pre').textContent=JSON.stringify(inspect(),null,2);}
  function toggle(force){
    mount();const show=typeof force==='boolean'?force:panel.hidden;
    panel.hidden=!show;button.setAttribute('aria-expanded',String(show));
    if(show)refresh();
  }
  /* No scanning, DOM construction or additional timers until debugging is enabled. */
  window.FDDebug122u={inspect,open:()=>toggle(true),close:()=>toggle(false),get errors(){return errors.slice();}};
  document.addEventListener('keydown',e=>{
    if(e.ctrlKey&&e.altKey&&e.shiftKey&&String(e.key).toLowerCase()==='g'){
      e.preventDefault();toggle();
    }
  });
  try{if(new URLSearchParams(location.search).get('fdDebug')==='1')mount();}catch(_){}
})();
