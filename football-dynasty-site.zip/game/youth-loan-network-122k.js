/* Football Dynasty 1.22k — fair, affordable youth loan network.
 * No match minutes awarded here. All minutes come from real simulated fixtures. */
(function(root){'use strict';
const base=root.FDYouthOpportunities122j||(typeof module!=='undefined'?require('./youth-opportunities-122j.js'):null);
const squad=root.FDSquadIntelligence122g||(typeof module!=='undefined'?require('./squad-intelligence-122g.js'):null);
const val=x=>Number.isFinite(Number(x))?Number(x):0;
function stableHash(s){let x=2166136261;for(let i=0;i<s.length;i++){x=Math.imul(x^s.charCodeAt(i),16777619)}return x>>>0;}
function fairPool({players=[],year=2027,seed='',cap=250}={}){
 const groups=new Map();for(const p of players){if(!p?.clubId)continue;let q=groups.get(p.clubId);if(!q)groups.set(p.clubId,q=[]);q.push(p);}
 for(const arr of groups.values())arr.sort((a,b)=>{
   const pa=Boolean(a.secondChanceLoanPriority121r||a.graduateReview122i?.action==='Seek loan opportunity'||a.returnReview122i?.action==='Consider another loan');
   const pb=Boolean(b.secondChanceLoanPriority121r||b.graduateReview122i?.action==='Seek loan opportunity'||b.returnReview122i?.action==='Consider another loan');
   return Number(pb)-Number(pa)||val(a.seasonMinutes)-val(b.seasonMinutes)||stableHash(`${seed}-${year}-${a.id}`)-stableHash(`${seed}-${year}-${b.id}`);
 });
 const keys=[...groups.keys()].sort((a,b)=>stableHash(`${seed}-${year}-${a}`)-stableHash(`${seed}-${year}-${b}`));
 const result=[];let i=0;while(result.length<cap){let progressed=false;for(const key of keys){const item=groups.get(key)[i];if(item){result.push(item);progressed=true;if(result.length>=cap)break;}}if(!progressed)break;i++;}return result;
}
function destination(args={}){
 const p=args.player,host=args.hostId,roster=args.receiving||[],tier=val(args.tier),lastHosts=args.lastHosts||[];
 if(!p||!host||host===p.clubId||tier<2||lastHosts.includes(host))return {allowed:false,reason:'invalid host'};
 const report=squad.inspect(roster,args.year),group=squad.family(p),role=report.groups[group];
 const effective=role.count+role.academyReady;
 // Never flood an already crowded role or a roster at its registration ceiling.
 if(report.seniorCount>=30||role.blocked>=3||effective>=role.target+1)return {allowed:false,reason:'position congested'};
 const ability=val(p.overall),min=tier>=3?49:tier===2?56:65;
 if(ability<min)return {allowed:false,reason:'not match-ready'};
 const rank=role.players.slice().sort((a,b)=>val(b.overall)-val(a.overall));
 const typical=val(rank[Math.min(1,rank.length-1)]?.overall||rank[0]?.overall||0);
 if(typical&&ability<typical-(tier>=3?10:8))return {allowed:false,reason:'not competitive'};
 const open=effective<role.target;
 // When a position is nominally filled, accept only an actual rotation upgrade:
 // This is NOT a guaranteed start, and a host cannot hoard extra loanees.
 const peer=rank[Math.min(rank.length-1,Math.max(0,Math.ceil(rank.length*.7)-1))];
 const meaningful=val(peer?.overall||0);
 const competing=meaningful>0 && ability>=meaningful+2 && base.rotationReady({player:p,receiving:roster,tier});
 const rotationSlot=!open&&effective===role.target&&competing&&role.blocked===0&&report.seniorCount<=27;
 if(!open&&!rotationSlot)return {allowed:false,reason:'no playing-time route'};
 const previous=base.destination(args);
 if(open&&!previous.allowed)return previous;
 const score=(open?28:7)+Math.max(0,role.target-effective)*13+Math.max(0,role.floor-effective)*25+
   Math.max(-12,Math.min(14,ability-typical))+(rotationSlot?8:0);
 return {allowed:true,reason:rotationSlot?'earned rotation challenge':'genuine vacancy',group,score,rotationSlot,seniorCount:report.seniorCount,roleCount:effective};
}
const api={...base,destination,fairPool};root.FDYouthLoanNetwork122k=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
