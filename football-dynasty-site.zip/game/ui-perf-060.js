/* Football Dynasty 0.97a — adaptive paint-cost control. */
(function(){'use strict';const KEY='fd-display-performance-v1';let mode='auto';try{const saved=localStorage.getItem(KEY);if(['auto','lite'].includes(saved))mode=saved;else if(saved==='full')localStorage.setItem(KEY,'auto');}catch(_){}
const lowPower=(()=>{try{const ua=navigator.userAgent||'',mem=Number(navigator.deviceMemory||0),cores=Number(navigator.hardwareConcurrency||0);return /CrOS/i.test(ua)||(mem>0&&mem<=4)||(cores>0&&cores<=4);}catch(_){return false;}})();
function effective(){return mode==='lite'||(mode==='auto'&&lowPower)?'lite':'optimized';}
function apply(){const value=effective();document.documentElement.dataset.performance=value;document.documentElement.dataset.performanceAutoLite=mode==='auto'&&value==='lite'?'true':'false';}
function setMode(value){if(!['auto','lite'].includes(value))return;mode=value;try{localStorage.setItem(KEY,mode);}catch(_){}apply();}
window.FDPerf60={getMode:()=>mode,getEffectiveMode:effective,isLowPower:()=>lowPower,setMode,apply};apply();})();
