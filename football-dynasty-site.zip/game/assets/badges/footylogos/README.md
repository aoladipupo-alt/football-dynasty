# FootyLogos badge directory

Build 0.2 uses a badge-provider abstraction. Club records keep a FootyLogos reference and render an initials fallback until a verified local SVG/PNG is imported.

Expected naming:

- arsenal.svg
- liverpool.svg
- real-madrid.svg

Do not make gameplay code depend on a specific file format; prefer SVG and fall back to transparent PNG. Badge assets stay separate from club IDs and save data so they can be replaced without breaking careers.
