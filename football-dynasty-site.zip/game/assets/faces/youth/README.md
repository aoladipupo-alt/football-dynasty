# Football Dynasty youth portrait packs (1.14b)

All of these are user-provided fictional/pregen portraits, bundled locally for offline play.

- Original `youth-01.jpg` to `youth-40.jpg`: the original 40-face collection.
- `youth-black-01.webp` to `youth-black-64.webp`: 64 portraits from the two new eight-column, four-row grids.
- `youth-asian-01.webp` to `youth-asian-50.webp`: 50 portraits from the new ten-column, five-row grid, spanning varied looks.

The text labels from the first uploaded grid are cropped out of the individual portraits.
Selection is stable at creation and saved in each generated player's `faceSource`. An old saved player retains their old portrait, even after the pack grows. Name/nationality/development are generated independently of the artwork. Nation-based regional weights are non-exclusive and intended for visual variety, not ethnicity verification.

A total of 154 bundled youth portraits are available. The bundled real-player portrait pack is not modified. No external image loading is required for academy portraits.

## 1.14c matching safeguard

New Jamaican and Caribbean academy intake identities use the Black/Caribbean-ready
portrait collection rather than the generic or Asian collection. This is a
visual/game-art safeguard and not a claim that nationality defines ethnicity.
The assigned `faceSource` of all existing players/saves remains unchanged.
