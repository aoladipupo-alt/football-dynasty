/* Football Dynasty 1.22b — wage-aware, non-compounding lower-league renewals.
   Decisions are made on VERIFIED completed-season minutes immediately before yearEnd.
   A Decline never ends a live contract: it blocks proactive renewal and allows
   a *naturally expired* contract to end without inventing severance or revenue. */
(function(root){'use strict';
const num=v=>Number.isFinite(Number(v))?Number(v):0;
const rounded=v=>Math.round(v*1000)/1000;
const role=p=>{const pos=String(p.positions?.[0]||p.position||'CM').toUpperCase();return pos==='GK'?'GK':/^(CB|RB|LB|LWB|RWB)/.test(pos)?'DEF':/^(LW|RW|RM|LM)/.test(pos)?'WIDE':/^(ST|CF)/.test(pos)?'ST':'MID';};
const minCover={GK:2,DEF:6,MID:4,WIDE:3,ST:2};
function senior(p,clubId){return p&&!p.retired&&!p.profilePending&&p.clubId===clubId&&p.transferType!=='Loan'&&!p.parentClubId&&p.registrationGroup!=='Academy'&&p.registrationGroup!=='U21'&&p.squadStatus!=='Academy'&&num(p.age)>=18;}
function plan({players=[],clubs=[],finances={},year,protectedClubId='',getTier=c=>num(c?.tier)||1,estimateWage=p=>num(p.wage)}={}){
  const decisions=[],season=num(year);if(!season)return decisions;
  // Single linear roster grouping; 178+ clubs and thousands of players on Chromebooks.
  const allowed=new Map(clubs.filter(c=>c?.id&&c.id!==protectedClubId&&getTier(c)>=2&&getTier(c)<=4&&finances[c.id]).map(c=>[c.id,c]));
  const grouped=new Map([...allowed].map(([id])=>[id,[]]));
  for(const p of players){const group=grouped.get(p?.clubId);if(group&&senior(p,p.clubId))group.push(p);}
  for(const [id,c] of allowed){const f=finances[id],roster=grouped.get(id);if(roster.length<18)continue;
    const wageBudget=Math.max(.1,root.FDMarketBalance122f?.limit?.(f)??num(f.wageBudget));let payroll=roster.reduce((s,p)=>s+Math.max(0,num(p.wage))*.052,0);
    const sortedWages=roster.map(p=>Math.max(0,num(p.wage))).sort((a,b)=>a-b);
    const median=sortedWages[Math.floor(sortedWages.length/2)]||1;
    const peersByRole=new Map(Object.keys(minCover).map(r=>[r,roster.filter(p=>role(p)===r).sort((a,b)=>num(b.overall)-num(a.overall))]));
    const expiring=roster.filter(p=>num(p.contractUntil)>0&&num(p.contractUntil)<=season+1)
      .sort((a,b)=>num(a.contractUntil)-num(b.contractUntil)||num(b.seasonMinutes)-num(a.seasonMinutes)||String(a.id).localeCompare(String(b.id)));
    let projected=payroll;
    for(const p of expiring){const family=role(p),peers=peersByRole.get(family)||[];
      const age=num(p.age),ovr=num(p.overall),pot=num(p.development?.potentialMax)||ovr;
      const minutes=Math.max(0,num(p.seasonMinutes)),ageProtect=age<=23&&pot>=ovr+5;
      const essential=p.clubLegend073||Boolean(p.squadPromise081)||ageProtect||peers.length<=minCover[family]||peers.indexOf(p)<Math.min(2,minCover[family]-1);
      const currentWage=Math.max(0,num(p.wage)),annual=currentWage*.052;
      // A renewal can increase wages; account for its DELTA before promising another deal.
      const requested=Math.max(0,num(estimateWage(p,c,currentWage))||currentWage),increment=Math.max(0,requested-currentWage)*.052;
      const underused=minutes<550&&age>=25&&!p.injuryDays;
      const highSalary=currentWage>=Math.max(2,median*1.45);
      const financiallyTight=projected+increment>wageBudget*1.035||payroll>wageBudget*.99;
      // No AI player, even an essential one, gets an unfunded wage increase.
      // The player keeps their existing contract until it *actually* expires.
      const unfundedRise=increment>.001&&projected+increment>wageBudget*1.035;
      const fringeDecline=!essential&&(
        (underused&&highSalary&&(financiallyTight||roster.length>=30))||
        (underused&&age>=29&&peers.length>minCover[family]+1&&financiallyTight)
      );
      const decline=unfundedRise||fringeDecline;
      const reason=unfundedRise?'Unaffordable renewal demand':fringeDecline?'Underused high-wage fringe':
        essential?'Essential squad cover':minutes>=1100?'Earned renewal opportunity':'Contract remains eligible';
      const row={year:season,clubId:id,decision:decline?'Decline':'Eligible',reason,minutes:Math.round(minutes),currentWage:rounded(currentWage),requestedWage:rounded(requested),payrollM:rounded(payroll),budgetM:rounded(wageBudget)};
      p.lowerLeagueRenewal122b=row;decisions.push({playerId:p.id,...row});
      if(!decline)projected+=increment;
      else if(num(p.contractUntil)<=season)projected=Math.max(0,projected-annual);
      // Flag valuable players for the existing market while a live deal remains;
      // never make an automatic sale, offer, or early termination here.
      if(decline&&unfundedRise&&num(p.contractUntil)>season&&minutes>=1100){
        p.transferListedByFinance122b=true;p.transferListedByFinance=true;p.transferListed=true;
      }
    }
    f.lowerLeagueProjection122b={year:season,payrollM:rounded(payroll),projectedRenewalM:rounded(projected),wageBudgetM:rounded(wageBudget),declined:decisions.filter(d=>d.clubId===id&&d.decision==='Decline').length};
  }
  return decisions;
}
const api={plan};root.FDLowerLeagueRenewals122b=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
