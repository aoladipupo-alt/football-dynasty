/* Football Dynasty 1.22f — liability-accurate wage accounting and AI budget guards.
   Does not invent revenue, lower live wages, decide human transfers, or simulate
   minutes. Runs once at rollover/window, never on a match tick. */
(function(root){'use strict';
const n=x=>Number.isFinite(Number(x))?Math.max(0,Number(x)):0;
const round=x=>Math.round(n(x)*100)/100;
const loan=(p)=>p.transferType==='Loan'&&p.parentClubId&&p.parentClubId!==p.clubId;
function contributions(p){
 if(!p||p.retired||!p.clubId)return [];
 const cost=n(p.wage)*.052;
 if(!loan(p))return [[p.clubId,cost]];
 const share=Math.max(0,Math.min(1,Number.isFinite(Number(p.loanWageShare))?Number(p.loanWageShare)/100:.5));
 return [[p.clubId,cost*share],[p.parentClubId,cost*(1-share)]];
}
function ledger(players=[]){
 const payroll=new Map(),previous=new Map();
 const change=(p,sign)=>{for(const [id,cost] of contributions(p)){payroll.set(id,Math.max(0,(payroll.get(id)||0)+sign*cost));}};
 for(const p of players){if(!p||!p.id)continue;change(p,1);previous.set(p.id,{clubId:p.clubId,parentClubId:p.parentClubId,transferType:p.transferType,loanWageShare:p.loanWageShare,wage:p.wage,retired:p.retired});}
 const sync=p=>{if(!p?.id)return;const prior=previous.get(p.id);if(prior)change(prior,-1);change(p,1);previous.set(p.id,{clubId:p.clubId,parentClubId:p.parentClubId,transferType:p.transferType,loanWageShare:p.loanWageShare,wage:p.wage,retired:p.retired});};
 const get=id=>Math.max(0,payroll.get(id)||0);
 const canRenew=(p,club,f,proposed,protectedClubId='')=>{
  if(!club||!f||club.id===protectedClubId)return true;
  const current=get(club.id),old=contributions(p).find(x=>x[0]===club.id)?.[1]||0;
  const revised=current-old+n(proposed)*.052;
  // A contract's live wage is never reduced. An unfunded increase is not promised.
  return revised<=limit(f)*1.015+.001;
 };
 return {payroll,get,sync,canRenew};
}
function limit(finance){
 const budget=n(finance?.wageBudget);
 const cap=Number(finance?.recruitmentWageLimit122f);
 return Number.isFinite(cap)&&cap>=0?Math.min(budget,cap):budget;
}
function rosterPayroll(roster=[]){return roster.reduce((sum,p)=>sum+(p&&!p.retired?n(p.wage)*.052*(loan(p)?Math.max(0,Math.min(1,Number(p.loanWageShare??50)/100)):1):0),0);}
function canAdd({finance,roster=[],weeklyWage=0,loanShare=1}={}){
 if(!finance)return false;
 const cap=limit(finance),used=rosterPayroll(roster);
 const extra=n(weeklyWage)*.052*Math.max(0,Math.min(1,Number(loanShare)));
 return cap>0&&used+extra<=cap*1.015+.001;
}
function reconcile({players=[],clubs=[],finances={},year,protectedClubId='',getTier=()=>1,getProfile=()=>({wageBudget:0})}={}){
 const book=ledger(players),results=[];
 const seniorCounts=new Map();
 for(const p of players){
  if(!p||p.retired||!p.clubId||p.transferType==='Loan'||p.parentClubId||p.registrationGroup==='U21'||p.registrationGroup==='Academy'||p.squadStatus==='Academy'||n(p.age)<18)continue;
  seniorCounts.set(p.clubId,(seniorCounts.get(p.clubId)||0)+1);
 }
 for(const club of clubs){if(!club?.id||club.id===protectedClubId)continue;
  const f=finances[club.id];if(!f)continue;
  const payroll=round(book.get(club.id));
  const prior=f.marketBalance122f;
  const currentTier=n(getTier(club)),seniors=seniorCounts.get(club.id)||0;
  // A save reload or duplicate yearly hook must not transfer the same cash again.
  if(prior&&n(prior.year)===n(year)&&Math.abs(n(prior.payrollM)-payroll)<.005&&n(prior.seniorCount)===seniors&&n(prior.tier)===currentTier){results.push({clubId:club.id,...prior});continue;}
  const profile=Math.max(.1,n(getProfile(club)?.wageBudget));
  // The recruitment ceiling is based on economically supportable wages, not
  // an emergency budget top-up to honor existing contracted salaries.
  const annualAllocation=prior&&n(prior.year)===n(year)?n(prior.approvedAllocationM):n(f.wageBudget);
  const tier=currentTier;
  // Sparse AI squads may exchange a SMALL part of their existing transfer
  // allocation for annual contract room. This is a paid board tradeoff, not
  // additional revenue and not available to manager-controlled clubs.
  const vacancy=Math.max(0,21-seniors);
  const maximumReserve=tier===2?.40:tier===3?.24:tier===4?.14:0;
  const reserve=prior&&n(prior.year)===n(year)?n(prior.transferredFromTransferBudgetM):round(Math.min(vacancy*.055,maximumReserve,n(f.budget)*.075));
  if(reserve>.005&&!(prior&&n(prior.year)===n(year)))f.budget=round(n(f.budget)-reserve);
  const fundingGap=Math.max(0,payroll-annualAllocation);
  // Honor all contracted wages, including the ten youth contracts per club.
  // Cover obligations WITHOUT adding cash. Only genuine recruitment headroom
  // and the transferred reserve can support a NEW permanent signing.
  const fundedAllocation=round(Math.max(annualAllocation,payroll*1.025)+reserve);
  const normalRecruitmentCap=Math.min(annualAllocation,Math.max(profile*1.24,payroll*1.055));
  const vacancyCap=reserve>.005?payroll+reserve*.98:0;
  const recruitmentCap=round(Math.min(fundedAllocation,Math.max(normalRecruitmentCap,vacancyCap)));
  f.wageBudget=fundedAllocation;
  f.wageOvercommit122f=round(fundingGap);
  f.recruitmentWageLimit122f=recruitmentCap;
  const row={year:Number(year)||0,tier,seniorCount:seniors,payrollM:payroll,
    approvedAllocationM:round(annualAllocation),allocationM:fundedAllocation,
    existingContractCoverageM:round(Math.max(0,fundedAllocation-annualAllocation-reserve)),
    transferredFromTransferBudgetM:reserve,
    recruitmentLimitM:recruitmentCap,overcommitM:round(fundingGap),
    status:fundingGap>.005?'Contract overhang':payroll>=recruitmentCap*.98?'Recruitment frozen':'Funded',
    basis:'Confirmed contracts; limited cash allocation tradeoff for understaffed squads; no invented revenue'};
  f.marketBalance122f=row;results.push({clubId:club.id,...row});
 }
 return results;
}
const api={ledger,limit,rosterPayroll,canAdd,reconcile,contributions};
root.FDMarketBalance122f=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
