/* Football Dynasty 1.22o: transfer-window-only affordability fallback.
 * Read-only candidate selection; no price discounts, forced player transfers,
 * invented statistics, state writes or looping over the full player database.
 */
(function(root){'use strict';
 const finite=x=>Number.isFinite(Number(x))?Number(x):0;
 // A buyer checks its first choice normally. Only if it fails affordability
 // does it look at other candidates, and then only at real squad shortages.
 function freeAgentFallback(picks,{affordable,genuineNeed,maxChecked=12}={}){
   if(!Array.isArray(picks)||typeof affordable!=='function'||typeof genuineNeed!=='function')return null;
   const cap=Math.max(1,Math.min(16,Math.floor(finite(maxChecked)||12)));
   const top=picks[0];
   if(top && top.p && affordable(top))return top;
   for(let i=1;i<Math.min(picks.length,cap);i++){
     const row=picks[i];
     if(row?.p&&!row.p.retired&&!row.p.profilePending&&genuineNeed(row)&&affordable(row))return row;
   }
   return null;
 }
 function priceFloor(row,rivalry=0,sellerPrestige=0,buyerPrestige=0){
   if(!row||!row.p||finite(row.price)<=0)return Infinity;
   const rival=finite(rivalry),seller=finite(sellerPrestige),buyer=finite(buyerPrestige);
   let premium=row.star?1.08:1;
   if(rival>0)premium*=rival>=3?1.38:rival>=2?1.22:1.10;
   if(buyer<seller)premium*=1.04;
   // .94 is the lowest pre-existing negotiation random factor.
   const base=Math.round(finite(row.price)*.94*premium*10)/10;
   const clause=finite(row.p.releaseClause);
   // A valid release clause is still honoured; this helper never invents one.
   return clause>0?Math.min(base,Math.round(clause*10)/10):base;
 }
 function paidShortlist(rows,{cash,prestige=0,rivalry,sellerPrestige,canFundWage}={}){
   if(!Array.isArray(rows)||typeof rivalry!=='function'||typeof sellerPrestige!=='function'||typeof canFundWage!=='function')return [];
   const funds=Math.max(0,finite(cash)),buyer=finite(prestige),cap=funds*(buyer>=90?.74:.62);
   if(!funds)return [];
   return rows.filter(x=>x&&x.p&&!x.p.retired&&!x.p.profilePending&&
     finite(x.suitability)>=60&&priceFloor(x,rivalry(x),sellerPrestige(x),buyer)<=cap+0.00001&&canFundWage(x));
 }
 const api={freeAgentFallback,priceFloor,paidShortlist};root.FDNegotiation122o=api;
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
