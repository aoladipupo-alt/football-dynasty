/* Football Dynasty 1.01a — personalities and promises and cache-coherent install. */
'use strict';
const VERSION='fd-app-123c-web-bridge-v1';
const SHELL_CACHE=`${VERSION}-shell`;
const RUNTIME_CACHE=`${VERSION}-runtime`;
const SHELL=[
  './',
  './index.html',
  './manifest.webmanifest',
  './bundle-071p.css',
  './ui-perf-060.js',
  './app-shell-096b.js',
  './debug-kit-122u.js',
  './data/player-age-index-111.js',
  './device-mode-096g.js',
  './host-bridge-123c.js',
  './runtime-096g.js',
  './shadow-ai-market-117.js',
  './market-balance-122f.js',
  './squad-intelligence-122g.js',
  './transfer-churn-122h.js',
  './long-term-squads-122i.js',
  './youth-opportunities-122j.js',
  './youth-loan-network-122k.js',
  './youth-minute-balance-122l.js',
  './squad-health-122m.js',
  './recruitment-signals-122n.js',
  './negotiation-fallback-122o.js',
  './bidding-counteroffers-122p.js',
  './ai-transfer-strategy-122q.js',
  './ai-vacancy-repair-122r.js',
  './lower-league-scouting-122s.js',
  './vacancy-evidence-122t.js',
  './lower-league-finances-122a.js',
  './lower-league-renewals-122b.js',
  './lower-league-economy-122c.js',
  './lower-league-entry-121z.js',
  './lower-league-rebuild-122d.js',
  './shadow-career-paths-120.js',
  './feeder-careers-121u.js',
  './upward-careers-121z.js',
  './performance-promotion-122e.js',
  './feeder-census-121w.js',
  './assets/app/icon-180.png',
  './assets/app/icon-192.png',
  './assets/app/icon-512.png',
  './assets/app/icon-maskable-512.png'
];
self.addEventListener('install',event=>{
  /* Do not skipWaiting here. Existing careers keep their current app version
     until the manager explicitly accepts the update. */
  event.waitUntil(caches.open(SHELL_CACHE).then(cache=>cache.addAll(SHELL)));
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k.startsWith('fd-app-')&&!k.startsWith(VERSION)).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});
self.addEventListener('message',event=>{
  if(event.data?.type==='SKIP_WAITING') self.skipWaiting();
});
/* 1.22u: bounded lazy cache to prevent unbounded image/shard accumulation.
   Precached app code remains in SHELL_CACHE and is never evicted by this policy. */
const MAX_RUNTIME_ENTRIES=240;
const TRIM_EVERY=16;
let cacheWrites=0;
let trimPromise=null;
async function trimRuntimeCache(cache){
  if(trimPromise)return trimPromise;
  trimPromise=(async()=>{
    const keys=await cache.keys();
    const excess=Math.max(0,keys.length-MAX_RUNTIME_ENTRIES);
    if(excess)await Promise.all(keys.slice(0,excess).map(key=>cache.delete(key)));
  })();
  try{await trimPromise;}finally{trimPromise=null;}
}
async function cacheFirst(request,event){
  /* Cache is version-scoped; avoid scanning unrelated service-worker caches. */
  const shell=await caches.open(SHELL_CACHE);
  const precached=await shell.match(request,{ignoreSearch:true});
  if(precached)return precached;
  const cache=await caches.open(RUNTIME_CACHE);
  const hit=await cache.match(request,{ignoreSearch:true});
  if(hit)return hit;
  const response=await fetch(request);
  if(response&&response.ok){
    const write=(async()=>{
      try{
        await cache.put(request,response.clone());
        if(++cacheWrites%TRIM_EVERY===0)await trimRuntimeCache(cache);
      }catch(_){/* Quota or private-mode restrictions cannot break gameplay. */}
    })();
    /* Keep the worker alive long enough to finish caching, including on mobile. */
    if(event&&typeof event.waitUntil==='function')event.waitUntil(write);
  }
  return response;
}
async function shellNavigation(request){
  /* Installed/repeat launches are instant and version-coherent. A new shell
     arrives with the next service-worker version rather than mixing files. */
  const cached=await caches.match('./index.html',{ignoreSearch:true});
  if(cached) return cached;
  try{return await fetch(request);}catch(_){return Response.error();}
}
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET')return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin)return;
  if(request.mode==='navigate'){
    event.respondWith(shellNavigation(request));
    return;
  }
  const path=url.pathname;
  const staticAsset=/\.(?:js|css|png|webp|svg|woff2?)$/i.test(path) || path.includes('/data/compiled-095a/');
  if(staticAsset) event.respondWith(cacheFirst(request,event));
});
