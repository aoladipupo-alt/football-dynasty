/* Football Dynasty 1.22n: bounded, window-only recruitment tie-breakers.
 * Reads natural listed positions and existing senior depth; does not give anyone
 * a new position, create a signing, fabricate match minutes or alter finances.
 */
(function(root){'use strict';
 const squad=root.FDSquadIntelligence122g || (typeof require!=='undefined'?require('./squad-intelligence-122g.js'):null);
 const n=x=>Number.isFinite(Number(x))?Number(x):0;
 const GROUPS=['GK','DEF','MID','WIDE','ST'];
 // Only consider candidates already satisfying the game's normal threshold;
 // otherwise try the next genuine positional need. Never waive any budget,
 // seller, player-interest, squad-size, or registration safeguards.
 function viable(rows=[],minimum=60){
   if(!Array.isArray(rows))return [];
   const threshold=Number.isFinite(Number(minimum))?Number(minimum):60;
   return rows.filter(r=>r&&r.p&&!r.p.retired&&!r.p.profilePending&&Number.isFinite(Number(r.suitability))&&Number(r.suitability)>=threshold);
 }
 const api={viable};root.FDRecruitment122n=api;
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
