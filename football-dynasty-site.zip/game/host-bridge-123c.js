/* Football Dynasty 1.23c - same-origin web launcher bridge. No save contents travel via postMessage. */
(()=>{
  'use strict';
  const PROTOCOL=1, PREFIX='FD_WEB_BRIDGE_123C', VERSION='1.23b';
  function safeStatus(){
    let started=false, ready=false;
    try{ready=typeof window.FD?.careerContext==='function';started=Boolean(window.FD?.careerContext?.()?.started);}catch(_){}
    return {ready,careerLoaded:started,engineVersion:VERSION,cloudSaveConnected:false,multiplayerAvailable:false};
  }
  function deliver(parent,requestId,kind,payload){
    parent.postMessage({channel:PREFIX,protocol:PROTOCOL,kind,requestId,...payload},location.origin);
  }
  function downloadCareer(){
    if(typeof window.FDStablePolish?.exportCareer!=='function')throw Error('Career backup tool is not ready. Open the game and finish loading your career first.');
    const payload=window.FDStablePolish.exportCareer();
    const slot=Math.max(1,Math.min(5,Number(window.FD?.careerContext?.()?.slot)||1));
    const file=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(file),link=document.createElement('a');
    link.href=url;link.download=`football-dynasty-career-${slot}.json`;
    document.body.append(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),2000);
    return {filename:link.download};
  }
  window.addEventListener('message',event=>{
    // Reject cross-origin/foreign-window callers (including an embedded Base44 page).
    if(window.parent===window || location.protocol==='file:' || event.source!==window.parent || event.origin!==location.origin)return;
    const data=event.data;
    if(!data||data.channel!==PREFIX||data.protocol!==PROTOCOL||!Number.isSafeInteger(data.requestId))return;
    if(data.kind==='status')deliver(event.source,data.requestId,'status',safeStatus());
    else if(data.kind==='download-backup'){
      try{const result=downloadCareer();deliver(event.source,data.requestId,'backup-result',{ok:true,...result});}
      catch(error){deliver(event.source,data.requestId,'backup-result',{ok:false,message:String(error?.message||error).slice(0,300)});}
    }
  });
  window.addEventListener('fd-interactive-ready-095b',()=>{
    if(window.parent!==window && location.origin!=='null'){
      try{deliver(window.parent,0,'ready',safeStatus());}catch(_){}
    }
  });
  // No APIs for importing data, deleting saves, changing finances, or match results.
  window.FDWebBridge123C=Object.freeze({protocol:PROTOCOL,safeStatus});
})();
