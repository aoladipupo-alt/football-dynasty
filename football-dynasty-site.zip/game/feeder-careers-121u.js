/* Football Dynasty 1.21u — persistent feeder-graduate career passport.
   Records actual reviewed appearances, divisions and club changes only.
   Recommendations never invent minutes or execute transfers. */
(function(root){
'use strict';
const N=x=>Math.max(0,Number(x)||0);
function assess(player,club,date,{originName='',tier=null}={}){
 if(!player?.shadowAcademy116||!player.shadowSignedSeason117||!club||!/^\d{4}-(01|05)-01$/.test(date))return null;
 const prev=player.feederCareer121u||{};
 if(prev.lastDate===date)return prev;
 const level=Math.max(1,Math.min(5,Math.round(Number(tier??club.tier)||1)));
 const old=Array.isArray(prev.reviews)?prev.reviews:[];
 const total=N(player.shadowSeasonMinutes120);
 // This evidence is obtained from finished fixtures via the existing career review.
 const year=Number(date.slice(0,4)), month=date.slice(5,7);
 const actualMinutes=total; // no cross-club historical minutes counted as new-club opportunity
 const lastSame=old.find(e=>e.clubId===player.clubId);
 const poorReviews=old.filter(e=>e.clubId===player.clubId&&e.month==='05'&&e.minutes<450).length;
 const age=N(player.age),ovr=N(player.overall),potential=N(player.development?.potentialMax||player.overall);
 let decision='Develop at current club';
 if(player.transferType==='Loan')decision='Assess loan after completed fixtures';
 else if(level>=3&&ovr>=73&&actualMinutes>=1300)decision='Scout a higher division';
 else if(level===2&&ovr>=80&&actualMinutes>=1600)decision='Scout top-flight clubs';
 else if(poorReviews>=1&&total<450&&age<=23&&potential>=ovr+4)decision='Seek playing-time loan';
 else if(poorReviews>=1&&total<450&&age<=26)decision='Consider permanent move';
 else if(total>=1450)decision='Established first-team contributor';
 else if(total>=450)decision='Continue rotation';
 const movement=lastSame&&lastSame.tier!==level?(level<lastSame.tier?'Club promoted to a stronger division':'Club relegated to a lower division'):'';
 const clubChange=old.length&&old[0].clubId!==player.clubId?`Moved from ${old[0].clubName||'previous club'}`:'';
 const entry={date,month,season:month==='01'?year-1:year-1,clubId:player.clubId,clubName:club.name,tier:level,minutes:Math.round(total),ovr:Math.round(ovr*10)/10,decision,movement:movement||clubChange};
 const reviews=[entry,...old].slice(0,10);
 const result={originId:prev.originId||player.shadowOrigin116||'',originName:prev.originName||originName||player.shadowOrigin116||'',lastDate:date,decision,reviews};
 player.feederCareer121u=result;
 // Let the existing opportunity-checked loan market handle this recommendation.
 if(decision==='Seek playing-time loan'&&!player.parentClubId&&!player.loanDestinationPending&&age<=23){
   player.shadowLoanFlag120=true;
 }
 return result;
}
function summary(p){const c=p?.feederCareer121u;return c?{origin:c.originName||c.originId,decision:c.decision,steps:(c.reviews||[]).slice(0,6)}:null;}
const api={assess,summary};root.FDFeederCareers121u=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
