/* Football Dynasty 0.96b — install/update shell debug. */
(()=>{
  'use strict';
  const installBtn=document.getElementById('app-install');
  const updateBtn=document.getElementById('app-update');
  const net=document.getElementById('app-network');
  let installPrompt=null;
  let refreshing=false;
  let updateRequested=false;
  let registrationStarted=false;
  let registrationPromise=null;

  const standalone=()=>window.matchMedia?.('(display-mode: standalone)')?.matches || window.navigator.standalone===true;
  const setNetwork=()=>{
    if(!net)return;
    const online=navigator.onLine!==false;
    net.textContent=online?'Online':'Offline';
    net.dataset.state=online?'online':'offline';
    net.hidden=online;
  };
  const persistStorage=async()=>{
    try{if(navigator.storage?.persist) await navigator.storage.persist();}catch(_){}
  };

  window.addEventListener('beforeinstallprompt',event=>{
    event.preventDefault();
    installPrompt=event;
    if(installBtn&&!standalone()) installBtn.hidden=false;
  });
  window.addEventListener('appinstalled',()=>{
    installPrompt=null;
    if(installBtn) installBtn.hidden=true;
    persistStorage();
  });
  installBtn?.addEventListener('click',async()=>{
    if(!installPrompt)return;
    const prompt=installPrompt;
    installPrompt=null;
    installBtn.hidden=true;
    try{
      await prompt.prompt();
      await prompt.userChoice;
      persistStorage();
    }catch(_){}
  });

  window.addEventListener('online',setNetwork);
  window.addEventListener('offline',setNetwork);
  setNetwork();
  if(standalone()){
    if(installBtn) installBtn.hidden=true;
    persistStorage();
  }

  const showUpdate=worker=>{
    if(!worker||!updateBtn)return;
    updateBtn.hidden=false;
    updateBtn.onclick=()=>{
      updateRequested=true;
      updateBtn.disabled=true;
      updateBtn.textContent='Updating…';
      worker.postMessage({type:'SKIP_WAITING'});
    };
  };

  const register=()=>{
    if(registrationStarted) return registrationPromise;
    registrationStarted=true;
    registrationPromise=(async()=>{
      if(!('serviceWorker' in navigator)) return null;
      try{
        /* Stable worker URL from 0.96b onward: future releases update one registration. */
        const reg=await navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'});
        if(reg.waiting) showUpdate(reg.waiting);
        reg.addEventListener('updatefound',()=>{
          const worker=reg.installing;
          worker?.addEventListener('statechange',()=>{
            if(worker.state==='installed'&&navigator.serviceWorker.controller) showUpdate(worker);
          });
        });
        navigator.serviceWorker.addEventListener('controllerchange',()=>{
          /* Reload only after the manager explicitly accepts an update. */
          if(!updateRequested||refreshing)return;
          refreshing=true;
          location.reload();
        });
        setTimeout(()=>reg.update().catch(()=>{}),5000);
        return reg;
      }catch(error){
        console.warn('Football Dynasty app shell unavailable:',error);
        return null;
      }
    })();
    return registrationPromise;
  };

  const startRegistration=()=>{
    if(registrationStarted)return;
    if('requestIdleCallback' in window) requestIdleCallback(register,{timeout:5000});
    else setTimeout(register,1800);
  };
  if(window.__FD_INTERACTIVE_READY_095B) startRegistration();
  else window.addEventListener('fd-interactive-ready-095b',startRegistration,{once:true});
  /* Recovery/first-visit fallback; registration guard prevents duplicate setup. */
  window.addEventListener('load',()=>setTimeout(startRegistration,5000),{once:true});
})();
