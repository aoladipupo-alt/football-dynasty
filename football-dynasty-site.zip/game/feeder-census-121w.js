/* Football Dynasty 1.21w: read-only career census for real global academy cohorts.
   Counts only signed graduates and recorded May-season reviews; source clubs
   do not play fictional fixtures and this module never edits player stats. */
(function(root){'use strict';
const n=x=>Number(x)||0;
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const originId=p=>String(p?.shadowOrigin116||p?.academyOriginClubId112||'');
const FOCUS=['ASEC Mimosas','Enyimba FC','Auckland City'];
function rows(players,clubs,focus=FOCUS){
 const byId=new Map((clubs||[]).filter(c=>c?.id).map(c=>[String(c.id),c]));
 const result=new Map();
 for(const name of focus){const club=[...byId.values()].find(c=>c.name===name);
   if(club)result.set(String(club.id),{source:club.name,sourceId:club.id,generated:0,signed:0,played:0,lowerLeagueFirstContracts:0,reviewedMinutes:0,upwardMoves:0,peakOverall:0,topPlayer:'',established:0});
 }
 for(const p of players||[]){if(!p?.shadowAcademy116||p.shadowSenior118)continue;
   const row=result.get(originId(p));if(!row)continue;row.generated++;
   if(!p.shadowSignedSeason117)continue;row.signed++;
   if(n(p.shadowFirstDestination121x?.tier)>=2)row.lowerLeagueFirstContracts++;
   const reviews=(p.feederCareer121u?.reviews||[]).filter(x=>x?.month==='05'&&x.clubId);
   const distinct=new Set(),actual=[];
   for(const x of reviews){const k=String(x.date||x.season||'');if(distinct.has(k))continue;distinct.add(k);actual.push(x);}
   const minutes=actual.reduce((s,x)=>s+Math.max(0,n(x.minutes)),0);
   row.reviewedMinutes+=minutes;
   if(minutes>0)row.played++;
   if(actual.some(x=>n(x.minutes)>=1200))row.established++;
   row.upwardMoves+=(p.upwardMoves121v||[]).filter(m=>m?.fromTier>m?.toTier).length;
   if(n(p.overall)>row.peakOverall){row.peakOverall=n(p.overall);row.topPlayer=String(p.name||'');}
 }
 return [...result.values()];
}
function render(players,clubs){const data=rows(players,clubs);if(!data.length)return '';
 const total=data.reduce((a,x)=>a+x.generated,0),signed=data.reduce((a,x)=>a+x.signed,0),played=data.reduce((a,x)=>a+x.played,0);
 return `<section class="card"><h3>Global Graduate Career Census <span class="status good">Verified careers</span></h3><div class="card-body"><p class="meta">${total.toLocaleString()} academy prospects from three tracked source clubs · ${signed.toLocaleString()} signed by professional clubs · ${played.toLocaleString()} with reviewed senior minutes. Source clubs are non-playable; no matches are created for them.</p><div class="table-wrap"><table><thead><tr><th>Source academy</th><th>Generated</th><th>Signed</th><th>With minutes</th><th>Lower-league first contracts</th><th>Career moves up</th><th>Best current graduate</th></tr></thead><tbody>${data.map(x=>`<tr><td>${esc(x.source)}</td><td>${x.generated}</td><td>${x.signed}</td><td>${x.played}</td><td>${x.lowerLeagueFirstContracts}</td><td>${x.upwardMoves}</td><td>${x.topPlayer?`${esc(x.topPlayer)} · ${Math.round(x.peakOverall)} OVR`:'—'}</td></tr>`).join('')}</tbody></table></div><p class="meta">Counts reflect the current saved career; recorded minutes are based on completed season reviews. Review history is capped, so historical minutes are not presented as all-time career totals.</p></div></section>`;
}
const api=Object.freeze({rows,render});root.FDFeederCensus121w=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
