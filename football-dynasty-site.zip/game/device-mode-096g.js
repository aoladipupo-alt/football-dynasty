/* Football Dynasty 0.97t — incremental UI performance and debug loader with verified 0.94d recovery. */
(() => {
  'use strict';
  const runtime='runtime-096g.js?v=123a-save-transfer';
  const recoveryRuntime='runtime-recovery-094d.js?v=recovery-094d';
  const gate=document.getElementById('device-gate'),switcher=document.getElementById('device-switch'),status=document.getElementById('boot-status');
  let loading=false,loaded=false,recovered=false;
  const setStatus=(text,show=true)=>{if(!status)return;status.textContent=text;status.hidden=!show;};
  const unlock=()=>{document.documentElement.removeAttribute('aria-busy');document.getElementById('app')?.removeAttribute('inert');setStatus('',false);};
  function setMode(mode){document.documentElement.dataset.deviceMode=mode;try{localStorage.setItem('fd-device-mode',mode);}catch(_){}if(switcher)switcher.textContent=mode==='pc'?'Switch to mobile':'Switch to PC';}
  function preloadRuntime(){try{const l=document.createElement('link');l.rel='preload';l.as='script';l.href=runtime;document.head.appendChild(l);}catch(_){}}
  function inject(src){return new Promise((resolve,reject)=>{const el=document.createElement('script');el.src=src;el.async=true;el.onload=()=>resolve(true);el.onerror=()=>{try{el.remove();}catch(_){}reject(new Error(`Could not load ${src}`));};document.body.appendChild(el);});}
  async function loadRuntime(){
    if(loaded)return true;if(window.__FD_RUNTIME_PROMISE_095B)return window.__FD_RUNTIME_PROMISE_095B;
    loading=true;setStatus('Starting Football Dynasty…');document.documentElement.setAttribute('aria-busy','true');document.getElementById('app')?.setAttribute('inert','');
    window.__FD_RUNTIME_PROMISE_095B=(async()=>{
      try{await inject(runtime);loaded=true;if(window.__FD_INTERACTIVE_READY_095B||window.__FD_BOOT_READY_095B)unlock();else setStatus('Preparing your club…');}
      catch(primaryError){console.warn(primaryError);recovered=true;setStatus('Primary game file failed. Starting verified recovery…');await inject(recoveryRuntime);loaded=true;if(window.__FD_BOOT_READY_094D)unlock();else setStatus('Recovery runtime loaded. Preparing database…');}
      finally{loading=false;}
      return true;
    })().catch(error=>{
      /* Failed primary + recovery: let the PC/Mobile button retry instead of
         reusing a permanently rejected promise. */
      window.__FD_RUNTIME_PROMISE_095B=null;
      loaded=false;
      throw error;
    });
    return window.__FD_RUNTIME_PROMISE_095B;
  }
  async function begin(mode){if(loading||loaded)return;setMode(mode);if(gate)gate.hidden=true;if(switcher)switcher.hidden=false;try{await loadRuntime();}catch(error){console.error(error);document.documentElement.removeAttribute('aria-busy');document.getElementById('app')?.removeAttribute('inert');if(gate)gate.hidden=false;if(switcher)switcher.hidden=true;const note=gate?.querySelector('.device-gate-note');if(note)note.textContent='Unable to load game files. Check that you extracted the full ZIP and try again.';setStatus('',false);}}
  preloadRuntime();
  window.addEventListener('fd-world-progress-095a',e=>{if(window.__FD_INTERACTIVE_READY_095B)return;const d=e.detail||{};setStatus(d.message||'Preparing football world…');});
  window.addEventListener('fd-database-progress-091b',e=>{if(window.__FD_INTERACTIVE_READY_095B)return;const l=Number(e?.detail?.loaded||0),t=Number(e?.detail?.total||0);if(t>0)setStatus(`Loading recovery database… ${l.toLocaleString()} / ${t.toLocaleString()}`);});
  window.addEventListener('fd-interactive-ready-095b',unlock);
  window.addEventListener('fd-boot-ready-095b',unlock);
  window.addEventListener('fd-boot-ready-094d',()=>{if(recovered)unlock();});
  gate?.addEventListener('click',e=>{const b=e.target.closest('[data-device]');if(b)begin(b.dataset.device);});
  switcher?.addEventListener('click',()=>setMode(document.documentElement.dataset.deviceMode==='pc'?'mobile':'pc'));
  try{const prior=localStorage.getItem('fd-device-mode');if(prior==='pc'||prior==='mobile'){setMode(prior);if(gate)gate.hidden=true;if(switcher)switcher.hidden=false;requestAnimationFrame(()=>begin(prior));}else gate?.querySelector('[data-device="pc"]')?.focus({preventScroll:true});}catch(_){}
})();
