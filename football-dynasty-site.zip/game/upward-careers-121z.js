/* Football Dynasty 1.21z: evidence-backed upward moves for global feeder graduates.
   Consumes actual May career reviews; never creates appearances or ability gains. */
(function(root){
'use strict';
const n=x=>Number(x)||0, r=x=>Math.round(x*10)/10;
const group=p=>{const s=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();return s==='GK'?'GK':/^(CB|LB|RB|LWB|RWB|SW)/.test(s)?'DEF':/^(LW|RW|LM|RM)/.test(s)?'WIDE':/^(ST|CF|LF|RF)/.test(s)?'ST':'MID';};
const desired={GK:3,DEF:8,MID:7,WIDE:5,ST:4};
function tier(c){const t=Number(c?.tier);return Math.max(1,Math.min(4,Number.isFinite(t)&&t>0?t:1));}
function recentReview(p,year){const rows=p?.feederCareer121u?.reviews||[];return rows.find(x=>x.month==='05'&&n(x.date?.slice(0,4))>=year-1&&x.clubId===p.clubId)||null;}
function eligible(p,source,year,clubTier=tier){
 if(!p||!source||!p.shadowAcademy116||!p.shadowSignedSeason117||p.retired||p.profilePending||p.transferType==='Loan'||p.parentClubId)return false;
 if(clubTier(source)<2||n(p.age)<18||n(p.age)>28||n(p.overall)<(clubTier(source)>=3?62:65)||n(p.overall)>89)return false;
 if(n(p.shadowSignedSeason117)>=year||n(p.upwardLastYear121v)>year-3)return false;
 const last=String(p.lastPermanentTransferSeason108||p.lastTransferSeason||'').match(/20\d{2}/);
 if(last&&year-n(last[0])<2)return false;
 const review=recentReview(p,year);
 // A tier-three regular can be ready for a tier-two step before becoming a star;
 // promotion to the top tier still requires stronger, sustained senior evidence.
 const minimumMinutes=clubTier(source)>=3?850:1500;
 if(!review||n(review.minutes)<minimumMinutes||n(review.ovr)<(clubTier(source)>=3?61:70))return false;
 const originTier=n(review.tier);
 if(originTier!==clubTier(source))return false; // do not sign from stale pre-promotion assessments
 // Tier-three clubs develop capable 61-68 OVR regulars who should be
 // eligible for a *competitive* Championship trial, not require top-flight ability.
 // A shorter 850-minute fixture season needs a proven positive form floor.
 return clubTier(source)>=3?(n(p.overall)>=62&&(n(review.minutes)>=1150||n(p.form)>=6.6)):n(p.overall)>=71;
}
function vacancy(p,buyer,roster,clubTier=tier){
 const senior=roster.filter(x=>!x.retired&&x.registrationGroup!=='U21'&&x.squadStatus!=='Academy');
 const max=clubTier(buyer)===1?34:clubTier(buyer)===2?35:36;
 if(senior.length>=max)return null;
 const f=group(p),peers=senior.filter(x=>group(x)===f).sort((a,b)=>n(b.overall)-n(a.overall));
 const typical=n(peers[Math.min(peers.length-1,desired[f]-1)]?.overall)||n(senior[10]?.overall)||64;
 // A club with several weaker defenders may still need an upgrade.
 // Positional *headcount* alone cannot block a clear top-rotation signing;
 // the total senior cap and the actual rank/quality gates still apply.
 // Must compete for actual matchday consideration, not simply sit behind elite players.
 const fromTier=n(p.shadowUpwardSourceTier121z)||0;
 const lowLeagueStep=fromTier>=3&&clubTier(buyer)===2;
 if(n(p.overall)<typical-(lowLeagueStep?7:5)||n(p.overall)>typical+12)return null;
 const rank=peers.filter(x=>n(x.overall)>n(p.overall)+1).length;
 if(rank>=Math.max(2,desired[f]))return null; // fourth-choice striker is a real vacancy
 return {group:f,typical,rank,peers:peers.length};
}
function run({players=[],clubs=[],finances={},year=2027,month='07',seed='',protectedClubId='',getTier=tier,getValue=()=>1,getWage=()=>3,getContractLength=()=>3,maxMoves=8}={}){
 year=n(year)||2027;const mm=String(month).padStart(2,'0');
 const output=[];output.touchedPlayerIds097d=[];
 if(mm!=='07'||!Array.isArray(players)||!Array.isArray(clubs))return output;
 const byId=new Map(clubs.map(c=>[c.id,c])),byRoster=new Map(clubs.map(c=>[c.id,[]]));
 for(const p of players){if(!p||p.retired)continue;byRoster.get(p.clubId)?.push(p);}
 const sold=new Set(),bought=new Set(),moved=new Set();
 const candidates=players.filter(p=>eligible(p,byId.get(p?.clubId),year,getTier)&&p.clubId!==protectedClubId)
 .sort((a,b)=>n(b.feederCareer121u.reviews.find(x=>x.month==='05')?.minutes)-n(a.feederCareer121u.reviews.find(x=>x.month==='05')?.minutes)||String(a.id).localeCompare(String(b.id)));
 // Buyer iteration is deterministic: no RNG in saved careers or repeated window calls.
 for(const p of candidates){
   if(output.length>=Math.max(0,Math.min(16,n(maxMoves))))break;
   const from=byId.get(p.clubId);if(!from||sold.has(from.id)||moved.has(p.id))continue;
   const fromRoster=byRoster.get(from.id)||[],positionPeers=fromRoster.filter(x=>!x.retired&&x.registrationGroup!=='U21'&&group(x)===group(p));
   if(fromRoster.filter(x=>!x.retired&&x.registrationGroup!=='U21').length<18||positionPeers.length<2)continue;
   // Let tier-3 regulars compete against the buyer's real squad as appropriate.
   // This internal hint is used only for this transfer pass and deleted below.
   p.shadowUpwardSourceTier121z=getTier(from);
   const choices=[];
   for(const buyer of clubs){
     if(buyer.id===from.id||buyer.id===protectedClubId||bought.has(buyer.id)||getTier(buyer)!==getTier(from)-1)continue;
     const f=finances[buyer.id];if(!f||n(f.budget)<=0||(root.FDMarketBalance122f?.limit?.(f)??n(f.wageBudget))<=0)continue;
     const roster=byRoster.get(buyer.id)||[];
     const opportunity=vacancy(p,buyer,roster,getTier);if(!opportunity||root.FDSquadIntelligence122g?.severeCongestion?.(roster,p,year))continue;
     const fee=Math.max(.1,r(Math.min(75,Math.max(.1,n(getValue(p,year)))*(Number(p.contractUntil)>=year+2?1.05:.83)*(getTier(from)>=3?.91:1))));
     if(fee>n(f.budget)*.48)continue;
     const wage=Math.max(1,n(getWage(p,buyer)));
     const wageBill=roster.reduce((acc,x)=>acc+(x.transferType==='Loan'?.5:1)*n(x.wage)*.052,0);
     // Wage budgets are annual M; wages on player contracts are weekly thousands.
     // A financially secure buyer may absorb a small short-term salary overrun;
     // severe overspending remains disallowed and remains subject to cash budget.
     const annualAfter=wageBill+wage*.052;
     const wageHeadroom=(n(f.budget)-fee)>=Math.max(8,fee*.25)?1.055:1.02;
     if(annualAfter>(root.FDMarketBalance122f?.limit?.(f)??n(f.wageBudget))*wageHeadroom)continue;
     const interest=n(p.overall)-opportunity.typical;
     const score=(getTier(from)-getTier(buyer))*20+ Math.max(0,5-Math.abs(interest))*3+
       Math.max(0,desired[opportunity.group]-opportunity.peers)*6+Math.min(12,n(f.budget)/6)+
       (buyer.id===p.upwardLastHost121v?-100:0)+ (getTier(from)>=3&&opportunity.rank<Math.max(2,desired[opportunity.group]-1)?5:0);
     choices.push({buyer,f,fee,wage,score,opportunity});
   }
   choices.sort((a,b)=>b.score-a.score||String(a.buyer.id).localeCompare(String(b.buyer.id)));
   const best=choices[0];delete p.shadowUpwardSourceTier121z;if(!best)continue;
   const {buyer,f,fee,wage,opportunity}=best;
   const oldWage=n(p.wage),previousId=from.id;
   p.clubId=buyer.id;p.teamName=buyer.name;p.leagueName=buyer.league;
   p.transferType='Permanent';p.registrationGroup='Senior';p.squadStatus='First Team';
   p.wage=wage;p.contractUntil=year+Math.max(2,Math.min(5,n(getContractLength(p,buyer))||3));
   p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=`${year}-07`;
   p.upwardLastYear121v=year;p.upwardLastHost121v=buyer.id;
   p.clubTenure073=0;p.wantsMove=false;p.transferListed=false;p.loanDestinationPending=false;
   const move={year,fromClubId:previousId,toClubId:buyer.id,fromTier:getTier(from),toTier:getTier(buyer),fee,reviewMinutes:n(recentReview({...p,clubId:previousId},year)?.minutes),outcome:'Awaiting first season'};
   p.upwardMoves121v=[move,...(p.upwardMoves121v||[])].slice(0,6);
   if(p.feederCareer121u){p.feederCareer121u.decision='Moved up a division — review playing time after fixtures';}
   const toFinance=finances[buyer.id],fromFinance=finances[from.id];
   const clause=p.shadowSellOn121z;
   const academyRoyalty=clause?.academyId&&clause.academyId!==from.id?
      r(Math.max(0,fee-n(clause.initialFee))*Math.min(.3,Math.max(0,n(clause.rate)))):0;
   if(clause&&academyRoyalty>0){clause.earnedTotal=r(n(clause.earnedTotal)+academyRoyalty);clause.lastRoyaltyYear=year;}
   // Selling club retains proceeds net of the academy's agreed profit-sharing fee.
   toFinance.budget=r(Math.max(0,n(toFinance.budget)-fee));toFinance.spent=r(n(toFinance.spent)+fee);
   if(fromFinance){fromFinance.budget=r(n(fromFinance.budget)+fee-academyRoyalty);fromFinance.received=r(n(fromFinance.received)+fee-academyRoyalty);}
   if(academyRoyalty&&finances[clause.academyId]){const sf=finances[clause.academyId];sf.budget=r(n(sf.budget)+academyRoyalty);sf.received=r(n(sf.received)+academyRoyalty);}
   byRoster.get(previousId)?.splice(byRoster.get(previousId).indexOf(p),1);byRoster.get(buyer.id).push(p);
   sold.add(previousId);bought.add(buyer.id);moved.add(p.id);
   const event={kind:'ai-feeder-upward121v',season:String(year),window:'07',playerId:p.id,playerName:p.name,
      fromClubId:previousId,fromClubName:from.name,toClubId:buyer.id,toClubName:buyer.name,toLeague:buyer.league,
      fee,sellOnRoyalty121z:academyRoyalty,position:p.positions?.[0]||p.position||'',managerStyle:'Development pathway',philosophy:'First-team opportunity',
      opportunity:`${Math.round(move.reviewMinutes)} recorded minutes at tier ${move.fromTier}; now tier ${move.toTier}`};
   output.push(event);output.touchedPlayerIds097d.push(p.id);
 }
 return output;
}
function review(p,date){
 const history=p?.upwardMoves121v;
 if(!Array.isArray(history)||!history.length||!/^(\d{4})-05-01$/.test(String(date)))return null;
 const move=history[0],year=n(String(date).slice(0,4));
 if(move.outcome!=='Awaiting first season'||year<=n(move.year))return null;
 const review=(p?.feederCareer121u?.reviews||[]).find(x=>x.date===date&&x.clubId===move.toClubId);
 if(!review)return null;
 const minutes=Math.max(0,n(review.minutes));
 move.outcome=p.clubId!==move.toClubId?'Moved again':minutes>=1200?'Established':minutes>=400?'Progress':'Blocked';
 move.assessedYear=year;move.postMoveMinutes=Math.round(minutes);
 return move;
}
const api={run,eligible,vacancy,review};root.FDUpwardCareers121v=api;root.FDUpwardCareers121y=api;root.FDUpwardCareers121z=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
