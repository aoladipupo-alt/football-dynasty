# Football Dynasty 1.23a — Save Loading & Human Transfer Audit

## Release scope
Built from **1.22z**. This is a focused bug-fix release, not a new transfer market or save format.

### Fix 1 — stale player wage agreement
A permanent transfer could have the player's terms agreed while the squad was within the wage budget, then be **registered later after other squad/budget changes** with no new annual payroll check. The completion path now rechecks current payroll using the existing `Squad61A.wageStatus` logic and the game's 108% critical wage threshold. When the contract cannot fit, the deal is kept open as `Wage budget issue`, earlier personal-term approval is invalidated, and the player, finances, and completed transfer history are left unchanged. The manager can negotiate again after freeing wages.

### Fix 2 — Continue loading callback robustness
The save manager previously awaited `requestAnimationFrame` to paint the loading state before reconstructing a career. Animation frames can be suspended while a tab is hidden; Continue could become stuck on the loading label. The new handler will proceed via a 160 ms safety timer even when the frame never arrives. This is a **robustness safeguard, not a demonstrated solution to every cold-load hang**.

### Cache coherency
Updated the runtime request token, app shell/script token, diagnostic version and PWA cache version so patched code is not silently masked by an old installed cache.

## Testing performed
- **10/10 controlled Chromium transfer-registration assertions passed**; imported roster fresh career loaded 3,886 players and no page exceptions were detected in this run.
- A paid transfer was established with controlled pre-agreed club/agent terms. Changing wage budget to below viable payroll caused registration to fail correctly, without moving the player or recording completion. Restoring funds and agreement permitted registration; fee, recorded history and saved player assignment were verified.
- **14/14 selected Node regression scripts passed**, including AI bargaining, youth pathways, finance, and the **20-year real-roster lower-league replacement test**.
- **3/3 Continue animation-frame fallback tests passed**, including suspended and hidden-tab cases.
- All four changed JavaScript entry points passed `node --check`.

## Remaining problems / testing boundaries
A **fresh, cold browser Continue test still stalled in this isolated browser setup** following the save-manager click. Unlike the successful same-session tests, it could not confirm full cold-reopen behavior; no fabricated timing/success metric is reported. A genuine older multi-season career export should be used for the next debugging cycle. Never overwrite the source save while diagnosing a failed cold reopen.

Normal negotiated fee acceptance and agent personal terms were not both traversed by full user clicks in this QA exercise. The validated transfer test concentrates on the final contract-registration boundary, including save persistence and finance checks.

## Installation
Use the playable ZIP as a full replacement of the game project on the **same app origin** if you want browser-stored careers to remain accessible. Back up a career first, because opening the game from a different origin or folder may not expose the previous origin's localStorage. The source/debug ZIP retains all older documentation and regression scripts, plus 1.23a tests.
