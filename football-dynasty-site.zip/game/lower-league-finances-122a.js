/* Football Dynasty 1.22a: lower-league wage discipline and natural squad turnover.
   Review actual season minutes BEFORE year-end clears them. During a July window,
   allow at most two funded mutual separations from over-crowded/over-budget AI clubs.
   Never fabricate transfer fees, player wages, appearances or club revenue. */
(function(root){'use strict';
const n=x=>Number(x)||0,round=x=>Math.round(x*100)/100;
const role=p=>{const x=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();return x==='GK'?'GK':/^(CB|RB|LB|LWB|RWB)/.test(x)?'DEF':/^(LW|RW|RM|LM)/.test(x)?'WIDE':/^(ST|CF)/.test(x)?'ST':'MID';};
const limits={GK:2,DEF:6,MID:4,WIDE:3,ST:2};
function active(p){return p&&!p.retired&&!p.profilePending&&p.clubId&&p.clubId!=='free-agent'&&p.transferType!=='Loan'&&!p.parentClubId&&p.registrationGroup!=='Academy';}
function senior(p){return active(p)&&p.registrationGroup!=='U21'&&p.squadStatus!=='Academy'&&n(p.age)>=18;}
function review({players=[],clubs=[],season,protectedClubId='',getTier=c=>n(c?.tier)||1 }={}){
  const out=[];const clubMap=new Map(clubs.filter(c=>getTier(c)>=2).map(c=>[c.id,c]));
  // Include U21-registered players who genuinely played senior minutes; exit
  // decisions still use the separate senior() gate and never release U21s.
  for(const p of players){if(!active(p)||n(p.age)<18||!clubMap.has(p.clubId)||p.clubId===protectedClubId)continue;
    const tier=getTier(clubMap.get(p.clubId));if(tier<2)continue;
    const y=n(season),previous=p.lowerLeagueReview122a;
    if(previous&&n(previous.season)===y)continue;
    const mins=Math.max(0,Math.round(n(p.seasonMinutes)));
    const age=n(p.age),potential=n(p.development?.potentialMax)||n(p.overall);
    // Genuine repeated non-selection, not a single injury-hit season.
    const streak=mins<300&&!p.injuryDays&&age>=25&&!p.clubLegend073&&!p.squadPromise081?
      Math.min(6,n(previous?.streak)+1):0;
    const state={season:y,tier,minutes:mins,streak,role:role(p),recommendation:streak>=2?'Fringe exit':mins>=1000?'Regular':mins>=480?'Rotation':'Monitor'};
    p.lowerLeagueReview122a=state;
    if(streak>=2&&age>=27&&potential<n(p.overall)+8&&!p.shadowAcademy116){
      p.lowerLeagueAvailable122a=true; // Advisory only; do not poison normal AI transfer windows.
    }
    out.push({playerId:p.id,clubId:p.clubId,...state});
  }
  return out;
}
function run({players=[],clubs=[],finances={},year,month='07',protectedClubId='',maxPerClub=2,getTier=c=>n(c?.tier)||1}={}){
 const changes=[];changes.touchedPlayerIds097d=[];
 if(String(month).padStart(2,'0')!=='07')return changes;
 const byClub=new Map(clubs.filter(c=>getTier(c)>=2&&getTier(c)<=4&&c.id!==protectedClubId&&finances[c.id]).map(c=>[c.id,c]));
 const rosters=new Map([...byClub].map(([id])=>[id,players.filter(p=>p.clubId===id&&senior(p))]));
 for(const [id,c] of byClub){
   const f=finances[id],r=rosters.get(id);
   if(n(f.lastLowerExitWindow122a)===n(year)||r.length<27)continue;
   const payroll=()=>round(r.reduce((s,p)=>s+n(p.wage)*.052,0));
   let used=0;const initiallyOverCapacity=r.length>=37;
   const proposals=r.filter(p=>{
     const v=p.lowerLeagueReview122a;
     return v&&n(v.season)===n(year)-1&&n(v.streak)>=2&&n(v.minutes)<300&&
       n(p.development?.potentialMax||p.overall)<n(p.overall)+8&&
       n(p.age)>=27&&n(p.contractUntil)<=n(year)+1&&n(p.contractUntil)>=n(year)&&
       n(p.lastPermanentTransferSeason108||p.lastTransferSeason||0)<=n(year)-3&&
       !p.clubLegend073&&!p.shadowAcademy116&&!p.secondChanceCareer121p;
   }).sort((a,b)=>n(a.lowerLeagueReview122a.minutes)-n(b.lowerLeagueReview122a.minutes)||n(a.overall)-n(b.overall)||String(a.id).localeCompare(String(b.id)));
   for(const p of proposals){
     if(used>=Math.min(2,Math.max(0,n(maxPerClub)))||r.length<=23)break;
     const peers=r.filter(x=>role(x)===role(p));
     if(peers.length<=limits[role(p)])continue;
     // A low payroll-to-budget ratio gives no reason to pay players to leave;
     // space pressure is also real for rosters of 32+ senior players.
     const ratio=payroll()/Math.max(.1,n(f.wageBudget));
     if(ratio<1.12&&!initiallyOverCapacity)break;
     const weekly=Math.max(0,n(p.wage)),severance=round(weekly*52/1000*.28);
     if(severance>Math.max(0,n(f.budget))*.15||n(f.budget)<severance)continue;
     const former=id,fromName=c.name,seniorBefore=r.length,pressureBefore=round(ratio);
     f.budget=round(n(f.budget)-severance);f.spent=round(n(f.spent)+severance);
     p.clubId='free-agent';p.teamName='Free Agent';p.leagueName='Free Agents';p.transferType='Permanent';
     p.registrationGroup='Senior';p.squadStatus='Free Agent';p.parentClubId=null;p.contractUntil=n(year);
     p.wage=0;p.releaseClause=null;p.transferListed=false;p.transferListedByAI073=false;
     p.wantsMove=false;p.lowerLeagueAvailable122a=false;
     p.lowerLeagueExit122a={year:n(year),clubId:former,severance,reason:'Mutual contract termination; repeated underuse'};
     p.clubTenure073=0;
     r.splice(r.indexOf(p),1);used++;
     changes.push({kind:'ai-lower-league-mutual-exit122a',season:String(year),window:'July',playerId:p.id,playerName:p.name,
       fromClubId:former,fromClubName:fromName,toClubId:'free-agent',toClubName:'Free Agent',fee:0,severance,
       position:p.positions?.[0]||p.position||'CM',seniorBefore,wageRatioBefore:pressureBefore,reason:'Two underused seasons; funded mutual termination',wageRoomFreed:round(weekly*.052)});
     changes.touchedPlayerIds097d.push(p.id);
   }
   f.lastLowerExitWindow122a=n(year);
 }
 return changes;
}
const api={review,run};root.FDLowerLeagueFinances122a=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
