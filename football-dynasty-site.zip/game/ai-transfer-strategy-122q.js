/* Football Dynasty 1.22q — bounded AI recruitment strategy (window-time only).
 * Read-only decisions; no budget creation, fake match minutes, automatic user-club
 * transfers, or changes to player abilities. Existing transfer eligibility,
 * seller interest, financial controls and youth selection remain authoritative.
 */
(function(root){'use strict';
 const groups=['GK','DEF','MID','WIDE','ST'];
 const desired={GK:2,DEF:7,MID:5,WIDE:5,ST:3};
 const finite=x=>Number.isFinite(Number(x))?Number(x):0;
 const role=p=>{
   const pos=String(p?.positions?.[0]||p?.position||p?.primaryPosition||'ST').toUpperCase();
   if(pos==='GK')return 'GK';
   if(['CB','LB','RB','LWB','RWB','WB'].includes(pos))return 'DEF';
   if(['DM','CDM','CM'].includes(pos))return 'MID';
   if(['AM','CAM','LW','RW','LM','RM'].includes(pos))return 'WIDE';
   return 'ST';
 };
 function plan({roster=[],finance={},tier=1,year=2026,needs=[]}={}){
   const senior=roster.filter(p=>p&&!p.retired&&!p.profilePending&&p.transferType!=='Loan'&&p.registrationGroup!=='U21'&&p.squadStatus!=='Academy');
   const buckets=Object.fromEntries(groups.map(g=>[g,[]]));
   for(const p of roster){if(p&&!p.retired&&!p.profilePending)buckets[role(p)].push(p);}
   const shortages=groups.filter(g=>buckets[g].filter(p=>((p.registrationGroup!=='U21'&&p.squadStatus!=='Academy')||finite(p.seasonMinutes)>=300)).length<Math.max(1,Math.ceil(desired[g]*.65)));
   const preferred=Array.isArray(needs)&&needs.length?needs[0]?.group:shortages[0]||'GK';
   const budget=Math.max(0,finite(finance?.budget));
   const base=Math.max(.1,finite(finance?.baseBudget)||budget);
   const wageBudget=Math.max(0,finite(finance?.wageBudget));
   const payroll=senior.reduce((n,p)=>n+Math.max(0,finite(p.wage))*.052,0); // weekly wages => annual £m, same as existing finance guard
   const wageTight=wageBudget>0&&payroll>=wageBudget*.94;
   const cashTight=budget<(tier>=3?.6:tier===2?2:6)||budget/base<.16;
   const readyYouth={};
   for(const group of groups){
     const peers=buckets[group].slice().sort((a,b)=>finite(b.overall)-finite(a.overall));
     const competition=finite(peers[Math.min(1,Math.max(0,peers.length-1))]?.overall);
     readyYouth[group]=peers.filter(p=>{
       const age=finite(p.age||p.simulationAge071g||25);
       return age>=18&&age<=23&&finite(p.seasonMinutes)>=300&&
         finite(p.overall)>=(competition?competition-3:48);
     }).length;
   }
   const dominant=preferred&&groups.includes(preferred)?preferred:shortages[0]||'MID';
   const priority=needs.find(n=>n.group===dominant)||{};
   const gap=shortages.length>0||finite(priority.short)>0;
   const youthReady=readyYouth[dominant]>0&&buckets[dominant].length>=desired[dominant];
   let approach='buy';
   if(!gap && senior.length>=31)approach='hold';
   else if(!gap && youthReady)approach='develop';
   else if(wageTight)approach='hold';
   else if(gap && cashTight)approach=tier>=2?'loan':'free';
   else if(cashTight)approach='free';
   return {approach,priorityGroup:dominant,shortages,readyYouth,seniorCount:senior.length,
     cashTight,wageTight,reason:approach==='develop'?'Proven homegrown cover':
       approach==='loan'?'Cash-limited positional vacancy':
       approach==='free'?'Affordable contract-first recruitment':
       approach==='hold'?'Protect squad and wage commitments':'Funded positional recruitment'};
 }
 function mayAddPaid({plan:decision,roster=[],candidate,year=2026}={}){
   if(!candidate||!decision||decision.approach!=='develop'||finite(decision.seniorCount)>=24)return true;
   const group=role(candidate),groupRows=roster.filter(p=>p&&!p.retired&&!p.profilePending&&role(p)===group);
   if(groupRows.length<desired[group]+5||groupRows.length<2||finite(decision.readyYouth?.[group])<2)return true;
   // A transfer clearly upgrading the rotation stays permitted. A comparable
   // fringe senior must not erase an existing, genuinely playing U23 prospect.
   const youth=groupRows.filter(p=>{
     const age=finite(p.age||p.simulationAge071g||25);
     return age>=18&&age<=23&&finite(p.seasonMinutes)>=300;
   });
   const best=Math.max(0,...youth.map(p=>finite(p.overall)));
   return finite(candidate.overall)>best+2;
 }
 function freeProbability(base,decision){
   if(!decision)return base;
   return decision.approach==='free'?Math.min(.98,base+.02):
     decision.approach==='loan'?Math.min(.98,base+.01):base;
 }
 function loanProbability(base,decision){
   if(!decision)return base;
   return decision.approach==='loan'?Math.min(.97,base+.025):base;
 }
 const api={plan,mayAddPaid,freeProbability,loanProbability,role};
 root.FDTransferStrategy122q=api;
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
