/* Football Dynasty 1.20b — career progression for global-club signings.
   Pure window/lineup policies: no artificial appearances, no fictitious matches.
   Review actual recorded minutes; rotate comparable players; arrange real loans. */
(function(root){
'use strict';
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
function hash(s){let h=2166136261;for(const ch of String(s)){h=Math.imul(h^ch.charCodeAt(0),16777619);}return h>>>0;}
const roll=s=>hash(s)/4294967296;
function family(p){const pos=String(p?.positions?.[0]||p?.position||'').toUpperCase();
 if(pos.includes('GK'))return 'GK';if(/^(CB|LB|RB|LWB|RWB|LCB|RCB|DEF)/.test(pos))return 'DEF';
 if(/^(LW|RW|LM|RM|LF|RF)/.test(pos))return 'WIDE';if(/^(ST|CF|FW|SS)/.test(pos))return 'ST';return 'MID';}
const isImported=p=>Boolean(p?.shadowAcademy116&&p?.shadowSignedSeason117&&!p.retired);
const isSecondChance=p=>Boolean(p?.secondChanceCareer121p&&!p.retired&&Number(p?.age)>=18&&Number(p?.age)<=26);
const needsMinutes=p=>Boolean((isImported(p)||isSecondChance(p))&&Number(p?.age)<=26);
// A live, pending placement can receive fair rotation priority only at its host.
const pendingPlacement121t=p=>Boolean(p?.secondChancePlacement121s?.outcome==='Pending'&&p.secondChancePlacement121s.toClubId===p.clubId&&Number(p.age)>=18&&Number(p.age)<=25);
// Validated near-equivalent AI rotation. No change to a human manager's XI.
function rotateAI({players=[],assignments={},slots=[],fixtureSeed='',clubId='',year=2026}={}){
 const valid=players.filter(p=>p&&!p.retired&&!p.injuryDays&&(p.registrationGroup==='Senior'||(p.registrationGroup==='U21'&&Number(p.age)>=17&&Number(p.age)<=21&&Number(p.overall)>=67&&Number(p.development?.potentialMax||0)>=84))&&(!p.parentClubId||p.clubId!==p.parentClubId)&&p.clubId===clubId);
 if(valid.length<12)return {assignments,rotated:null};
 const sorted=valid.map(p=>Number(p.overall||0)).sort((a,b)=>b-a);
 const typical=Number(sorted[Math.min(10,sorted.length-1)]||67);
 const minRotation=clamp(Math.round(typical-10),52,67);
 const ids=new Set(Object.values(assignments)),selected=valid.filter(p=>needsMinutes(p)&&!ids.has(p.id)&&Number(p.overall)>=minRotation&&Number(p.age)<=26&&Number(p.development?.potentialMax||p.overall)>=Math.max(66,typical-4));
 const possibilities=[];
 for(const p of selected){
   const potential=Number(p.development?.potentialMax||p.overall),role=String(p.shadowCareerPath119||'');
   const allowedGap=isSecondChance(p)&&typical<75?10:role==='First team'?5:role==='Rotation'?5:potential>=90&&Number(p.age)<=21?8:potential>=85&&Number(p.age)<=23?6:3;
   for(const [key,position] of slots){const incumbent=valid.find(q=>q.id===assignments[key]);if(!incumbent||family(incumbent)!==family(p))continue;
     const natural=Array.isArray(p.positions)&&p.positions.includes(position),incNatural=incumbent.positions?.includes(position);
     if(!natural||!incNatural)continue;const gap=Number(incumbent.overall)-Number(p.overall);
     if(gap>allowedGap||gap< -4)continue;
     const mins=Number(p.seasonStats?.year)===Number(year)?Number(p.seasonStats.overall?.minutes||0):Number(p.seasonMinutes||0);
     const chance=clamp(.21+Math.max(0,850-mins)/850*.18+(role==='First team'?.07:0)+(isSecondChance(p)?.07:0)+(gap<=0?.09:0)
       +(pendingPlacement121t(p)&&gap<=8&&mins<850?.14:0),.13,.65);
     if(roll(`${fixtureSeed}|rotate|${clubId}|${p.id}`)>=chance)continue;
     possibilities.push({p,key,incumbent,gap,mins,score:gap*2+mins/350
       -(pendingPlacement121t(p)&&gap<=8&&mins<850?4:0)+roll(`${fixtureSeed}|rank|${p.id}`)});
   }
 }
 if(!possibilities.length)return {assignments,rotated:null};
 possibilities.sort((a,b)=>a.score-b.score||String(a.p.id).localeCompare(String(b.p.id)));
 const best=possibilities[0];return {assignments:{...assignments,[best.key]:best.p.id},rotated:{playerId:best.p.id,replacedId:best.incumbent.id,slot:best.key}};
}
// 1.21f: deterministic AI substitutions for REAL simulated AI fixtures only.
// Planning a sub NEVER changes stats; the match ledger grants minutes only once
// the fixture completes. Keep the human manager's bench and tactical control intact.
function planLiteSubs({players=[],starters=[],fixtureSeed='',clubId='',year=2026}={}){
 const ids=new Set(starters.map(p=>p.id));
 const available=players.filter(p=>p&&p.clubId===clubId&&!p.retired&&!p.injuryDays&&!p.profilePending&&
   (p.registrationGroup==='Senior'||(p.registrationGroup==='U21'&&Number(p.age)>=17&&Number(p.age)<=21&&Number(p.overall)>=67&&Number(p.development?.potentialMax||0)>=84))&&
   !(p.transferType==='Loan'&&p.parentClubId===clubId)&&!ids.has(p.id));
 const sorted=players.filter(p=>p.clubId===clubId&&!p.retired).map(p=>Number(p.overall||0)).sort((a,b)=>b-a);
 const typical=Number(sorted[Math.min(10,sorted.length-1)]||67);
 const minSub=clamp(Math.round(typical-11),51,65),minPotential=typical<68?72:78;
 const imported=available.filter(p=>needsMinutes(p)&&Number(p.age)<=26&&Number(p.overall)>=minSub&&Number(p.development?.potentialMax||p.overall||0)>=(isSecondChance(p)&&typical<75?Math.max(65,typical-5):minPotential));
 const proposals=[];
 for(const p of imported){
   const potential=Number(p.development?.potentialMax||p.overall),role=String(p.shadowCareerPath119||'');
   for(const starter of starters){
     const out=players.find(x=>x.id===starter.id);if(!out||family(out)!==family(p)||family(out)==='GK')continue;
     const natural=(p.positions||[]).includes(starter.position)||(p.positions||[]).some(pos=>(out.positions||[]).includes(pos));
     if(!natural)continue;
     const gap=Number(out.overall)-Number(p.overall);
     const maxGap=isSecondChance(p)&&typical<75?14:role==='First team'?10:potential>=90?12:potential>=85?10:7;
     if(gap>maxGap||gap< -5)continue;
     const minutes=Number(p.seasonStats?.year)===Number(year)?Number(p.seasonStats.overall?.minutes||0):Number(p.seasonMinutes||0);
     const chance=clamp(.25+(potential>=90?.10:0)+(isSecondChance(p)?.10:0)+(minutes<600?.12:0)+(gap<=3?.10:0)
       +(pendingPlacement121t(p)&&minutes<800&&gap<=10?.13:0),.20,.75);
     if(roll(`${fixtureSeed}|lite-sub|${p.id}|${starter.id}`)>=chance)continue;
     const score=gap*2+Math.max(0,minutes)/450-(potential>=90?3:0)
       -(pendingPlacement121t(p)&&minutes<800&&gap<=10?4:0)+roll(`${fixtureSeed}|sub-score|${p.id}`);
     proposals.push({inId:p.id,outId:starter.id,position:starter.position,score});
   }
 }
 proposals.sort((a,b)=>a.score-b.score||String(a.inId).localeCompare(String(b.inId)));
 const usedIn=new Set(),usedOut=new Set(),results=[];
 for(const row of proposals){
   if(usedIn.has(row.inId)||usedOut.has(row.outId))continue;
   usedIn.add(row.inId);usedOut.add(row.outId);
   const minute=62+Math.floor(roll(`${fixtureSeed}|sub-minute|${row.inId}`)*17);
   results.push({...row,minute});if(results.length>=2)break;
 }
 return results.sort((a,b)=>a.minute-b.minute||String(a.inId).localeCompare(String(b.inId)));
}
// Perform in January and May, using the game's actual finished-match ledger.
function review({players=[],clubs=[],date='',protectedClubId=''}={}){
 if(!/^\d{4}-(01|05)-01$/.test(date))return [];
 const byClub=new Set(clubs.map(c=>c.id)),year=Number(date.slice(0,4)),january=date.slice(5,7)==='01';
 const changed=[];
 for(const p of players){if(!isImported(p)||p.clubId===protectedClubId||!byClub.has(p.clubId)||p.shadowReviewDate120===date)continue;
   if(p.transferType==='Loan'||p.parentClubId)continue;
   const mins=Number(p.seasonStats?.year)===year-1?Number(p.seasonStats.overall?.minutes||0):Number(p.seasonMinutes||0);
   // Career season begins in July; seasonStats.year is seasonYear(currentDate), i.e. previous calendar year in January and May.
   const minutes=Math.max(0,Number.isFinite(mins)?mins:0),age=Number(p.age)||25,potential=Number(p.development?.potentialMax||p.overall),ovr=Number(p.overall)||60;
   const recentArrival=Number(p.shadowSignedSeason117)>=year&&january;
   const target=january?(age<=23?320:420):(age<=23?880:1100);
   const needsLoan=age<=23&&potential>=Math.max(73,ovr+4)&&ovr>=54&&minutes<target*.65&&!recentArrival;
   const status=minutes>=target?'Regular contributor':minutes>=target*.45?'Rotation minutes':age<=23?'Needs playing time':'Limited minutes';
   p.shadowReviewDate120=date;p.shadowCareerStatus120=status;p.shadowSeasonMinutes120=Math.round(minutes);
   p.shadowLoanFlag120=Boolean(needsLoan);p.shadowReviewHistory120=Array.isArray(p.shadowReviewHistory120)?p.shadowReviewHistory120:[];
   p.shadowReviewHistory120.unshift({date,minutes:Math.round(minutes),target,status,loanRecommended:needsLoan,clubId:p.clubId});
   p.shadowReviewHistory120=p.shadowReviewHistory120.slice(0,4);changed.push(p);
 }
 return changed;
}
// 1.21c: estimate depth-chart opportunity rather than comparing only a second-best peer.
// This is a projection, not fabricated match minutes and not a contractual guarantee.
const POSITION_SLOTS={GK:1,CB:2,LB:1,RB:1,LWB:1,RWB:1,DM:1,CDM:1,CM:2,AM:1,CAM:1,LW:1,RW:1,LM:1,RM:1,ST:1,CF:1};
function projectedMinutes(p,roster=[]){
 const positions=(Array.isArray(p?.positions)?p.positions:[p?.position]).filter(Boolean).map(v=>String(v).toUpperCase());
 const natural=positions[0]||'CM',slots=POSITION_SLOTS[natural]||1;
 const others=roster.filter(q=>q&&!q.retired&&q.id!==p.id&&q.registrationGroup==='Senior'&&!q.injuryDays);
 let peers=others.filter(q=>(Array.isArray(q.positions)?q.positions:[q.position]).some(pos=>String(pos).toUpperCase()===natural));
 // When an alternate position is not populated, compare the wider positional family.
 if(!peers.length)peers=others.filter(q=>family(q)===family(p));
 const o=Number(p.overall)||0;
 const stronger=peers.filter(q=>Number(q.overall)>o||(Number(q.overall)===o&&String(q.id)<String(p.id))).length;
 const first=peers.reduce((m,q)=>Math.max(m,Number(q.overall)||0),0);
 const gap=Math.max(0,first-o),n=peers.length;
 const starter=Math.max(0,slots-stronger);
 let minutes=0;
 if(starter>0)minutes=clamp(2300-gap*100,1450,2700);
 else if(stronger===slots)minutes=gap<=3?980:gap<=6?620:gap<=8?360:0;
 else if(stronger===slots+1)minutes=gap<=3?440:gap<=6?210:0;
 // Massive squads can dilute rotation and high OVR disparity destroys realistic chances.
 if(n>slots+4)minutes=Math.round(minutes*.85);
 return Math.max(0,Math.round(minutes));
}
function reviewFailures(p,clubId=p.clubId){
 const hist=Array.isArray(p.shadowReviewHistory120)?p.shadowReviewHistory120:[];
 // May & January of the same season are separate checks, never virtual fixtures.
 return hist.filter(h=>h?.clubId===clubId&&Number(h.minutes)<Number(h.target||800)*.55).length;
}
function recentCareerMove(p,year){
 const recorded=p.shadowLastPermanentReview121b||p.lastPermanentTransferSeason108;
 const found=String(recorded||'').match(/20\d{2}/);
 return found&&Number(year)-Number(found[0])<3;
}
function loanFailedBefore(p,clubId){return (p.shadowFailedLoanClubs121c||[]).includes(clubId);}
// Loan outcomes are evaluated only from actual match minutes at the end of the loan.
function recordLoanReturn(p,year){
 if(!p?.shadowCareerLoanStart121c||p.transferType!=='Loan')return false;
 const begin=Number(p.shadowCareerLoanStartMinutes121c||0);
 const season=p.seasonStats;
 const raw=season&&Number(season.year)>=Number(year)-1?Number(season.overall?.minutes||0):Number(p.seasonMinutes||0);
 const recorded=Math.max(0,Number.isFinite(raw)?raw:0);
 const minutes=Math.max(0,recorded>=begin?recorded-begin:recorded);
 const failed=minutes<500;
 if(failed){p.shadowFailedLoanCount121c=Number(p.shadowFailedLoanCount121c||0)+1;
   const clubs=Array.isArray(p.shadowFailedLoanClubs121c)?p.shadowFailedLoanClubs121c:[];
   p.shadowFailedLoanClubs121c=[...new Set([...clubs,p.clubId])].slice(-12);
 }else p.shadowFailedLoanCount121c=0;
 p.shadowLastLoanResult121c={year:Number(year),minutes,failed,clubId:p.clubId};
 delete p.shadowCareerLoanStart121c;delete p.shadowCareerLoanStartMinutes121c;
 return true;
}
// A real loan, not virtual minutes. Avoid placements that already failed and
// prioritize a permanent sale after two unsuccessful loans.
function loanWindow({players=[],clubs=[],year=2027,month='01',seed='shadow-paths-120',protectedClubId=''}={}){
 if(!['01','07'].includes(String(month)))return [];
 const byId=new Map(clubs.map(c=>[c.id,c])),rosters=new Map(clubs.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired&&rosters.has(p.clubId)&&p.transferType!=='Loan')rosters.get(p.clubId).push(p);
 const candidates=players.filter(p=>isImported(p)&&p.shadowLoanFlag120&&p.transferType!=='Loan'&&!p.parentClubId&&
  p.clubId!==protectedClubId&&rosters.has(p.clubId)&&Number(p.age)>=18&&Number(p.age)<=23&&Number(p.overall)>=54&&
  Number(p.lastYouthLoanSeason112)!==Number(year)&&!p.injuryDays&&Number(p.shadowFailedLoanCount121c||0)<2&&Number(String(p.lastPermanentTransferSeason108||p.shadowSignedSeason117||'0').match(/20\d{2}/)?.[0]||0)<Number(year))
  .sort((a,b)=>Number(b.development?.potentialMax||0)-Number(a.development?.potentialMax||0)||String(a.id).localeCompare(String(b.id)));
 const moves=[],byParent=new Map(),incoming=new Map();
 for(const p of candidates){if(moves.length>= (String(month)==='01'?4:6))break;
  const origin=byId.get(p.clubId),parentRoster=rosters.get(p.clubId)||[];
  if(!origin||parentRoster.length<=16||(byParent.get(origin.id)||0)>=1)continue;
  const ownOpportunity=projectedMinutes(p,parentRoster),currentEvidence=Math.max(0,Number(p.shadowSeasonMinutes120||0)),
    ownBaseline=Math.min(ownOpportunity,currentEvidence*1.25+300),options=[];
  for(const to of clubs){if(to.id===p.clubId||to.id===protectedClubId||to.shadowOnly116||(incoming.get(to.id)||0)>=2||loanFailedBefore(p,to.id))continue;
   const roster=rosters.get(to.id)||[],seniors=roster.filter(q=>q.registrationGroup==='Senior'&&!q.injuryDays);
   if(seniors.length<11)continue;
   const opportunity=projectedMinutes(p,seniors);
   if(opportunity<850||opportunity<ownBaseline+350)continue;
   const score=opportunity/25-(incoming.get(to.id)||0)*7+roll(`${seed}|${year}|${month}|${p.id}|${to.id}`)*5;
   options.push({to,score,opportunity});
  }
  if(!options.length)continue;options.sort((a,b)=>b.score-a.score||a.to.id.localeCompare(b.to.id));
  const destination=options[0].to,fromId=p.clubId;
  const endYear=String(month)==='01'?Number(year):Number(year)+1;
  p.parentClubId=origin.id;p.parentClubName=origin.name;p.clubId=destination.id;p.teamName=destination.name;p.leagueName=destination.league;
  p.transferType='Loan';p.loanStart=String(year)+'-'+String(month)+'-01';p.loanEndYear=endYear;p.loanEnd=`${endYear}-06-30`;
  p.loanOption='None';p.loanRecallClause102='Window recall';p.loanPlayingTime='Rotation / starting opportunities';p.loanDestinationPending=false;
  p.shadowCareerLoanStart121c=`${year}-${month}`;
  p.shadowCareerLoanStartMinutes121c=Number(p.seasonStats?.overall?.minutes||p.seasonMinutes||0);
  p.lastLoanSeason108=String(year);p.lastYouthLoanSeason112=Number(year);p.shadowLoanFlag120=false;p.shadowCareerStatus120='On loan for playing time';
  byParent.set(fromId,(byParent.get(fromId)||0)+1);incoming.set(destination.id,(incoming.get(destination.id)||0)+1);
  rosters.set(fromId,parentRoster.filter(q=>q.id!==p.id));rosters.get(destination.id).push(p);
  moves.push({kind:'ai-loan',shadowCareerLoan120:true,season:String(year),window:String(month)==='01'?'January':'July',playerId:p.id,playerName:p.name,fromClubId:fromId,fromClubName:origin.name,toClubId:destination.id,toClubName:destination.name,toLeague:destination.league,fee:0,loanEndYear:endYear,position:p.positions?.[0]||p.position||family(p),projectedMinutes:options[0].opportunity,developmentFit:Math.round(options[0].score),managerStyle:'Youth development',philosophy:'Global talent pathway'});
 }
 moves.touchedPlayerIds097d=moves.map(m=>m.playerId);return moves;
}
// Only AI-managed imported prospects. Buyer must offer more projected minutes,
// not merely have an affordable fee or a slightly worse second-best positional peer.
function permanentWindow({players=[],clubs=[],finances={},year=2027,month='07',seed='career-121c',protectedClubId='',getValue}={}){
 if(!['01','07'].includes(String(month)))return [];
 const byId=new Map(clubs.map(c=>[c.id,c])),rosters=new Map(clubs.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired&&rosters.has(p.clubId)&&p.transferType!=='Loan')rosters.get(p.clubId).push(p);
 const eligible=players.filter(p=>isImported(p)&&p.clubId!==protectedClubId&&rosters.has(p.clubId)&&p.transferType!=='Loan'&&!p.parentClubId&&!p.injuryDays&&Number(p.age)>=18&&Number(p.age)<=25&&Number(p.overall)>=55&&Number(p.development?.potentialMax||0)>=74&&Number(p.shadowSignedSeason117||0)<Number(year)-1&&!recentCareerMove(p,year));
 eligible.sort((a,b)=>String(a.id).localeCompare(String(b.id)));
 const moves=[],departures=new Set(),arrivals=new Map();
 for(const p of eligible){
  if(moves.length>= (String(month)==='07'?8:4))break;
  if(reviewFailures(p)<2||departures.has(p.clubId)||p.shadowCareerStatus120==='Regular contributor')continue;
  const from=byId.get(p.clubId),roster=rosters.get(p.clubId);
  if(!from||roster.length<=17)continue;
  const currentProjection=projectedMinutes(p,roster),recentMinutes=Math.max(0,Number(p.shadowSeasonMinutes120)||0),
    currentEvidence=Math.min(currentProjection,recentMinutes*1.5+450);
  const value=typeof getValue==='function'?Number(getValue(p,year)):Math.max(1,Number(p.overall)-58)*.5;
  if(!Number.isFinite(value)||value<=0)continue;
  const price=Math.round(clamp(value*.80,1,150)*10)/10;
  const visited=new Set([...(p.shadowVisitedClubs121c||[]),from.id]);
  const options=[];
  for(const to of clubs){
   if(to.id===from.id||to.id===protectedClubId||to.shadowOnly116||!rosters.has(to.id)||(arrivals.get(to.id)||0)>=1||visited.has(to.id))continue;
   const target=rosters.get(to.id),cash=finances[to.id];
   if(target.length<16||!cash||Number(cash.budget)<price*1.3)continue;
   const opportunity=projectedMinutes(p,target);
   if(opportunity<700||opportunity<currentEvidence+250||opportunity<Math.min(1000,recentMinutes+250))continue;
   const score=opportunity/40+Math.min(10,(Number(cash.budget)-price)/10)+roll(`${seed}|${year}|${p.id}|${to.id}`)*5;
   options.push({to,score,opportunity});
  }
  if(!options.length)continue;
  options.sort((a,b)=>b.score-a.score||String(a.to.id).localeCompare(String(b.to.id)));
  const choice=options[0],to=choice.to,cash=finances[to.id],seller=finances[from.id];
  cash.budget=Math.round((Number(cash.budget)-price)*10)/10;
  cash.spent=Math.round((Number(cash.spent||0)+price)*10)/10;
  if(seller){seller.budget=Math.round((Number(seller.budget||0)+price)*10)/10;seller.income=Math.round((Number(seller.income||0)+price)*10)/10;}
  p.clubId=to.id;p.teamName=to.name;p.leagueName=to.league;p.transferType='Permanent';
  p.shadowCareerStatus120='Permanent move for first-team football';p.shadowLastPermanentReview121b=Number(year);p.shadowLoanFlag120=false;
  p.shadowVisitedClubs121c=[...visited,to.id].slice(-20);p.shadowFailedLoanCount121c=0;
  p.lastPermanentTransferSeason108=String(year);p.lastTransferSeason=String(year);p.lastTransferWindow=String(month);
  p.clubTenure073=0;p.wantsMove=false;p.transferListed=false;
  // Previous-club reviews cannot be reinterpreted as poor minutes at the new club.
  p.shadowReviewHistory120=[];p.shadowSeasonMinutes120=0;
  departures.add(from.id);arrivals.set(to.id,(arrivals.get(to.id)||0)+1);
  rosters.set(from.id,roster.filter(q=>q.id!==p.id));rosters.get(to.id).push(p);
  moves.push({kind:'ai-permanent',shadowCareerPermanent121b:true,shadowCareerOpportunity121c:true,playerId:p.id,playerName:p.name,fromClubId:from.id,fromClubName:from.name,toClubId:to.id,toClubName:to.name,toLeague:to.league,fee:price,season:String(year),window:String(month)==='01'?'January':'July',date:`${year}-${month}-01`,position:p.positions?.[0]||p.position||family(p),projectedMinutes:choice.opportunity,previousProjectedMinutes:currentProjection,managerStyle:'Youth development',philosophy:'First-team opportunity',reason:'Blocked wonderkid seeking first-team minutes'});
 }
 moves.touchedPlayerIds097d=moves.map(m=>m.playerId);return moves;
}
const api=Object.freeze({rotateAI,planLiteSubs,review,loanWindow,permanentWindow,isImported,family,projectedMinutes,recordLoanReturn});
root.FDShadowPaths120=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
