/* Football Dynasty 1.22j: evidence-based loan opportunity decisions.
   Runs at windows; the existing match engine alone awards appearances and minutes. */
(function(root){'use strict';
const squad=root.FDSquadIntelligence122g||(typeof module!=='undefined'?require('./squad-intelligence-122g.js'):null);
const num=x=>Number.isFinite(Number(x))?Number(x):0;
const floor={GK:2,DEF:5,MID:4,WIDE:2,ST:2},target={GK:2,DEF:7,MID:5,WIDE:5,ST:3};
const senior=p=>Boolean(p&&!p.retired&&!p.profilePending&&p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.squadStatus!=='Academy'&&p.transferType!=='Loan');
const age=p=>num(p?.age||p?.simulationAge071g)||25;
function candidate({player,source=[],year=2027,protectedClubId='',sourceId=''}={}){
 const p=player;if(!p||!p.id||p.retired||p.profilePending||p.transferType==='Loan'||p.clubId==='free-agent'||
   p.clubId===protectedClubId||p.clubId!==sourceId||age(p)<18||age(p)>23||num(p.overall)<46||num(p.overall)>75||
   !source.some(x=>x.id===p.id)||num(p.youthOpportunity122j?.year)>=num(year)||
   String(p.lastLoanSeason108||'').includes(String(year))||String(p.lastTransferSeason||'').includes(String(year)))return {allowed:false,reason:'not available'};
 const group=squad.family(p),members=source.filter(q=>q.id!==p.id&&senior(q)&&squad.family(q)===group);
 const seniors=source.filter(senior),stronger=members.filter(q=>num(q.overall)>=num(p.overall)+2).length;
 const homeRemaining=members.length; // never remove the only viable emergency cover
 if(seniors.length<16||stronger<2||homeRemaining<floor[group])return {allowed:false,reason:'needed home cover'};
 const previous=num(p.careerHistory076?.[0]?.minutes||p.seasonMinutes);
 const flagged=p.secondChanceLoanPriority121r||p.graduateReview122i?.action==='Seek loan opportunity'||p.returnReview122i?.action==='Consider another loan';
 if(previous>=650||(!flagged&&previous>=400))return {allowed:false,reason:'already receiving minutes'};
 const failed=(p.youthOpportunityHistory122j||[]).filter(x=>x.outcome==='Blocked').length;
 if(failed>=3&&!flagged)return {allowed:false,reason:'repeat failed loans need another plan'};
 return {allowed:true,group,minutes:previous,flagged:Boolean(flagged),stronger,score:(flagged?24:0)+Math.min(22,stronger*5)+Math.max(0,400-previous)/55+(p.registrationGroup==='U21'?7:0)};
}
function destination({player,receiving=[],tier=3,year=2027,hostId='',lastHosts=[]}={}){
 if(!player||!hostId||player.clubId===hostId||tier<2||lastHosts.includes(hostId))return {allowed:false,reason:'invalid host'};
 const group=squad.family(player),report=squad.inspect(receiving,year),role=report.groups[group];
 const effective=role.count+role.academyReady;
 if(report.seniorCount>29||effective>=target[group]||role.blocked>=3)return {allowed:false,reason:'no genuine vacancy'};
 // A loan is a viable player, not a new guaranteed starter. Guard impossible level jumps.
 const strength=role.players.slice().sort((a,b)=>num(b.overall)-num(a.overall));
 const typical=num(strength[Math.min(1,strength.length-1)]?.overall||strength[0]?.overall||0);
 if(typical&&num(player.overall)<typical-(tier>=3?10:8))return {allowed:false,reason:'not competitive with host depth'};
 if(num(player.overall)<(tier>=3?49:56))return {allowed:false,reason:'below match-ready ability'};
 const score=Math.max(0,target[group]-effective)*12+Math.max(0,floor[group]-effective)*30+
  Math.max(-8,Math.min(12,num(player.overall)-typical))+Math.min(8,Math.max(0,24-report.seniorCount));
 return {allowed:true,reason:'real host vacancy',group,score,seniorCount:report.seniorCount,roleCount:effective,typical};
}
function rotationReady({player,receiving=[],tier=3}={}){
 if(!player||squad.family(player)==='GK'||num(player.overall)<(tier>=3?49:tier===2?55:65))return false;
 const group=squad.family(player),needed={GK:1,DEF:4,MID:3,WIDE:2,ST:1}[group];
 const starters=receiving.filter(p=>p&&!p.retired&&!p.profilePending&&squad.family(p)===group)
   .sort((a,b)=>num(b.overall)-num(a.overall)).slice(0,needed);
 if(starters.length<1)return true; // useful in an actual understrength XI
 const lowest=num(starters[starters.length-1].overall),gap=lowest-num(player.overall);
 return gap<=(tier>=3?11:tier===2?9:6)&&gap>=-8;
}
function reviewOutcomes({players=[],returns=[],year=2027}={}){
 const index=new Map(players.map(p=>[p.id,p]));const events=[];
 for(const row of returns){const p=index.get(row.playerId),m=p?.youthOpportunity122j;
  if(!m||!m.year||m.toClubId!==row.fromClubId||m.fromClubId!==row.toClubId||
    (p.youthOpportunityHistory122j||[]).some(x=>x.year===m.year&&x.toClubId===m.toClubId))continue;
  // 1.22l: winter loanees may have played for their parent before moving.
  // Review ONLY minutes earned after the loan move, not their full-season total.
  const minutes=Math.max(0,Math.round(num(p.seasonMinutes)-num(m.minutesAtArrival))),outcome=minutes>=700?'Established':minutes>=200?'Rotation':'Blocked';
  const e={year:m.year,reviewYear:num(year),fromClubId:m.fromClubId,toClubId:m.toClubId,minutes,outcome};
  p.youthOpportunityHistory122j=[...(p.youthOpportunityHistory122j||[]),e].slice(-5);
  p.youthOpportunity122j={...m,status:'Returned',lastOutcome:outcome,verifiedLoanMinutes:minutes};
  events.push({playerId:p.id,...e});
 }
 return events;
}
root.FDYouthOpportunities122j={candidate,destination,rotationReady,reviewOutcomes};
if(typeof module!=='undefined'&&module.exports)module.exports=root.FDYouthOpportunities122j;
})(typeof window!=='undefined'?window:globalThis);
