/* Football Dynasty 1.22l: don't loan over match-ready home prospects.
 * This module only ranks eligibility and rotation; it never awards minutes. */
(function(root){'use strict';
const squad=root.FDSquadIntelligence122g||(typeof module!=='undefined'?require('./squad-intelligence-122g.js'):null);
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const ready={2:55,3:49};
function homeProspects({player,receiving=[],tier=3}={}){
 if(!player)return [];
 const family=squad.family(player), min=tier>=3?ready[3]:tier===2?ready[2]:65;
 return receiving.filter(p=>p&&p.id!==player.id&&!p.retired&&!p.profilePending&&p.transferType!=='Loan'&&
   squad.family(p)===family&&n(p.age)>=17&&n(p.age)<=23&&n(p.overall)>=min&&
   n(p.overall)>=n(player.overall)-5&&n(p.seasonMinutes)<600&&
   (p.registrationGroup==='U21'||p.registrationGroup==='Academy'||p.dataQuality==='generated'||
    p.graduateReview122i?.action==='First-team pathway'||p.graduateReview122i?.action==='Seek loan opportunity'));
}
function destinationReview({player,receiving=[],tier=3,roleCount=0,roleFloor=0,roleTarget=0}={}){
 const candidates=homeProspects({player,receiving,tier});
 // The club can still recruit for an actual floor deficiency; avoid filling
 // a nominal rotation slot when an equivalent home youngster is available.
 if(candidates.length&&n(roleCount)>=Math.max(n(roleFloor),n(roleTarget)||n(roleFloor)))return {allowed:false,reason:'homegrown prospect deserves existing minutes',blockedBy:candidates.map(p=>p.id)};
 return {allowed:true,reason:'no comparably ready homegrown option',blockedBy:[]};
}
function loanPriority({player,eligible=[],tier=3,minutes=0}={}){
 if(!player||player.transferType!=='Loan'||!player.youthOpportunity122j||player.youthOpportunity122j.toClubId!==player.clubId)return 0;
 const rivals=homeProspects({player,receiving:eligible,tier});
 if(rivals.length)return 0;
 return Math.max(0,Math.min(3.6,1.1+(600-n(minutes))/360));
}
function homePriority({player,tier=3,minutes=0,incumbent=null}={}){
 if(!player||n(player.age)>23||n(player.age)<17||player.transferType==='Loan'||
 !(player.registrationGroup==='U21'||player.registrationGroup==='Academy'||player.dataQuality==='generated'))return 0;
 if(n(minutes)>=650||n(player.overall)<(tier>=3?49:tier===2?55:65))return 0;
 if(incumbent&&n(incumbent.overall)-n(player.overall)>(tier>=3?8:tier===2?7:5))return 0;
 return Math.min(3.2,1.2+(650-n(minutes))/340);
}
const api={homeProspects,destinationReview,loanPriority,homePriority};root.FDYouthMinuteBalance122l=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
