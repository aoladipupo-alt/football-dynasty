/* Football Dynasty 1.22g — squad-aware recruitment, no daily scans.
   Pure decision layer: does not move players, invent match minutes, edit
   finances or manage the user club. Uses only recorded playing time. */
(function(root){'use strict';
const num=x=>Number.isFinite(Number(x))?Number(x):0;
const family=(p)=>{const s=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();
 if(s==='GK')return 'GK';if(['CB','LB','RB','LWB','RWB','WB','SW'].includes(s))return 'DEF';
 if(['DM','CDM','CM'].includes(s))return 'MID';if(['AM','CAM','LW','RW','LM','RM'].includes(s))return 'WIDE';return 'ST';};
const ORDER=['GK','DEF','MID','WIDE','ST'];
// A rotation-sized senior team; hard registration limits still come from FDWorld.
const targets={GK:2,DEF:7,MID:5,WIDE:5,ST:3};
const floors={GK:2,DEF:5,MID:4,WIDE:2,ST:2};
function countable(p){return Boolean(p&&!p.retired&&!p.profilePending&&p.clubId&&p.clubId!=='free-agent'&&p.squadStatus!=='Academy'&&p.registrationGroup!=='Academy'&&p.registrationGroup!=='U21'&&!(p.transferType==='Loan'&&p.loanDestinationPending));}
function inspect(roster=[],year=2027){
 const rows=Array.isArray(roster)?roster:[],by={GK:[],DEF:[],MID:[],WIDE:[],ST:[]};
 const u21={GK:[],DEF:[],MID:[],WIDE:[],ST:[]};
 for(const p of rows){if(!p||p.retired||p.profilePending||!(num(p.overall)>0))continue;
  const f=family(p);if(countable(p))by[f].push(p);
  else if((p.registrationGroup==='U21'||p.squadStatus==='Academy')&&p.transferType!=='Loan'&&
   num(p.seasonMinutes)>=650&&num(p.age||p.simulationAge071g)>=17)u21[f].push(p);
 }
 const groups={};let seniorCount=0,underusedYoung=0;
 for(const f of ORDER){const squad=by[f].sort((a,b)=>num(b.overall)-num(a.overall));seniorCount+=squad.length;
  const ready=u21[f].filter(p=>num(p.overall)>=num(squad[Math.min(1,squad.length-1)]?.overall||p.overall)-8).sort((a,b)=>num(b.overall)-num(a.overall));
  const top=squad.slice(0,f==='GK'?1:2),baseline=top.length?top.reduce((s,p)=>s+num(p.overall),0)/top.length:0;
  const age=top.length?top.reduce((s,p)=>s+num(p.age||p.simulationAge071g||year-2001),0)/top.length:25;
  const blocked=squad.filter(p=>num(p.age||p.simulationAge071g)<=23&&num(p.seasonMinutes)<450&&num(p.development?.potentialMax)>num(p.overall)+6).length;
  underusedYoung+=blocked;
  groups[f]={count:squad.length,academyReady:Math.min(1,ready.length),readyIds:ready.slice(0,1).map(p=>p.id),target:targets[f],floor:floors[f],coreOverall:baseline,coreAge:age,blocked,players:squad};
 }
 return {seniorCount,groups,underusedYoung};
}
function plan(roster=[],year=2027){
 const report=inspect(roster,year),all=ORDER.flatMap(f=>report.groups[f].players);
 const baseline=all.length?all.slice().sort((a,b)=>num(b.overall)-num(a.overall))[Math.min(10,all.length-1)].overall:60;
 return ORDER.map(group=>{const m=report.groups[group],effective=m.count+m.academyReady;
  const short=Math.max(-4,m.target-effective),danger=Math.max(0,m.floor-effective);
  const qualityGap=m.coreOverall?Math.max(0,num(baseline)-m.coreOverall):10;
  const aging=Math.max(0,m.coreAge-(group==='GK'?32:29));
  const urgency=danger*27+Math.max(0,short)*10+qualityGap*1.4+aging*1.4;
  const congestion=Math.max(0,-short)*13+m.blocked*4;
  return {group,short,qualityGap,avgAge:m.coreAge,priority:Math.round((urgency-congestion)*10)/10,
    seniorCount:m.count,academyCover:m.academyReady,underused:m.blocked};
 }).sort((a,b)=>b.priority-a.priority||ORDER.indexOf(a.group)-ORDER.indexOf(b.group));
}
function evaluate({roster=[],candidate=null,year=2027,tier=1,report=null}={}){
 if(!candidate||candidate.retired||candidate.profilePending||num(candidate.overall)<=0)return {allowed:false,reason:'invalid player',score:-100};
 report=report||inspect(roster,year);const group=family(candidate),m=report.groups[group],age=num(candidate.age||candidate.simulationAge071g)||24;
 const hardCap=tier>=3?36:tier===2?35:34;
 const effective=m.count+m.academyReady,need=Math.max(0,m.target-effective),urgent=effective<m.floor;
 const sorted=m.players,benchmark=num(sorted[Math.min(1,sorted.length-1)]?.overall||sorted[0]?.overall||0);
 const starterUpgrade=sorted.length>0&&num(candidate.overall)>=num(sorted[0].overall)+4;
 const rotationUpgrade=sorted.length>0&&num(candidate.overall)>=num(sorted[sorted.length-1].overall)+5;
 const usefulDepth=effective<m.target+2&&num(candidate.overall)>=benchmark-(group==='GK'?13:11);
 const crowded=effective>=m.target+1||(!urgent&&m.blocked>=3&&age<=23&&effective>=m.target+1);
 const overfull=report.seniorCount>=hardCap+(urgent?1:0);
 const mismatch=Boolean(!urgent&&effective>=m.target&&benchmark&&num(candidate.overall)<benchmark-13);
 const exceptionalVacancy=starterUpgrade&&effective<m.target+3&&report.seniorCount<=28;
 // Normal recruitmentBand, interest and budget rules already screen ability.
 // This layer only vetoes genuinely crowded positional groups or untenable
 // overstock; it must not freeze clubs that need an affordable reserve.
 const allowed=!overfull&&!mismatch&&(!crowded||exceptionalVacancy);
 const reasons=overfull?'registration cap':mismatch?'quality too low':crowded&&!starterUpgrade?'positional congestion':allowed?'squad improvement':'no playing-time opportunity';
 const score=Math.max(-35,Math.min(35,need*9+Math.max(0,m.floor-effective)*12+(starterUpgrade?15:0)-m.blocked*4-Math.max(0,effective-m.target)*10));
 return {allowed,reason:reasons,score,group,seniorCount:report.seniorCount,urgency:urgent,academyCover:m.academyReady,underused:m.blocked};
}
function safeToSell(roster=[],p,year=2027){
 if(!p||!countable(p))return false;
 const report=inspect(roster,year),m=report.groups[family(p)];
 const remaining=m.players.filter(x=>x.id!==p.id),effective=remaining.length+m.academyReady;
 if(effective<m.floor)return false;
 // Do not displace a club's only strong keeper or the only viable striker.
 if((family(p)==='GK'||family(p)==='ST')&&remaining.length&&!remaining.some(x=>num(x.overall)>=num(p.overall)-12))return false;
 return true;
}
// Severe congestion applies to specialized feeder/upward systems too.
// These systems have separate scouting checks but cannot bypass squad size indefinitely.
function severeCongestion(roster=[],candidate=null,year=2027){
 if(!candidate)return false;const g=inspect(roster,year).groups[family(candidate)];
 return g.count+g.academyReady>=g.target+4;
}
// A bounded rotation opportunity bonus; never overrides positional or OVR
// requirements, and never awards minutes outside the match selector.
function rotationPriority({player,minutes=0,incumbent=null,tier=1}={}){
 if(!player||!incumbent||num(player.age||player.simulationAge071g)<18||num(player.age||player.simulationAge071g)>23)return 0;
 const ability=num(player.overall),ceiling=num(player.development?.potentialMax||ability),gap=num(incumbent.overall)-ability;
 if(gap>(tier>=3?11:tier===2?9:6)||gap< -8||ceiling<ability+5)return 0;
 const chance=Math.max(0,(720-num(minutes))/720),youth=player.registrationGroup==='U21'?1.4:.55;
 return Math.round(Math.min(4.2,(youth+Math.min(1.9,(ceiling-ability)*.11))*chance)*100)/100;
}
const api={family,inspect,plan,evaluate,safeToSell,severeCongestion,rotationPriority,targets,floors};
root.FDSquadIntelligence122g=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
