# Football Dynasty 1.23a — Save and Transfer Integrity

Based on 1.22z. This maintenance update strengthens the human transfer-registration pathway and the save-manager's Continue button.

- Rechecks current annual payroll when completing a permanent transfer, even if the player had agreed personal terms earlier. If the squad is now over the 108% hard limit, the agreement reopens with a wage-budget explanation; the transfer does not charge cash, move the player, or write completion history.
- Prevents an interrupted/suspended animation-frame callback from leaving Continue stuck at 'OPENING CAREER…'. The UI paint uses a capped 160 ms fallback.
- Updates service-worker and runtime request versions so installed copies load the patched code.

**Validated:** controlled Chromium transfer registration (10 assertions); 14 selected Node regression scripts, including a 20-year lower-league rebuild; 3 frame-suspension tests. Compiled database loaded 3,886 players on a fresh career. No page errors in the transfer test.

**Not established:** fully negotiated club acceptance through both parties and a full multi-season cold-save reopen. An isolated cold-continue harness still stalls after clicking Continue; do not regard that as verified save-load resolution. Existing saves are not intentionally migrated or reset by these changes. Back up a career before updating.
