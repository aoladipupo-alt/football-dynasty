/* Football Dynasty 1.22d — vacancy-led lower division squad rebuilding.
   Uses EXISTING unemployed players; no generated transfers, appearance records,
   forced exits, imaginary revenue, or user-club signings. Deterministic July only. */
(function(root){'use strict';
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const r=x=>Math.round(x*100)/100;
const role=p=>{const s=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();return s==='GK'?'GK':/^(CB|LB|RB|LWB|RWB|SW)/.test(s)?'DEF':/^(LW|RW|LM|RM)/.test(s)?'WIDE':/^(ST|CF|LF|RF)/.test(s)?'ST':'MID';};
const preferred={GK:3,DEF:8,MID:7,WIDE:5,ST:4};
const quality={2:[57,77],3:[49,70],4:[45,66]};
const wageCeiling={2:18,3:9,4:5}; // weekly thousands; no disguised salary reductions
function tier(c,getTier){return Math.max(1,Math.min(4,n(getTier(c))||1));}
function available(p,year){return Boolean(p&&p.id&&!p.retired&&!p.profilePending&&p.clubId==='free-agent'&&!p.parentClubId&&p.transferType!=='Loan'&&n(p.age)>=18&&n(p.age)<=34&&n(p.overall)>=45&&n(p.overall)<=79&&(!p.shadowAcademy116||p.shadowSignedSeason117)&&String(p.lastTransferWindow||'')!==`${year}-07`);}
function summary(roster){
 const seniors=roster.filter(x=>x&&!x.retired&&x.registrationGroup!=='U21'&&x.registrationGroup!=='Academy'&&x.squadStatus!=='Academy'&&x.transferType!=='Loan'&&!x.parentClubId);
 const peers={GK:[],DEF:[],MID:[],WIDE:[],ST:[]};
 for(const p of seniors)peers[role(p)].push(p);
 for(const a of Object.values(peers))a.sort((x,y)=>n(y.overall)-n(x.overall));
 const median=seniors.length?seniors.slice().sort((x,y)=>n(y.overall)-n(x.overall))[Math.floor(seniors.length/2)].overall:0;
 return {seniors,peers,median};
}
function need(p,c,roster,getTier,prepared){
 const t=tier(c,getTier),bounds=quality[t];if(!bounds||n(p.overall)<bounds[0]||n(p.overall)>bounds[1])return null;
 const {seniors,peers:byRole,median}=prepared||summary(roster);
 // No bloated 35+ senior rosters or mass free-agent stockpiling.
 if(seniors.length>=29)return null;
 const family=role(p),peers=byRole[family];
 const weak=peers.filter(x=>n(x.overall)<n(p.overall)-2).length;
 const missing=Math.max(0,preferred[family]-peers.length);
 const shortage=missing>0||seniors.length<19;
 // If the club is already well-stocked in that role, only genuine squad-quality
 // shortfalls can prompt a move, and only while the full roster is thin.
 if(!shortage||(!missing&&weak===0))return null;
 const rank=peers.filter(x=>n(x.overall)>n(p.overall)+1).length;
 if(rank>=preferred[family]-1)return null;
 const typical=n(peers[Math.min(peers.length-1,Math.max(0,preferred[family]-2))]?.overall)||n(median)||bounds[0]+4;
 if(n(p.overall)<typical-6||n(p.overall)>typical+12)return null;
 const age=n(p.age),pot=n(p.development?.potentialMax)||n(p.overall);
 const upside=age<=23?Math.min(8,Math.max(0,pot-n(p.overall))):0;
 const score=missing*11+Math.max(0,23-seniors.length)*3+Math.max(0,n(p.overall)-typical)*2+Math.min(6,upside)+(weak?2:0);
 return {role:family,score,rank,missing,rosterSize:seniors.length};
}
function run({players=[],clubs=[],finances={},year=2027,month='07',seed='',protectedClubId='',getTier=c=>n(c?.tier)||1,getWage=p=>n(p.wage),getContractLength=()=>3,maxMoves=16,maxPerClub=2}={}){
 const output=[];output.touchedPlayerIds097d=[];
 if(String(month).padStart(2,'0')!=='07'||!Array.isArray(players)||!Array.isArray(clubs))return output;
 const selectedClubs=clubs.filter(c=>c?.id&&c.id!==protectedClubId&&tier(c,getTier)>=2&&tier(c,getTier)<=4&&finances[c.id]);
 const roster=new Map(selectedClubs.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired&&roster.has(p.clubId))roster.get(p.clubId).push(p);
 const pool=players.filter(p=>available(p,year)).sort((a,b)=>n(b.overall)-n(a.overall)||String(a.id).localeCompare(String(b.id)));
 const joined=new Map(),used=new Set(),limit=Math.min(50,Math.max(0,n(maxMoves)));
 const sequence=selectedClubs.slice().sort((a,b)=>{
    const ar=roster.get(a.id)||[],br=roster.get(b.id)||[];
    const as=ar.filter(p=>p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.transferType!=='Loan').length;
    const bs=br.filter(p=>p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.transferType!=='Loan').length;
    return as-bs||String(a.id).localeCompare(String(b.id));
 });
 // Round-robin: a depleted club gets one useful replacement before another
 // club signs a second. All decisions are reproducible across save reloads.
 for(let pass=0;pass<Math.min(3,Math.max(0,n(maxPerClub)));pass++){
  for(const c of sequence){
   if(output.length>=limit)return output;
   if((joined.get(c.id)||0)>pass)continue;
   const f=finances[c.id],current=roster.get(c.id),t=tier(c,getTier);
   if(!f||n(f.wageBudget)<=0)continue;
   const payroll=current.reduce((s,p)=>s+Math.max(0,n(p.wage))*((p.transferType==='Loan')?.026:.052),0);
   const prepared=summary(current);
   const space=(root.FDMarketBalance122f?.limit?.(f)??n(f.wageBudget))*1.015-payroll;
   if(space<=.02)continue;
   let best=null;
   for(const p of pool){if(used.has(p.id))continue;
    const fit=need(p,c,current,getTier,prepared);if(!fit)continue;
    // An established free agent can accept a shorter contract, not an
    // implausible wage slash. Reject unaffordable salary expectations.
    const ask=Math.max(.4,n(p.wage),n(getWage(p,c))||0);
    if(ask>wageCeiling[t]||ask*.052>space)continue;
    // Distinctive, stable tie-breaker only, not random scouting outcomes.
    const age=n(p.age),development=age<=23&&n(p.development?.potentialMax)>n(p.overall)+4?3:0;
    const score=fit.score+development-ask*.9-Math.max(0,age-29)*2+
      (n(p.overall)-(quality[t][0]+quality[t][1])/2)*.4;
    if(!best||score>best.score||score===best.score&&String(p.id).localeCompare(String(best.p.id))<0)best={p,fit,ask,score};
   }
   if(!best)continue;
   const {p,fit,ask}=best,oldAge=n(p.age);
   p.clubId=c.id;p.teamName=c.name;p.leagueName=c.league;
   p.registrationGroup='Senior';p.squadStatus='First Team';p.transferType='Permanent';
   p.parentClubId=null;p.loanEndYear=null;p.loanDestinationPending=false;
   p.wage=r(ask);p.contractUntil=n(year)+Math.max(1,Math.min(4,n(getContractLength(p,c))||2));
   p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=`${year}-07`;
   p.clubTenure073=0;p.freeAgentYears080=0;p.transferListed=false;p.transferListedByFinance=false;p.wantsMove=false;
   if(p.shadowAcademy116&&p.shadowSignedSeason117){p.shadowCareerStatus120='Re-established at senior club';}
   current.push(p);used.add(p.id);joined.set(c.id,(joined.get(c.id)||0)+1);
   const event={kind:'ai-lower-league-rebuild122d',season:String(year),window:'07',playerId:p.id,playerName:p.name,fromClubId:'free-agent',fromClubName:'Free Agent',toClubId:c.id,toClubName:c.name,toLeague:c.league,
     fee:0,position:p.positions?.[0]||p.position||'',managerStyle:'Squad replacement',philosophy:'Funded first-team vacancy',
     opportunity:`${fit.role} position; ${fit.rosterSize} seniors before signing`,rebuildWage122d:r(ask),age119:oldAge};
   output.push(event);output.touchedPlayerIds097d.push(p.id);
  }
 }
 return output;
}
const api={run,need,available};root.FDLowerLeagueRebuild122d=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
