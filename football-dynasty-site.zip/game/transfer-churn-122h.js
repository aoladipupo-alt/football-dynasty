/* Football Dynasty 1.22h: event-time, budget-neutral squad-surplus matching.
   Pure decision helpers. No fabricated minutes, no direct squad mutations. */
(function(root){'use strict';
const squad=root.FDSquadIntelligence122g || (typeof module!=='undefined' ? require('./squad-intelligence-122g.js') : null);
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const caps={GK:2,DEF:7,MID:5,WIDE:5,ST:3};
const floor={GK:2,DEF:5,MID:4,WIDE:2,ST:2};
function senior(p){return Boolean(p&&!p.retired&&!p.profilePending&&p.transferType!=='Loan'&&p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.squadStatus!=='Academy'&&p.clubId&&p.clubId!=='free-agent'&&n(p.overall)>45);}
function sellerAssessment(roster=[],p,year=2027){
 if(!senior(p)||!Array.isArray(roster)||!roster.some(x=>x.id===p.id))return {allowed:false,reason:'unavailable',score:-100};
 const f=squad.family(p),report=squad.inspect(roster,year),group=report.groups[f],size=report.seniorCount,remaining=group.players.filter(x=>x.id!==p.id);
 if(!squad.safeToSell(roster,p,year)||remaining.length<floor[f])return {allowed:false,reason:'essential cover',score:-100};
 const age=n(p.age||p.simulationAge071g)||25,minutes=n(p.seasonMinutes),pot=n(p.development?.potentialMax||p.overall);
 const ranked=group.players.slice().sort((a,b)=>n(b.overall)-n(a.overall)),rank=ranked.findIndex(x=>x.id===p.id);
 const surplus=group.count-caps[f],crowded=surplus>=2,seniorExcess=size>=29&&group.count>floor[f]+1;
 if(!crowded&&!seniorExcess)return {allowed:false,reason:'no surplus',score:-100};
 if(age<=21&&pot>=n(p.overall)+8&&minutes<700)return {allowed:false,reason:'young prospect better loaned',score:-100};
 if(rank<=1 && !p.wantsMove && !p.financialPressureSale)return {allowed:false,reason:'core player',score:-100};
 const fringe=rank>=Math.max(2,group.count-3),lowMinutes=minutes<550;
 if(!fringe&&!p.transferListed&&!p.wantsMove&&!p.financialPressureSale)return {allowed:false,reason:'valuable rotation',score:-100};
 const strongPotential=age<=23&&pot>=n(p.overall)+10;
 const score=(Math.max(0,surplus)*14)+(Math.max(0,size-25)*2)+(fringe?13:0)+(lowMinutes?8:0)+(age>=30?4:0)+(p.transferListed?8:0)+(p.wantsMove?10:0)+(p.financialPressureSale?12:0)-(strongPotential?10:0);
 return {allowed:true,reason:'surplus role with protected cover',score,group:f,seniorCount:size,seniorSurplus:surplus,minutes,fringe};
}
function buyerAssessment(roster=[],p,tier=2,year=2027){
 if(!senior(p)||!Array.isArray(roster))return {allowed:false,reason:'invalid',score:-100};
 const f=squad.family(p),report=squad.inspect(roster,year),group=report.groups[f],effective=group.count+group.academyReady;
 const evaluation=squad.evaluate({roster,candidate:p,tier,year,report});
 if(!evaluation.allowed)return {allowed:false,reason:evaluation.reason,score:-100};
 // Brokerage is for actual openings, not replacing good seniors to stockpile stars.
 if(effective>=caps[f]||report.seniorCount>=29)return {allowed:false,reason:'no sustainable vacancy',score:-100};
 const peers=group.players.slice().sort((a,b)=>n(b.overall)-n(a.overall)),backup=peers[Math.min(1,peers.length-1)]||null;
 const ability=n(p.overall),minOvr=backup?n(backup.overall)-(f==='GK'?13:10):Math.max(46,tier>=3?51:tier===2?58:66);
 if(ability<minOvr)return {allowed:false,reason:'not rotation standard',score:-100};
 const available=effective<floor[f]?2:1;
 return {allowed:true,reason:'genuine rotation vacancy',score:available*21+(caps[f]-effective)*10+Math.min(12,Math.max(0,ability-n(backup?.overall||ability))),group:f,need:caps[f]-effective,seniorCount:report.seniorCount};
}
function compatible({source=[],destination=[],player,tier=2,year=2027}={}){
 const seller=sellerAssessment(source,player,year);
 if(!seller.allowed)return {allowed:false,reason:'seller: '+seller.reason};
 const buyer=buyerAssessment(destination,player,tier,year);
 if(!buyer.allowed)return {allowed:false,reason:'buyer: '+buyer.reason};
 return {allowed:true,score:seller.score+buyer.score,seller,buyer};
}
root.FDTransferChurn122h={sellerAssessment,buyerAssessment,compatible,senior};
if(typeof module!=='undefined'&&module.exports)module.exports=root.FDTransferChurn122h;
})(typeof window!=='undefined'?window:globalThis);
