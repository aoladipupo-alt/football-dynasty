/* Football Dynasty 1.22m: lightweight, read-only squad health and youth pathway
   insights; no roster writes, manufactured minutes, or extra daily scans. */
(function(root){'use strict';
const sq=root.FDSquadIntelligence122g||(typeof module!=='undefined'?require('./squad-intelligence-122g.js'):null);
const ORDER=['GK','DEF','MID','WIDE','ST'];
const LABEL={GK:'Goalkeepers',DEF:'Defenders',MID:'Central midfield',WIDE:'Wide / attacking mid',ST:'Strikers'};
const n=x=>Number.isFinite(Number(x))?Number(x):0;
function report({players=[],year=2027}={}){
 const rows=Array.isArray(players)?players.filter((p,i,all)=>p&&all.findIndex(q=>q===p||q?.id&&q.id===p.id)===i):[];
 const seniors=rows.filter(p=>p&&!p.retired&&!p.profilePending&&p.clubId&&p.clubId!=='free-agent'&&p.registrationGroup!=='Academy'&&p.registrationGroup!=='U21'&&p.squadStatus!=='Academy');
 const youth=rows.filter(p=>p&&!p.retired&&!p.profilePending&&n(p.age||p.simulationAge071g)<=23&&n(p.age||p.simulationAge071g)>=16&&p.transferType!=='Loan');
 const m=sq.inspect(rows,year).groups;
 // Count actual existing secondary-role options; one player may be versatile
 // but must not be silently counted as TWO registered seniors.
 const secondary=Object.fromEntries(ORDER.map(f=>[f,[]]));
 for(const p of seniors){const native=sq.family(p),unique=new Set((Array.isArray(p.positions)?p.positions:[]).slice(1).map(pos=>sq.family({positions:[pos]})));
  for(const f of unique)if(f!==native)secondary[f].push(p);
 }
 const result=ORDER.map(f=>{
  const g=m[f],shortage=Math.max(0,g.floor-g.count),excess=Math.max(0,g.count-g.target),blocked=youth.filter(p=>sq.family(p)===f&&n(p.seasonMinutes)<450&&n(p.overall)>=45&&n(p.development?.potentialMax||p.overall)>n(p.overall)+5).length;
  // Only report a credible secondary option, never assert an extra starter.
  const flexible=secondary[f].filter(p=>n(p.overall)>=48).sort((a,b)=>n(b.overall)-n(a.overall));
  const status=shortage?'Shortage':excess>=4?'Overcrowded':excess>0?'Surplus':'Balanced';
  const action=shortage?`Recruit ${shortage} viable ${shortage===1?'option':'options'}; ${flexible.length?'review existing versatile cover first':'prioritize this role'}`:
    excess>=4?`Review fringe contracts and ${blocked?'blocked prospects':'loan options'} before signing more`:
    blocked>=2?`Review playing-time paths for ${blocked} young players`:
    excess>0?'Avoid unnecessary depth signings':'Keep competition and development balanced';
  return {group:f,label:LABEL[f],seniors:g.count,target:g.target,floor:g.floor,shortage,excess,blockedYouth:blocked,secondaryOptions:flexible.length,
    versatile: flexible.slice(0,3).map(p=>({id:p.id,name:p.name,positions:p.positions,overall:n(p.overall)})),status,action};
 });
 return {groups:result,seniorCount:seniors.length,shortages:result.reduce((a,x)=>a+x.shortage,0),
 severeOvercrowding:result.filter(x=>x.excess>=4).length,blockedYouth:result.reduce((a,x)=>a+x.blockedYouth,0)};
}
const api={report,ORDER,LABEL};root.FDSquadHealth122m=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
