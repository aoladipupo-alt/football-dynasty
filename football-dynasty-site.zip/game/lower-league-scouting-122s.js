/* Football Dynasty 1.22s — funded lower-league shortlist scouting.
 * Post-window, narrowly scoped: one essential GK/ST vacancy, after normal
 * recruitment and severe emergency repair. Existing free agents only.
 * No manufactured players, extra money, fictional appearances or managed transfers.
 */
(function(root){'use strict';
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const round=x=>Math.round(x*100)/100;
const positions=['GK','ST'];
const quality={2:[53,77],3:[48,71],4:[45,67]};
const weeklyCap={2:20,3:10,4:6};
function examine({roster=[],tier=3,year=2027}={}){
 const squad=root.FDSquadIntelligence122g;
 if(!squad)return {eligible:false,reason:'Squad report unavailable',holes:[]};
 const t=Math.max(1,Math.min(4,n(tier)||3)),r=squad.inspect(roster,year);
 const essential=Object.entries(r.groups).filter(([,x])=>x.count+x.academyReady<x.floor);
 const missing=essential.map(([role,x])=>({role,count:x.count,academyReady:x.academyReady,missing:x.floor-x.count-x.academyReady}));
 const small=r.seniorCount>=19&&r.seniorCount<=27;
 // More serious vacancies remain with 1.22r. No broad squad-stockpiling.
 const eligible=t>=2&&small&&missing.length===1&&missing[0].missing===1&&positions.includes(missing[0].role);
 return {eligible,holes:missing,seniorCount:r.seniorCount,groups:r.groups,reason:eligible?'Funded single-role scouting':missing.length?'Not a single eligible vacancy':'No essential vacancy'};
}
function candidate({player,club,roster=[],finance,year=2027,tier=3,getWage=()=>0,report=null}={}){
 const market=root.FDMarketBalance122f, squad=root.FDSquadIntelligence122g;
 if(!market||!squad||!player?.id||!club?.id||!finance||player.clubId!=='free-agent'||player.retired||player.profilePending||player.parentClubId||player.transferType==='Loan'||
   String(player.lastTransferWindow||'')===`${year}-07`||String(player.lastTransferWindow||'')===`${year}-01`)return null;
 const age=n(player.age||player.simulationAge071g),t=Math.max(1,Math.min(4,n(tier)||3)),ovr=n(player.overall);
 if(age<18||age>34||!quality[t]||ovr<quality[t][0]||ovr>quality[t][1])return null;
 const role=squad.family(player),plan=report||examine({roster,tier:t,year});
 if(!plan.eligible||plan.holes[0].role!==role)return null;
 const positionPeers=plan.groups[role].players;
 const starters=positionPeers.slice().sort((a,b)=>n(b.overall)-n(a.overall));
 const senior=roster.filter(p=>p&&!p.retired&&p.clubId===club.id&&p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.squadStatus!=='Academy');
 const typical=senior.slice().sort((a,b)=>n(b.overall)-n(a.overall))[Math.min(9,senior.length-1)]?.overall||quality[t][0]+7;
 const strongest=n(starters[0]?.overall),minimum=Math.max(quality[t][0],typical-(t===2?14:16),strongest?strongest-16:0);
 if(ovr<minimum||ovr>typical+13||(strongest&&ovr>strongest+14))return null;
 const wage=Math.max(.4,n(player.wage),n(getWage(player,club)));
 if(wage>weeklyCap[t]||!market.canAdd({finance,roster,weeklyWage:wage}))return null;
 const signingCost=round(Math.max(.03,Math.min(t===2?.22:.11,ovr*.0012)));
 // Preserve meaningful cash headroom for other recruitment and operations.
 if(n(finance.budget)<.12||signingCost>n(finance.budget)*.18)return null;
 const potential=n(player.development?.potentialMax||ovr);
 const readiness=ovr>=Math.max(quality[t][0],strongest-10);
 const score=ovr*.85+Math.min(8,Math.max(0,potential-ovr))*(age<=23?.2:0)+
   (readiness?7:0)-wage*.8-Math.max(0,age-30)*2-
   Math.max(0,ovr-typical)*1.5;
 return {role,wage,signingCost,score,year,seniorBefore:plan.seniorCount};
}
function shortlist({freeAgents=[],club,roster=[],finance,year=2027,tier=3,getWage=()=>0,maxChecked=200}={}){
 const report=examine({roster,tier,year});if(!report.eligible)return [];
 // Pre-filter the relevant role and ability before expensive contract checks.
 const group=report.holes[0].role,band=quality[tier]||[];const out=[];
 let checked=0;
 for(const p of freeAgents){
  if(!p||p.clubId!=='free-agent'||root.FDSquadIntelligence122g.family(p)!==group||n(p.overall)<band[0]||n(p.overall)>band[1])continue;
  if(checked++>=Math.max(8,Math.min(300,n(maxChecked)||200)))break;
  const fit=candidate({player:p,club,roster,finance,year,tier,getWage,report});if(fit)out.push({player:p,...fit});
 }
 return out.sort((a,b)=>b.score-a.score||String(a.player.id).localeCompare(String(b.player.id)));
}
function run({players=[],clubs=[],finances={},year=2027,month='July',protectedClubId='',getTier=c=>c.tier||1,getWage=p=>p.wage||0,getContractLength=()=>2,maxMoves=3}={}){
 const events=[];events.touchedPlayerIds097d=[];
 const stamp=`${year}-${['January','01'].includes(String(month))?'01':'07'}`;
 if(!['July','07','08','January','01'].includes(String(month))||!root.FDMarketBalance122f||!root.FDSquadIntelligence122g)return events;
 const perWindowLimit=Math.min(['January','01'].includes(String(month))?2:3,Math.max(0,n(maxMoves)));
 if(!perWindowLimit)return events;
 const byClub=new Map(clubs.map(c=>[c.id,[]]));
 const free=[];
 for(const p of players){if(!p||p.retired)continue;if(p.clubId==='free-agent')free.push(p);else if(byClub.has(p.clubId))byClub.get(p.clubId).push(p);}
 const destinations=clubs.filter(c=>c?.id&&c.id!==protectedClubId&&finances[c.id]).map(c=>({club:c,tier:n(getTier(c)),roster:byClub.get(c.id)||[]}))
   .map(row=>({...row,plan:examine({roster:row.roster,tier:row.tier,year})}))
   .filter(row=>row.plan.eligible&&!row.roster.some(p=>p.scoutingStamp122s===stamp))
   .sort((a,b)=>a.plan.seniorCount-b.plan.seniorCount||String(a.club.id).localeCompare(String(b.club.id)));
 for(const {club,tier,roster} of destinations){
  if(events.length>=perWindowLimit)break;
  const f=finances[club.id],choices=shortlist({freeAgents:free,club,roster,finance:f,year,tier,getWage});
  // An unaffordable/unsuitable first player is NOT a reason to stop searching.
  const selected=choices[0];if(!selected)continue;
  const p=selected.player;
  const check=candidate({player:p,club,roster,finance:f,year,tier,getWage});if(!check)continue;
  const oldWage=n(p.wage);
  p.clubId=club.id;p.teamName=club.name;p.leagueName=club.league;
  p.registrationGroup='Senior';p.squadStatus='First Team';p.transferType='Permanent';
  p.parentClubId=null;p.parentClubName=null;p.loanEndYear=null;p.loanDestinationPending=false;
  p.wage=round(check.wage);p.contractUntil=n(year)+Math.max(1,Math.min(4,n(getContractLength(p,club))||2));
  p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=stamp;
  p.scoutingStamp122s=stamp;p.clubTenure073=0;p.freeAgentYears080=0;p.transferListed=false;p.wantsMove=false;
  f.budget=round(n(f.budget)-check.signingCost);f.spent=round(n(f.spent)+check.signingCost);
  roster.push(p);
  events.push({kind:'ai-lower-league-scout122s',season:String(year),window:String(month),playerId:p.id,playerName:p.name,
    fromClubId:'free-agent',fromClubName:'Free Agent',toClubId:club.id,toClubName:club.name,toLeague:club.league,
    fee:0,signingCost:check.signingCost,position:p.positions?.[0]||p.position||'',wage:check.wage,previousWage:oldWage,
    role122s:check.role,seniorBefore122s:check.seniorBefore,scoutingCandidates122s:choices.length,reason:'Funded first-team shortlist fallback'});
  events.touchedPlayerIds097d.push(p.id);
 }
 return events;
}
const api={examine,candidate,shortlist,run};root.FDLowerLeagueScouting122s=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
