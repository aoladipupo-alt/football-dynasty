/* Football Dynasty 1.21z — limited, financially viable first contracts at third-tier clubs.
   Active only during transfer windows. Foreign feeder clubs do NOT play matches. */
(function(root){
'use strict';
const num=x=>Number(x)||0, round=x=>Math.round(x*10)/10;
function hash(s){let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;}
function group(p){const x=String(p?.positions?.[0]||p?.position||'CM').toUpperCase();return x==='GK'?'GK':/^(CB|RB|LB|LWB|RWB)/.test(x)?'DEF':/^(LW|RW|RM|LM)/.test(x)?'WIDE':/^(ST|CF)/.test(x)?'ST':'MID';}
const cap={GK:3,DEF:9,MID:7,WIDE:5,ST:4};
function opportunity(p,club,roster){
 const tier=num(club?.tier)||1,ovr=num(p?.overall),role=group(p);
 if(tier<3||tier>4||ovr<54||ovr>67)return null;
 const seniors=roster.filter(x=>x&&!x.retired&&x.registrationGroup!=='U21'&&x.squadStatus!=='Academy');
 if(seniors.length>=36||seniors.length<17)return null;
 const peers=seniors.filter(x=>group(x)===role).sort((a,b)=>num(b.overall)-num(a.overall));
 const ahead=peers.filter(x=>num(x.overall)>ovr+1).length;
 const startingQuality=num(peers[Math.min(peers.length-1,Math.max(0,cap[role]-2))]?.overall)||55;
 if(ahead>=cap[role]||ovr<startingQuality-5||ovr>startingQuality+13)return null;
 return {role,competition:ahead,peerQuality:startingQuality,seniorCount:seniors.length,
   score:Math.max(0,cap[role]-ahead)*4+(ovr-startingQuality)*2+Math.max(0,27-seniors.length)};
}
function run({players=[],clubs=[],shadowClubs=[],finances={},year=2027,month='07',protectedClubId='',seed='',getValue=()=>1,getWage=()=>4,getContractLength=()=>3,maxMoves=2}={}){
 const events=[];events.touchedPlayerIds097d=[];
 if(String(month).padStart(2,'0')!=='07'||!Array.isArray(players)||!Array.isArray(clubs))return events;
 const sources=new Map(shadowClubs.filter(c=>c?.shadowOnly116).map(c=>[c.id,c]));
 const buyers=clubs.filter(c=>c?.id!==protectedClubId&&num(c.tier)>=3&&num(c.tier)<=4&&finances[c.id]);
 if(!buyers.length)return events;
 const roster=new Map(buyers.map(c=>[c.id,[]]));
 for(const p of players)if(p&&!p.retired&&roster.has(p.clubId))roster.get(p.clubId).push(p);
 const stock=players.filter(p=>p&&p.shadowAcademy116&&sources.has(p.clubId)&&!p.retired&&!p.shadowSignedSeason117&&!p.shadowSenior118&&!p.parentClubId&&
   num(p.age)>=18&&num(p.age)<=23&&num(p.overall)>=54&&num(p.overall)<=67&&num(p.development?.potentialMax)>=73)
   .sort((a,b)=>((hash(seed+'|prospect|'+a.id)%10000)-(hash(seed+'|prospect|'+b.id)%10000))||String(a.id).localeCompare(String(b.id)));
 
 const bought=new Set(),sourcesUsed=new Map(),limit=Math.min(6,Math.max(0,num(maxMoves)));
 for(const p of stock){
   if(events.length>=limit)break;
   const source=sources.get(p.clubId),sourceId=p.clubId;
   if((sourcesUsed.get(sourceId)||0)>=2)continue;
   const ask=num(getValue(p,year));if(!Number.isFinite(ask)||ask<=0)continue;
   // Sell-on development deal: smaller initial fee allows a genuine third-tier start,
   // while originating academy retains a future resale percentage (not fabricated cash).
   // A modest development fee plus a future sell-on share makes early careers
   // affordable for third-tier clubs; price ceilings apply only to 54–67 OVR.
   const fee=Math.max(.2,Math.min(num(p.overall)<=62?.4:.8,round(Math.max(.2,ask)*.44)));
   const bids=[];
   for(const c of buyers){
     if(bought.has(c.id))continue;
     const fit=opportunity(p,c,roster.get(c.id));if(!fit||root.FDSquadIntelligence122g?.severeCongestion?.(roster.get(c.id),p,year))continue;
     const f=finances[c.id];if(num(f.budget)<fee||fee>num(f.budget)*.25)continue;
     const wage=Math.max(.1,num(getWage(p,c)));
     const bill=roster.get(c.id).reduce((s,x)=>s+num(x.wage)*.052,0);
     if(!(root.FDMarketBalance122f?.limit?.(f)??num(f.wageBudget))||bill+wage*.052>(root.FDMarketBalance122f?.limit?.(f)??num(f.wageBudget))*1.035)continue;
     // A club must both discover the player and offer a plausible first-team role.
     const roll=(hash(seed+'|discover|'+p.id+'|'+c.id)%10000)/10000;
     if(roll>.44)continue;
     const score=fit.score+Math.min(10,num(f.budget)/5)+((hash(seed+'|score|'+p.id+'|'+c.id)%10000)/10000)*9;
     bids.push({c,f,fee,wage,fit,score});
   }
   bids.sort((a,b)=>b.score-a.score||String(a.c.id).localeCompare(String(b.c.id)));
   if(!bids.length)continue;
   const {c,f,wage,fit,score}=bids[0],fromName=source.name;
   p.clubId=c.id;p.teamName=c.name;p.leagueName=c.league;
   p.transferType='Permanent';p.registrationGroup='Senior';p.squadStatus='First Team';p.shadowCareerPath119='Development rotation';
   p.shadowSignedSeason117=num(year);p.shadowSignedFee117=fee;
   p.shadowFirstDestination121x={clubId:c.id,clubName:c.name,tier:num(c.tier),year:num(year),role:'First-team pathway'};
   p.shadowSellOn121z={academyId:sourceId,academyName:fromName,rate:.2,initialFee:fee};
   p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=`${year}-07`;
   p.wage=wage;p.contractUntil=num(year)+Math.max(2,Math.min(5,num(getContractLength(p,c))||3));
   p.clubTenure073=0;p.morale=Math.min(99,num(p.morale||70)+4);
   f.budget=round(Math.max(0,num(f.budget)-fee));f.spent=round(num(f.spent)+fee);
   roster.get(c.id).push(p);bought.add(c.id);sourcesUsed.set(sourceId,(sourcesUsed.get(sourceId)||0)+1);
   events.push({kind:'ai-feeder-first-contract121z',season:String(year),window:'July',playerId:p.id,playerName:p.name,
      fromClubId:sourceId,fromClubName:fromName,toClubId:c.id,toClubName:c.name,toLeague:c.league,fee,
      position:p.positions?.[0]||p.position||'CM',firstDestinationTier121x:num(c.tier),
      managerStyle:'Lower-league talent scouting',philosophy:'Senior opportunity',careerPath119:'First-team pathway',
      sellOn121z:20,scoutingFit121z:Math.round(fit.score),overall119:num(p.overall),age119:num(p.age)});
   events.touchedPlayerIds097d.push(p.id);
 }
 return events;
}
const api={run,opportunity};root.FDLowerLeagueEntry121z=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
