/* Football Dynasty 1.22i — annual, evidence-based squad restructuring.
   Loans only return where the original yearEnd makes them return; the review
   never manufactures minutes, changes contracts, or transfers a player. */
(function(root){'use strict';
const squad=root.FDSquadIntelligence122g||(typeof module!=='undefined'?require('./squad-intelligence-122g.js'):null);
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const target={GK:2,DEF:7,MID:5,WIDE:5,ST:3};
const minimum={GK:2,DEF:5,MID:4,WIDE:2,ST:2};
function active(p,clubId){return Boolean(p&&!p.retired&&!p.profilePending&&p.clubId===clubId&&p.transferType!=='Loan'&&p.registrationGroup!=='U21'&&p.registrationGroup!=='Academy'&&p.squadStatus!=='Academy');}
function peers(roster,p){const f=squad.family(p);return (roster||[]).filter(q=>q?.id!==p.id&&active(q,p.clubId)&&squad.family(q)===f);}
function age(p){return n(p.age||p.simulationAge071g)||25;}
function potential(p){return n(p.development?.potentialMax||p.overall);}
function naturalExpiry({roster=[],player,year=2027,protectedClubId='',recordedMinutes}={}){
 const p=player;
 if(!p||p.retired||!p.clubId||p.clubId==='free-agent'||p.clubId===protectedClubId||p.transferType==='Loan')return {decline:false,reason:'protected or unavailable'};
 const until=n(p.contractUntil),y=n(year),f=squad.family(p),other=peers(roster,p),senior=(roster||[]).filter(q=>active(q,p.clubId));
 if(!until||until>y+1||age(p)<24||potential(p)>=n(p.overall)+9)return {decline:false,reason:'contract or potential protected'};
 const mins=recordedMinutes===undefined?n(p.seasonMinutes):n(recordedMinutes);
 const stronger=other.filter(q=>n(q.overall)>=n(p.overall)+2).length;
 const comfortable=other.length>=minimum[f]+1;
 const overcrowded=other.length+1>=target[f]+2 || senior.length>=31&&other.length+1>=target[f]+1;
 const rank=senior.filter(q=>n(q.overall)>n(p.overall)).length;
 const recentlyEffectiveLoan=p.returnReview122i&&n(p.returnReview122i.year)===y&&n(p.returnReview122i.minutes)>=900;
 const decline=comfortable&&overcrowded&&senior.length>=24&&stronger>=2&&rank>=9&&mins<500&&!recentlyEffectiveLoan;
 return {decline,reason:decline?'overcrowded and underused at natural contract end':'needed cover or earned opportunity',group:f,minutes:mins,peers:other.length,seniorCount:senior.length,atExpiry:until<=y};
}
function loanReturn({roster=[],player,year=2027,recordedMinutes=0,protectedClubId=''}={}){
 const p=player;
 if(!p||p.retired||p.clubId===protectedClubId||!p.clubId||p.clubId==='free-agent')return {action:'No automatic decision',reason:'protected club or unavailable'};
 const other=peers(roster,p),f=squad.family(p),clubRows=(roster||[]).filter(q=>active(q,p.clubId)),mins=n(recordedMinutes),a=age(p);
 const stronger=other.filter(q=>n(q.overall)>=n(p.overall)+3).length,depth=other.length;
 const crowded=depth+1>target[f]&&clubRows.length>=22;
 let action='Compete for minutes';
 if(crowded&&stronger>=2&&mins<700&&a<=23&&potential(p)>=n(p.overall)+7)action='Consider another loan';
 else if(crowded&&stronger>=2&&mins<550&&a>=24&&depth>=minimum[f]+1&&potential(p)<n(p.overall)+9)action='Transfer-list for an offer';
 return {year:n(year),action,reason:action==='Compete for minutes'?'No evidence of a blocked pathway':'Overcrowded role and limited verified loan minutes',minutes:Math.max(0,Math.round(mins)),group:f,strongerPeers:stronger,groupSize:depth+1};
}
function reviewReturns({players=[],returns=[],year=2027,protectedClubId=''}={}){
 const byId=new Map(players.map(p=>[p.id,p]));const byClub=new Map();
 for(const p of players)if(p?.clubId){if(!byClub.has(p.clubId))byClub.set(p.clubId,[]);byClub.get(p.clubId).push(p);}
 const events=[];
 for(const e of returns){const p=byId.get(e.playerId);if(!p||p.clubId!==e.toClubId||p.clubId===protectedClubId)continue;
  if(n(p.returnReview122i?.year)===n(year)&&p.returnReview122i?.clubId===p.clubId)continue;
  const assessed=loanReturn({player:p,roster:byClub.get(p.clubId)||[],year,recordedMinutes:p.seasonMinutes,protectedClubId});
  p.returnReview122i={...assessed,clubId:p.clubId};
  if(assessed.action==='Consider another loan')p.secondChanceLoanPriority121r=true;
  if(assessed.action==='Transfer-list for an offer'){
   p.transferListed=true;p.transferListedByReturn122i=true;p.wantsMove=true;p.unhappinessReason='Seeking a regular role';
  }
  events.push({playerId:p.id,clubId:p.clubId,...assessed});
 }
 return events;
}
function reviewGraduates({players=[],graduations=[],year=2027,protectedClubId=''}={}){
 const byId=new Map(players.map(p=>[p.id,p]));const byClub=new Map();
 for(const p of players)if(p?.clubId){if(!byClub.has(p.clubId))byClub.set(p.clubId,[]);byClub.get(p.clubId).push(p);}
 const events=[];
 for(const g of graduations){const p=byId.get(g.playerId);if(!p||p.retired||p.clubId!==g.clubId||p.clubId===protectedClubId)continue;
  if(n(p.graduateReview122i?.year)===n(year))continue;
  const recent=n(p.careerHistory076?.[0]?.minutes??p.seasonMinutes),other=peers(byClub.get(p.clubId),p),f=squad.family(p);
  const crowded=other.length+1>target[f]&&other.filter(q=>n(q.overall)>=n(p.overall)+3).length>=2;
  const action=crowded&&recent<450?'Seek loan opportunity':'Compete for senior spot';
  p.graduateReview122i={year:n(year),clubId:p.clubId,action,minutes:recent,group:f};
  if(action==='Seek loan opportunity')p.secondChanceLoanPriority121r=true;
  events.push({playerId:p.id,clubId:p.clubId,action,minutes:recent});
 }
 return events;
}
root.FDLongTermSquads122i={naturalExpiry,loanReturn,reviewReturns,reviewGraduates};
if(typeof module!=='undefined'&&module.exports)module.exports=root.FDLongTermSquads122i;
})(typeof window!=='undefined'?window:globalThis);
