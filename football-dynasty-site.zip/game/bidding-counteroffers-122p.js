/* Football Dynasty 1.22p - bounded, transfer-window-only AI bid resolution.
 * Negotiates only against existing candidates: no generated players, discounted
 * asking prices, forced acceptances, new state writes, or invented match minutes.
 */
(function(root){'use strict';
 const number=x=>Number.isFinite(Number(x))?Number(x):NaN;
 const roundFee=x=>Math.round(x*10)/10;
 /**
  * Evaluates the chosen top candidate first, then at most two alternatives.
  * quote(row) must implement the existing rivalry, competition and clause rules.
  * When the initial quote is below an existing seller's minimum, the seller
  * can counter UP to its reserve; the buyer never receives a discount.
  */
 function resolvePaid(options,{startIndex=0,maxTries=3,quote,canAfford,stillEligible}={}){
   if(!Array.isArray(options)||!options.length||typeof quote!=='function'||typeof canAfford!=='function')return null;
   const cap=Math.min(3,Math.max(1,Math.floor(number(maxTries)||3)),options.length);
   const start=Math.min(options.length-1,Math.max(0,Math.floor(number(startIndex)||0)));
   let rejected=0,countered=0;
   for(let i=0;i<cap;i++){
     const row=options[(start+i)%options.length];
     if(!row?.p||row.p.retired||row.p.profilePending||row.suitability<60||
       (stillEligible&& !stillEligible(row))){rejected++;continue;}
     const initial=quote(row);
     if(!initial||!Number.isFinite(number(initial.price))||number(initial.price)<0){rejected++;continue;}
     const original=roundFee(number(initial.price));
     const release=number(row.p.releaseClause);
     const validClause=release>0 && initial.clauseActivated===true;
     const floor=number(initial.minimumSellerFee);
     const sellerMayCounter=!validClause&&!row.p.transferListed&&!row.p.wantsMove&&!row.p.financialPressureSale;
     const proposed=sellerMayCounter&&Number.isFinite(floor)&&floor>original
       ?Math.ceil((floor-0.000001)*10)/10:original;
     const isCounter=proposed>original;
     if(isCounter)countered++;
     if(!canAfford(row,proposed,initial)){rejected++;continue;}
     return {chosen:row,price:proposed,competition:Array.isArray(initial.competition)?initial.competition:[],
       clauseActivated:validClause,countered:isCounter,firstQuote:original,attempts:i+1,
       rejectedBeforeSuccess:rejected,countersRequested:countered};
   }
   return null;
 }
 const api={resolvePaid};root.FDBidding122p=api;
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
