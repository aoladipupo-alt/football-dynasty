/* Football Dynasty 1.22t — evidence-led funded vacancy repair.
 * Runs ONLY after normal transfers, severe repair and GK/ST scouting.
 * One missing DEF/MID/WIDE rotation player on healthy lower-division squads.
 * Existing free agents only; no phantom cash, match minutes or forced moves.
 */
(function(root){'use strict';
const n=x=>Number.isFinite(Number(x))?Number(x):0;
const round=x=>Math.round(x*100)/100;
const roles=['DEF','MID','WIDE'];
const bands={2:[53,77],3:[48,71],4:[45,67]};
const caps={2:20,3:10,4:6};
const market=()=>root.FDMarketBalance122f;
const squad=()=>root.FDSquadIntelligence122g;
function inspect({roster=[],tier=3,year=2027}={}){
 if(!squad())return {eligible:false,reason:'missing-analysis',holes:[]};
 const t=n(tier),r=squad().inspect(roster,year);
 const holes=Object.entries(r.groups).map(([role,x])=>({role,missing:Math.max(0,x.floor-x.count-x.academyReady),seniors:x.count,academyReady:x.academyReady})).filter(x=>x.missing);
 const narrow=holes.length===1&&holes[0].missing===1&&roles.includes(holes[0].role);
 const eligible=t>=2&&t<=4&&r.seniorCount>=20&&r.seniorCount<=27&&narrow;
 return {eligible,holes,seniorCount:r.seniorCount,report:r,reason:eligible?'one-funded-rotation-vacancy':
   t<2||t>4?'outside-lower-leagues':r.seniorCount<20?'small-squad-use-rebuild':r.seniorCount>27?'squad-too-large':
   !holes.length?'no-essential-shortage':narrow?'other-ineligible':'reserved-for-existing-pathways'};
}
function fit({player,club,roster=[],finance,tier=3,year=2027,getWage=p=>p.wage||0,assessment=null}={}){
 if(!club?.id||!player?.id||!finance||!market()||!squad())return {eligible:false,reason:'missing-input'};
 const report=assessment||inspect({roster,tier,year});
 if(!report.eligible)return {eligible:false,reason:report.reason};
 const role=squad().family(player),age=n(player.age||player.simulationAge071g),ovr=n(player.overall),t=n(tier);
 if(player.clubId!=='free-agent'||player.retired||player.profilePending||player.parentClubId||player.transferType==='Loan'||
  player.loanDestinationPending||String(player.lastTransferWindow||'')===`${year}-07`||String(player.lastTransferWindow||'')===`${year}-01`||
  age<19||age>32)return {eligible:false,reason:'not-available'};
 if(role!==report.holes[0].role)return {eligible:false,reason:'wrong-position'};
 if(ovr<bands[t][0]||ovr>bands[t][1])return {eligible:false,reason:'wrong-division-level'};
 const seniors=report.report.groups;
 const all=Object.values(seniors).flatMap(x=>x.players).sort((a,b)=>n(b.overall)-n(a.overall));
 const typical=n(all[Math.min(9,all.length-1)]?.overall)||bands[t][0]+7;
 const own=seniors[role].players;
 const strongest=n(own[0]?.overall);
 if(ovr<Math.max(bands[t][0],typical-15,strongest?strongest-17:0)||ovr>typical+11||(strongest&&ovr>strongest+13))return {eligible:false,reason:'not-competitive'};
 const wage=Math.max(.4,n(player.wage),n(getWage(player,club)));
 if(wage>caps[t])return {eligible:false,reason:'wage-too-high'};
 const signingCost=round(Math.max(.04,Math.min(t===2?.22:.11,ovr*.0012)));
 if(n(finance.budget)<.5||signingCost>n(finance.budget)*.12)return {eligible:false,reason:'cash-reserve'};
 if(!market().canAdd({finance,roster,weeklyWage:wage}))return {eligible:false,reason:'wage-headroom'};
 const score=ovr*1.2-wage*.9-Math.max(0,age-29)*1.8-Math.max(0,ovr-typical)*1.1+
  Math.min(3,Math.max(0,n(player.development?.potentialMax||ovr)-ovr))*(age<=23?.4:0);
 return {eligible:true,reason:'affordable-fit',role,wage,signingCost,score};
}
function assessClub({club,roster=[],finance,freeAgents=[],tier=3,year=2027,getWage=p=>p.wage||0,maxExamined=260}={}){
 const assessment=inspect({roster,tier,year});
 const outcome={clubId:club?.id,reason:assessment.reason,eligible:assessment.eligible,holes:assessment.holes.map(x=>({role:x.role,missing:x.missing})),seniorCount:assessment.seniorCount,scanned:0,roleMatches:0,affordable:0,blockers:{},choices:[]};
 if(!assessment.eligible)return outcome;
 const role=assessment.holes[0].role,t=n(tier),pool=freeAgents.filter(p=>p?.clubId==='free-agent'&&!p.retired&&squad().family(p)===role&&n(p.overall)>=bands[t][0]&&n(p.overall)<=bands[t][1]);
 pool.sort((a,b)=>n(b.overall)-n(a.overall)||String(a.id).localeCompare(String(b.id)));
 for(const p of pool.slice(0,Math.max(20,Math.min(360,n(maxExamined)||260)))){
  outcome.scanned++;outcome.roleMatches++;
  const result=fit({player:p,club,roster,finance,tier,year,getWage,assessment});
  if(result.eligible){outcome.affordable++;outcome.choices.push({player:p,...result});}
  else outcome.blockers[result.reason]=(outcome.blockers[result.reason]||0)+1;
 }
 outcome.choices.sort((a,b)=>b.score-a.score||String(a.player.id).localeCompare(String(b.player.id)));
 outcome.reason=outcome.affordable?'affordable-available':outcome.roleMatches?'no-affordable-fit':'no-role-candidates';
 return outcome;
}
function run({players=[],clubs=[],finances={},year=2027,month='July',protectedClubId='',getTier=c=>c.tier||1,getWage=p=>p.wage||0,getContractLength=()=>2,maxMoves=2}={}){
 const events=[];events.touchedPlayerIds097d=[];
 const audit={eligibleClubs:0,consideredClubs:0,filled:0,blocked:{},examples:[]};events.audit122t=audit;
 const january=['January','01'].includes(String(month));
 if(!['July','07','08','January','01'].includes(String(month))||!market()||!squad())return events;
 const windowCap=Math.min(january?1:2,Math.max(0,n(maxMoves)));
 if(!windowCap)return events;
 const stamp=`${year}-${january?'01':'07'}`;
 const rosters=new Map(clubs.map(c=>[c.id,[]]));const free=[];
 for(const p of players){if(!p||p.retired)continue;if(p.clubId==='free-agent')free.push(p);else if(rosters.has(p.clubId))rosters.get(p.clubId).push(p);}
 const eligible=clubs.filter(c=>c?.id&&c.id!==protectedClubId&&finances[c.id]&&n(getTier(c))>=2&&n(getTier(c))<=4)
  .map(c=>({club:c,tier:n(getTier(c)),roster:rosters.get(c.id)||[]}))
  .map(c=>({...c,assessment:inspect({roster:c.roster,tier:c.tier,year})}))
  .filter(c=>c.assessment.eligible&&!c.roster.some(p=>p.vacancyEvidenceStamp122t===stamp))
  .sort((a,b)=>a.assessment.seniorCount-b.assessment.seniorCount||String(a.club.id).localeCompare(String(b.club.id)));
 audit.eligibleClubs=eligible.length;
 for(const {club,tier,roster} of eligible){
  if(events.length>=windowCap)break;
  const finance=finances[club.id];
  const check=assessClub({club,roster,finance,freeAgents:free,tier,year,getWage});audit.consideredClubs++;
  audit.blocked[check.reason]=(audit.blocked[check.reason]||0)+1;
  if(audit.examples.length<5)audit.examples.push({clubId:club.id,role:check.holes[0]?.role,reason:check.reason,available:check.affordable,blockers:check.blockers});
  if(!check.choices.length)continue;
  const {player:p}=check.choices[0];
  const fresh=fit({player:p,club,roster,finance,year,tier,getWage});if(!fresh.eligible)continue;
  const oldWage=n(p.wage);
  p.clubId=club.id;p.teamName=club.name;p.leagueName=club.league;
  p.registrationGroup='Senior';p.squadStatus='First Team';p.transferType='Permanent';
  p.parentClubId=null;p.parentClubName=null;p.loanEndYear=null;p.loanEnd=null;p.loanDestinationPending=false;
  p.wage=round(fresh.wage);p.contractUntil=n(year)+Math.max(1,Math.min(4,n(getContractLength(p,club))||2));
  p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=stamp;
  p.vacancyEvidenceStamp122t=stamp;p.clubTenure073=0;p.freeAgentYears080=0;p.transferListed=false;p.wantsMove=false;
  finance.budget=round(n(finance.budget)-fresh.signingCost);finance.spent=round(n(finance.spent)+fresh.signingCost);
  roster.push(p);audit.filled++;
  events.push({kind:'ai-vacancy-evidence122t',season:String(year),window:String(month),playerId:p.id,playerName:p.name,
   fromClubId:'free-agent',fromClubName:'Free Agent',toClubId:club.id,toClubName:club.name,toLeague:club.league,
   fee:0,signingCost:fresh.signingCost,position:p.positions?.[0]||p.position||'',wage:fresh.wage,previousWage:oldWage,
   role122t:fresh.role,alternatives122t:check.affordable,reason:'Evidence-backed funded rotation vacancy'});
  events.touchedPlayerIds097d.push(p.id);
 }
 return events;
}
const api={inspect,fit,assessClub,run};root.FDVacancyEvidence122t=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
