/* Football Dynasty 1.19b: lightweight, deterministic global club scouting + destination-fit market.
   Run only inside existing July/January transfer windows. No fixtures or shadow matches.
   Browser/global export plus CommonJS for regression tests. */
(function (root) {
  'use strict';
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const round=n=>Math.round(n*10)/10;
  function hash(value){let h=2166136261;for(const ch of String(value)){h=Math.imul(h^ch.charCodeAt(0),16777619)}return h>>>0;}
  function roll(key){return hash(key)/4294967296;}
  function family(p){const pos=String((p.positions||[])[0]||p.position||'').toUpperCase();
    if(pos.includes('GK'))return 'GK';if(/^(LB|RB|CB|LWB|RWB|LCB|RCB|DEF)/.test(pos))return 'DEF';if(/^(LW|RW|LM|RM|LF|RF|W)/.test(pos))return 'WIDE';if(/^(ST|CF|FW|SS)/.test(pos))return 'ST';return 'MID';}
  const NEED={GK:2,DEF:7,MID:6,WIDE:4,ST:3};
  // 1.21x: first overseas contract must provide a believable entry-level role.
  // A feeder graduate's *potential* alone is not a reason for a Premier League
  // club to add another U21 to an overcrowded squad.
  function firstDestination121x(p,buyer,roster){
    if(!p?.shadowAcademy116||p.shadowSenior118||p.shadowSignedSeason117)return null;
    const tier=clamp(Number(buyer?.tier)||1,1,4),age=Number(p.age)||18;
    const ovr=Number(p.overall)||0,pot=Number(p.development?.potentialMax)||ovr;
    if(age<18||age>24)return null;
    const group=(roster||[]).filter(x=>!x.retired&&family(x)===family(p));
    const slots={GK:1,DEF:4,MID:3,WIDE:2,ST:1}[family(p)]||2;
    const ranked=group.map(x=>Number(x.overall)||0).sort((a,b)=>b-a);
    const competition=ranked.filter(x=>x>ovr+1).length;
    const matchQuality=ranked.length?ranked[Math.min(ranked.length-1,slots-1)]:tier===1?74:tier===2?64:55;
    const seniorCount=(roster||[]).filter(x=>!x.retired&&x.registrationGroup!=='U21'&&x.squadStatus!=='Academy').length;
    if(seniorCount>=(tier===1?34:tier===2?35:36))return null;
    if(tier===1){
      // Exceptionally promising players still can enter top-flight youth systems,
      // but ordinary 55-70 rated graduates should start lower and PLAY.
      if(pot<91&&ovr<76)return null;
      if(ovr<matchQuality-9)return null;
      if(competition>slots+2)return null;
    }else if(tier===2){
      if(ovr<59||ovr>80||ovr<matchQuality-8||competition>slots+3)return null;
    }else{
      if(ovr<53||ovr>73||ovr<matchQuality-8||competition>slots+3)return null;
    }
    const seniorReady=ovr>=matchQuality-5&&competition<=slots+1;
    const role=seniorReady?(competition<slots?'First team':'Development rotation'):'Development rotation';
    if(tier===1&&!seniorReady&&pot<94)return null;
    return {role,competition,matchQuality,tier,
      // The first contract is a stepping stone; selection is still earned in fixtures.
      fit:clamp((seniorReady?13:4)+(tier>=2?6:0)+Math.min(5,Math.max(0,slots-competition)*2),0,23)};
  }
  const ROUTES={
    'ajax':['South America','Caribbean','Africa'], 'psv':['South America','Caribbean','Africa'], 'feyenoord':['Caribbean','South America','Africa'],
    'benfica':['South America','Africa'], 'sporting':['South America','Africa'], 'fc-porto':['South America','Africa'],
    'chelsea':['South America','Africa','North America'], 'man-city':['South America','Africa','North America'], 'man-utd':['Africa','South America'],
    'barcelona':['South America','Africa'], 'real-madrid':['South America'], 'dortmund':['Africa','South America','Asia'],
    'lille':['Africa','South America'], 'anderlecht':['Africa','Caribbean'], 'genk':['Africa','South America'],
    'club-brugge':['Africa','South America'], 'juventus':['South America','Africa'], 'atletico-madrid':['South America']
  };
  function links(club){const id=String(club.id||'').toLowerCase(),name=String(club.name||'').toLowerCase();
    for(const [key,routes] of Object.entries(ROUTES))if(id.includes(key)||name.replace(/[^a-z0-9]/g,'').includes(key.replace(/[^a-z0-9]/g,'')))return routes;
    const league=String(club.league||'').toLowerCase();if(/eredivisie/i.test(league))return ['Caribbean','South America','Africa'];
    if(/primeira|portugal/i.test(league))return ['South America','Africa'];if(/ligue 1|france/i.test(league))return ['Africa'];
    if(/la liga|spain/i.test(league))return ['South America','Africa'];return [];
  }
  function academyFee(p,origin,marketValue){const pot=Number(p.development?.potentialMax||p.overall||60),ovr=Number(p.overall||55),age=Number(p.age||18);
    const upside=Math.max(0,pot-ovr),rep=Number(origin?.reputation||76);
    const reserve=Math.max(.35,Number(marketValue)||.35)*(.95+clamp((pot-79)*.025,0,.38));
    return round(clamp(reserve+Math.max(0,pot-78)*.11+Math.max(0,rep-80)*.04+(age<=20?Math.min(1.5,upside*.026):0),.5,145));
  }
  // 1.19b: senior talent must have a distinct reserve curve; the youth ask
  // additionally protects potential. Prices are MILLIONS, never wages.
  function reservePrice119(p,origin,marketValue,year){
    if(!p.shadowSenior118)return academyFee(p,origin,marketValue);
    const ovr=clamp(Number(p.overall)||60,40,95),age=clamp(Number(p.age)||26,18,42);
    const rep=clamp(Number(origin?.reputation)||78,50,100);
    const years=clamp((Number(p.contractUntil)||Number(year)+1)-Number(year),0,5);
    const ability=Math.max(.55,Math.pow(Math.max(0,ovr-61),2)*.038);
    const experience=age<=25?1.04:age<=29?1:age<=31?.88:age<=33?.72:.56;
    const contract=years<=1?.82:years===2?1:years===3?1.1:1.17;
    const academy=1+clamp((rep-80)*.01,-.12,.19);
    // Age-aware market value is a floor only, not a second markup.
    const base=clamp(Number(marketValue)||0,0,160);
    return round(clamp(Math.max(base*.90,ability*experience*contract*academy),.5,155));
  }
  // Evaluate real club competition BEFORE bidding. A strong senior must have
  // plausible first-team minutes; high-potential U21s can instead develop.
  function opportunity119(p,roster,buyer=null){
    const entry=firstDestination121x(p,buyer,roster);
    if(p?.shadowAcademy116&&!p.shadowSenior118&&!p.shadowSignedSeason117){
      if(!entry)return null;
      return {role:entry.role,fit:entry.fit,stronger:entry.competition,firstDestination121x:true};
    }
    const peers=(roster||[]).filter(x=>family(x)===family(p));
    const ovr=Number(p.overall)||55,pot=Number(p.development?.potentialMax)||ovr;
    const stronger=peers.filter(x=>Number(x.overall||0)>ovr+1).length;
    const slots={GK:1,DEF:4,MID:3,WIDE:2,ST:1}[family(p)]||2;
    if(p.shadowSenior118){
      if(stronger>=slots+3)return null;
      const role=stronger<slots?'First team':'Rotation';
      return {role,fit:clamp(12-(Math.max(0,stronger-slots+1)*3),-9,13),stronger};
    }
    if(Number(p.age)<=21&&ovr<74){
      // At smaller clubs a 58-rated player may already be senior-ready.
      const tier=Number(buyer?.tier)||1;
      const peerQuality=peers.length?peers.map(x=>Number(x.overall||55)).sort((a,b)=>b-a)[Math.min(slots,peers.length-1)]:58;
      if(tier>=2&&ovr>=peerQuality-7&&stronger<=slots+3){
        return {role:stronger<slots?'First team':'Development rotation',fit:clamp(11-(Math.max(0,stronger-slots)*2),-5,12),stronger};
      }
      if(stronger>=slots+8&&pot<88)return null;
      return {role:'U21 development',fit:clamp(8-(Math.max(0,stronger-slots-2)*1.5),-7,10),stronger};
    }
    if(stronger>=slots+5&&pot<88)return null;
    return {role:stronger<slots?'First team':'Development rotation',fit:clamp(10-(Math.max(0,stronger-slots+1)*2),-7,12),stronger};
  }
  function scoutScore(p,buyer,roster,origin,seed,callbacks){
    const pot=Number(p.development?.potentialMax||p.overall||0),ovr=Number(p.overall||0),fam=family(p),list=roster||[];
    const group=list.filter(x=>family(x)===fam),short=Math.max(0,(NEED[fam]||4)-group.length);
    const median=list.length?list.map(x=>Number(x.overall||60)).sort((a,b)=>a-b)[Math.floor(list.length*.5)]:65;
    const age=Number(p.age||18),rep=Number(callbacks.prestige(buyer)||70);
    const tier=Number(buyer.tier)||1;
    // Lower-division teams recruit current ability relative to their own squad;
    // potential is upside, not a compulsory 90+ rating chase.
    if(tier>=2&& (ovr<median-12||ovr>median+(tier>=3?10:13)))return null;
    // A top side only chases underdeveloped players when potential is genuinely high.
    if(rep>=88&&pot<84&&ovr<74)return null;
    if(rep>=82&&pot<79&&ovr<68)return null;
    const route=links(buyer).includes(origin.region)?10:0;
    const ambition=Math.max(-10,Math.min(12,(pot-77)*.75));
    const abilityFit=clamp((ovr-median)*.6,-11,10);
    const scarcity=Math.min(13,short*3.2);
    const room=group.length?Math.max(-12,8-(Math.max(...group.map(x=>Number(x.overall||0)))-ovr)*.75):7;
    const development=age<=21?Math.min(9,Math.max(0,pot-ovr)*.23):1;
    const random=roll(seed+'|scout|'+p.id+'|'+buyer.id)*11;
    const entry=firstDestination121x(p,buyer,roster);
    const entryBonus=entry?(entry.role==='First team'?14:6)+(tier>=2?8:-5):0;
    // 1.21z: when a 58-66 OVR graduate can start in tier 3, prefer an actual
    // professional role to being a reserve at tier 2. Never waive ability/budget checks.
    const firstTeamStep121z=entry&&age<=23&&ovr>=58&&ovr<=66?
      (tier>=3&&entry.role==='First team'?15:tier===2&&entry.role!=='First team'?-5:0):0;
    return {score:abilityFit+ambition+scarcity+room+development+route+random+46+entryBonus+firstTeamStep121z,short,fam,route,room};
  }
  function run(opts){
    const {players=[],clubs=[],shadowClubs=[],finances={},seed='shadow-117',year=2026,month='07',protectedClubId='',getValue=()=>0,getPrestige=c=>c.reputation||70,getManagerStyle=()=> 'Balanced Squad',getContractLength=()=>4,getContractWage=()=>.3,history=[]}=opts||{};
    const isSummer=String(month).includes('07');if(!isSummer&&!String(month).includes('01'))return [];
    const world=new Map(shadowClubs.filter(c=>c?.shadowOnly116).map(c=>[c.id,c]));
    const candidates=players.filter(p=>p?.shadowAcademy116&&world.has(p.clubId)&&!p.retired&&p.transferType!=='Loan'&&(
      p.shadowSenior118?(Number(p.age)>=22&&Number(p.age)<=33&&Number(p.overall)>=65):(Number(p.age)>=18&&Number(p.age)<=24&&Number(p.overall)>=55&&Number(p.development?.potentialMax||0)>=74)
    )&&(!p.lastPermanentTransferSeason108||Number(String(p.lastPermanentTransferSeason108).match(/20\d\d/)?.[0]||0)<Number(year)-2));
    if(!candidates.length)return [];
    const roster=new Map(), buyers=[];
    for(const c of clubs){if(!c||c.shadowOnly116||c.id===protectedClubId||!finances[c.id]||Number(finances[c.id].budget||0)<.75)continue;
      roster.set(c.id,[]);buyers.push(c);
    }
    if(!buyers.length)return [];
    for(const p of players){const list=roster.get(p?.clubId);if(list&&!p.retired&&p.transferType!=='Loan'&&Number(p.overall)>=35)list.push(p);}
    const validBuyers=buyers.filter(c=>(roster.get(c.id)||[]).length>=11);
    if(!validBuyers.length)return [];
    const moves=[],bought=new Map();let seniorDeals=0;
    // Preserve small overseas club stocks across July and January windows.
    // Previous windows are read-only; only this window creates new transfers.
    const sourceSold=new Map();
    for(const event of history||[]){
      if(!event?.shadowSource117||Number(String(event.season||'').match(/20\d\d/)?.[0]||0)!==Number(year))continue;
      const key=event.fromClubId,rec=sourceSold.get(key)||{all:0,seniors:0};
      rec.all++;if(event.shadowSenior118)rec.seniors++;sourceSold.set(key,rec);
    }
    const maxDeals=isSummer?Math.min(19,Math.max(7,Math.round(validBuyers.length*.16))):Math.min(7,Math.max(2,Math.round(validBuyers.length*.055)));
    const seniorCap=isSummer?Math.min(5,Math.ceil(maxDeals*.32)):Math.min(2,Math.ceil(maxDeals*.35));
    const sorted=candidates.map(p=>({p,priority:Number(p.development?.potentialMax||0)*.35+Number(p.overall||0)*.32+(p.shadowSenior118?3:0)+roll(seed+'|priority|'+p.id)*38})).sort((a,b)=>b.priority-a.priority).slice(0,Math.max(80,maxDeals*9));
    const funcs={prestige:getPrestige};
    for(const {p} of sorted){if(moves.length>=maxDeals)break;
      if(p.shadowSenior118&&seniorDeals>=seniorCap)continue;
      const origin=world.get(p.clubId);if(!origin)continue;
      const currentSource=sourceSold.get(origin.id)||{all:0,seniors:0};
      if(currentSource.all>=4||(p.shadowSenior118&&currentSource.seniors>=2))continue;
      const base=Number(getValue(p,year))||0,ask=reservePrice119(p,origin,base,year);
      const bids=[];
      for(const buyer of validBuyers){if((bought.get(buyer.id)||0)>=1)continue;
        const cash=finances[buyer.id];const budget=Number(cash?.budget||0);
        const rep=Number(getPrestige(buyer)||70);
        const fraction=rep>=87?.48:rep>=74?.40:.32;
        if(budget<ask||budget*fraction<ask)continue;
        const opportunity=opportunity119(p,roster.get(buyer.id),buyer);if(!opportunity)continue;
        const interest=scoutScore(p,buyer,roster.get(buyer.id),origin,seed,funcs);if(!interest)continue;
        interest.score+=opportunity.fit*.48;
        const cutoff=isSummer?61:65;
        if(interest.score<cutoff)continue;
        // Scouting reach affects discovery, not a prospect's raw ability.
        // Only clubs that genuinely discover this player may submit bids.
        const discovered=roll(seed+'|discover|'+p.id+'|'+buyer.id);
        const entryFirst=p.shadowAcademy116&&!p.shadowSenior118&&!p.shadowSignedSeason117;
        const reach=clamp(.08+(interest.route>0?.22:0)+(Number(p.development?.potentialMax||0)>=90?.10:0)+(rep>=89?.05:0)+
          (entryFirst&&Number(buyer.tier)>=2?.12:0),.06,.54);
        if(discovered>reach)continue;
        const playingFit=interest.room+Math.min(5,interest.short*2)+opportunity.fit;
        const lowDivisionStart121z=entryFirst&&Number(p.overall)>=58&&Number(p.overall)<=66&&Number(buyer.tier)>=3&&opportunity.role==='First team'?8:0;
        if(p.shadowSenior118&&opportunity.role!=='First team'&&rep>=87&&Number(p.overall)<73)continue;
        // Prospects want a meaningful development path, not just a prestigious badge.
        const playerInterest=clamp(Math.round(36+rep*.40+playingFit*.75+lowDivisionStart121z+(interest.route>0?5:0)-Math.max(0,rep-89)*.55+
          (entryFirst?(opportunity.role==='First team'?10:Number(buyer.tier)>=2?7:-11):0)+
          (roll(seed+'|interest|'+p.id+'|'+buyer.id)-.5)*14),10,96);
        if(playerInterest<(p.shadowSenior118?61:57))continue;
        const factor=1+Math.min(.16,Math.max(0,interest.score-63)*.003)+(roll(seed+'|bid|'+p.id+'|'+buyer.id)-.5)*.12;
        const fee=round(Math.max(ask,ask*factor));if(fee>budget*fraction||fee>budget)continue;
        bids.push({buyer,fee,score:interest.score,interest:playerInterest,fit:playingFit,rep,role:opportunity.role});
      }
      if(!bids.length)continue;
      // Only genuinely interested, affordable bidders participate in the race.
      bids.sort((a,b)=>(b.score+b.interest*.3)-(a.score+a.interest*.3));
      const finalists=bids.slice(0,Math.min(4,bids.length));
      // Player preference, viable minutes and fee all matter; top fee need not win.
      const winner=finalists.map(b=>({...b,decision:b.interest*.58+b.fit*.50+b.score*.28+(b.fee/Math.max(.5,ask))*5+roll(seed+'|decision|'+p.id+'|'+b.buyer.id)*5})).sort((a,b)=>b.decision-a.decision)[0];
      const price=winner.fee,club=winner.buyer,cash=finances[club.id];
      if(!cash||Number(cash.budget||0)<price)continue;
      const fromId=p.clubId;
      p.clubId=club.id;p.teamName=club.name;p.leagueName=club.league;
      p.transferType='Permanent';p.clubTenure073=0;p.clubLegend073=false;
      p.lastTransferSeason=String(year);p.lastPermanentTransferSeason108=String(year);p.lastTransferWindow=isSummer?'July':'January';
      p.registrationGroup=Number(club.tier)>=2&&winner.role!=='U21 development'||Number(p.overall)>=74||Number(p.age)>21?'Senior':'U21';p.squadStatus=p.registrationGroup==='U21'?'U21':'First Team';
      p.shadowSignedSeason117=Number(year);p.shadowSignedFee117=price;
      p.shadowCareerPath119=winner.role;
      if(!p.shadowSenior118&&!p.shadowFirstDestination121x){
        p.shadowFirstDestination121x={clubId:club.id,clubName:club.name,tier:clamp(Number(club.tier)||1,1,4),year:Number(year),role:winner.role};
      }
      p.contractUntil=Number(year)+clamp(Number(getContractLength(p,club))||4,2,6);
      p.wage=Number(getContractWage(p,club))||.3;
      p.morale=clamp(Number(p.morale||72)+5,0,99);
      cash.budget=round(Math.max(0,Number(cash.budget)-price));cash.spent=round(Number(cash.spent||0)+price);
      const source=world.get(fromId);
      bought.set(club.id,(bought.get(club.id)||0)+1);if(p.shadowSenior118)seniorDeals++;
      const sourceLedger=sourceSold.get(fromId)||{all:0,seniors:0};
      sourceLedger.all++;if(p.shadowSenior118)sourceLedger.seniors++;sourceSold.set(fromId,sourceLedger);
      const list=roster.get(club.id);if(list)list.push(p);
      moves.push({kind:'ai-transfer',shadowSource117:true,shadowSenior118:Boolean(p.shadowSenior118),season:String(year),window:isSummer?'July':'January',playerId:p.id,playerName:p.name,fromClubId:fromId,fromClubName:source.name,toClubId:club.id,toClubName:club.name,toLeague:club.league,fee:price,position:String(p.positions?.[0]||p.position||'MID'),managerStyle:getManagerStyle(club,year),philosophy:'Global Talent Recruitment',careerPath119:winner.role,firstDestinationTier121x:Number(p.shadowFirstDestination121x?.tier||club.tier||1),overall119:Number(p.overall||0),age119:Number(p.age||0),reserve119:ask,interest:winner.interest,competition:finalists.filter(b=>b.buyer.id!==club.id).map(b=>b.buyer.name),bids117:finalists.map(b=>({clubId:b.buyer.id,clubName:b.buyer.name,fee:b.fee,playerInterest:b.interest,careerPath119:b.role})),scoutingRoute117:origin.region,contractUntil:p.contractUntil});
    }
    return moves;
  }
  const api=Object.freeze({run,family,academyFee,reservePrice119,opportunity119,firstDestination121x,links});
  root.FDShadowMarket117=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
