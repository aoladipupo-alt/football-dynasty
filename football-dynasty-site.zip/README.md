# Football Dynasty — Website Foundation Phase 1

This is a **working, static, hostable** Football Dynasty web shell. **No Base44 code or user account integration is included in this ZIP yet.** The existing game code is preserved byte-for-byte under `/game/`.

## How to run

```bash
python3 -m http.server 8765 --directory .
```
Open `http://localhost:8765/` from this folder. The career hub is the root; `/game/index.html` runs the unchanged original game.

Deploy the **contents** of this archive to a static web host. Avoid deploying the site from `file://`, because storage/service workers depend on a proper origin. Keep all paths relative and the entire `/game/` directory together.

## Base44 integration status

Base44 app: `6ad248071090badba59b648b`

Created private owner-only `Career` and `LeagueLobby` schemas in Base44. Neither browser-save uploading nor multiplayer gameplay is connected yet. Base44 source editing requires a Builder-plan workspace; Base44's built-in AI builder may be used for further site changes on the current plan. This static hub is a source-preserving hostable artifact, not proof of Base44 deployment.

## Important caveats

- `localStorage` and `IndexedDB` data are stored per origin. **Previous browser saves will not automatically follow the game** from a local file or another domain.
- Do not enable cloud restore, overwrite or multiplayer writes without real access controls and a round-trip restoration test.
- App version 1.23a still has an unresolved cold-reopen long-career test issue.
- All original 410 files are under `/game/`, unchanged. The root page is a new landing page.

## 1.23c web-launcher integration (next phase)
- The static website entry is `index.html`, and `play.html` embeds the **unchanged gameplay engine**, retained under `game/`.
- The only game-file edits are an opt-in, same-origin status/backup bridge script reference and a service-worker cache update. The core runtime and player data remain byte-for-byte unchanged.
- `play.html` has a Back to hub link, opens the full game in another tab, detects when a career has actually loaded, and requests an in-game backup download. It does not read or transmit career payloads.
- For **Import backup**, use the game's existing Settings > Career Files > Import backup action. It validates before modifying a save and keeps an import recovery copy.
- Browser careers are keyed to **web origin**. Moving from ZIP/local server to Base44 or to a different domain does **not** move saves automatically. Export/import is the only verified migration path.
- The Base44 app currently stores private career metadata and draft league metadata, but it does **not** host the game's full JavaScript engine or sync its browser saves. Deploy this complete static directory to the same origin to use `play.html` as supplied.
- Multiplayer is not implemented and is explicitly labeled unavailable. The status bridge intentionally provides no user-controlled write APIs.
- Opening index.html from file:// is not a supported hosted test path; serve via `python -m http.server 8000`.
