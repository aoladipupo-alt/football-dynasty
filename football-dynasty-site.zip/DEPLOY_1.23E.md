# Football Dynasty 1.23e — Static site publication guide

## Scope
This is the **actual existing 1.23b single-player game**, delivered with the 1.23d launcher and hosting checker. The game files have not been modified; the only additions are GitHub Pages deployment configuration and a local/CI validation script. **No cloud save synchronization, multiplayer, or verified live hosting** is claimed.

## Publish through GitHub Pages
1. **Back up current careers first**: from the original game's Settings → Career Files → Export career. Browser storage is separate for every origin/domain.
2. Connect GitHub to ChatGPT if you want us to work with a repository through chat, or create a repository in GitHub yourself. A public repository makes the complete client-side game source and assets publicly accessible; confirm you have rights to distribute all included content. GitHub Pages availability and privacy depend on the user's GitHub plan/settings.
3. Put all files **at the repository root**, including the hidden `.nojekyll` file and `.github/workflows/deploy-pages.yml`. Do not upload the ZIP without extracting unless the repository host handles extraction.
4. In your GitHub repository choose Settings → Pages → Build and deployment → **GitHub Actions**. Push the files to the `main` branch and let the deployment workflow finish.
5. Your project site will typically be `https://YOUR_USERNAME.github.io/YOUR_REPOSITORY/`; it is not a verified published URL until deployed. Opening `hosting-check.html` on this site and selecting **Verify file SHA-256 hashes** should confirm all 7 required assets.
6. Verify real gameplay: start a new career, play through a match, export career backup, import into a new slot, and reopen after restarting the browser. Only then describe the site as tested playable.
7. In the Base44 Football Dynasty app, link a Play button to the verified GitHub Pages URL. The external game's local save is on the GitHub Pages origin, not on Base44's domain.

## Local smoke check
Run `python3 scripts/verify-static-release.py` from an extracted archive to validate all essential hashes and static links. For a local HTTP test, run `python3 -m http.server 8000` at the archive root, then open `http://localhost:8000/hosting-check.html`. The game needs HTTP(S), not `file://`, for browser storage and service worker features.

## Important boundaries
- This GitHub Pages workflow deploys only static HTML, CSS, JS, images, and data. Multiplayer authority and account-linked cloud saves need a secure backend and separately verified authorization.
- Existing career backups should **not** be checked into GitHub. Browser storage is not transferred across host domains.
- GitHub Pages hosting does not automatically place game files inside Base44; Base44 can link to the deployed game once verified.
- Base44's direct code editing is restricted on the user's current workspace plan.
