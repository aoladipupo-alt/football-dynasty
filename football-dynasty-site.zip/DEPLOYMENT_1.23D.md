# Football Dynasty 1.23d — Hosted deployment validation

This package contains the original **1.23b Football Dynasty gameplay engine** as bundled in 1.23c, without modifying any file under `game/`. The engine has not been deployed to the Base44 domain by generating this ZIP.

## Deployment workflow
1. Publish **every file** in this ZIP to a static HTTPS website root. `game/index.html`, `game/data/*`, and `game/assets/*` must all be reachable under the *same origin* as `play.html`.
2. Visit `/hosting-check.html` and run **Check game deployment**; optionally check SHA-256 hashes. It verifies seven critical assets, MIME types, exact sizes and local storage availability.
3. Open `/play.html`; verify the actual game initializes and a *new* test career starts. Export a backup; import it into another test career slot; restart the browser and cold-reopen the save.
4. Only after those checks pass update the Base44 integration status from `locally_packaged` to `deployed_verified`.

## Base44 limitations
Base44's direct sandbox/file access currently requires a Builder workspace, and the Base44 builder has not ingested the static game bundle. The Base44 UI alone is not a hosted version of the match engine. You need an authorized way to deploy the static files to the site's origin, or host them separately with an explicit link. Do not iframe from a second domain expecting old `localStorage` saves or same-origin `postMessage` integration.

## Existing save safety
No cloud saves or multiplayer. Browser saves are origin-specific; export from the old site and use **Settings > Career Files > Import backup** on the new site. No automated migration or raw save transmission through the launcher. Never overwrite original careers during testing.

## Tested limits
Deployment checks are static and targeted. They do not certify long-term career cold reopen, full-season simulation, or online multiplayer.
