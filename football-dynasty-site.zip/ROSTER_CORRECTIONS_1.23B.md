# Football Dynasty 1.23b — roster and positional corrections

## Corrections
- Raheem Sterling (EA 202652) is a free agent, not assigned to Chelsea in newly generated 2026 careers. First-year, otherwise untouched Chelsea placements from old saves are corrected; real later transfers remain intact.
- Christantus Uche (EA 73374) is 23 and Nigerian. Preserves the canonical Crystal Palace record, removes the stale Getafe identity, and adds the portrait uploaded by the user.
- Removes the duplicate **Josep Chavarria** registration placeholder. **Pep Chavarría** (EA 258371) remains active; no attributes or club assignment changed.
- Adds **LWB** when both **LB and LM** are listed, and **RWB** when both **RB and RM** are listed. Primary positions, ratings and existing other positions are preserved. This also applies when previously saved position lists are restored.

## Caveats
- Old career saves can contain references to removed placeholder identities. They are intentionally not automatically rewritten in old transfer histories to avoid corrupting match records.
- Bundled portrait is user-supplied. Redistribution rights were not verified.
- This project ZIP is a standalone hosted-web foundation; the full single-player engine is here. Base44's separate scaffold does **not** automatically contain these files yet.
